/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * PChat Client-Side Persistent Offline Storage (IndexedDB)
 * 
 * Provides:
 * - Offline cached message history per conversation
 * - Pending outgoing message queue with automatic retry
 * - Stable ID reconciliation and duplicate elimination
 * - Non-destructive merge logic so partial API responses never clobber full local history
 * - Synchronization cursors & recovery
 * - Strictly stores no passwords or authentication secrets
 */

import { MessageItem, ConversationItem } from '../context/ChatContext.js';

const DB_NAME = 'pchat_offline_store';
const DB_VERSION = 1;

const STORE_MESSAGES = 'messages';
const STORE_PENDING = 'pending_outgoing';
const STORE_CONVERSATIONS = 'conversations';
const STORE_METADATA = 'sync_metadata';

let dbInstance: IDBDatabase | null = null;
let dbInitPromise: Promise<IDBDatabase> | null = null;

function isIndexedDBAvailable(): boolean {
  return typeof window !== 'undefined' && typeof window.indexedDB !== 'undefined';
}

export function openLocalDB(): Promise<IDBDatabase> {
  if (!isIndexedDBAvailable()) {
    return Promise.reject(new Error('IndexedDB is not supported in this runtime environment.'));
  }

  if (dbInstance) {
    return Promise.resolve(dbInstance);
  }

  if (dbInitPromise) {
    return dbInitPromise;
  }

  dbInitPromise = new Promise((resolve, reject) => {
    try {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;

        // 1. Messages Store: indexed by id, conversation_id, and created_at
        if (!db.objectStoreNames.contains(STORE_MESSAGES)) {
          const msgStore = db.createObjectStore(STORE_MESSAGES, { keyPath: 'id' });
          msgStore.createIndex('conversation_id', 'conversation_id', { unique: false });
          msgStore.createIndex('created_at', 'created_at', { unique: false });
          msgStore.createIndex('conv_created', ['conversation_id', 'created_at'], { unique: false });
          msgStore.createIndex('status', 'status', { unique: false });
        }

        // 2. Pending Outgoing Queue Store: indexed by client_temp_id
        if (!db.objectStoreNames.contains(STORE_PENDING)) {
          const pendingStore = db.createObjectStore(STORE_PENDING, { keyPath: 'client_temp_id' });
          pendingStore.createIndex('conversation_id', 'conversation_id', { unique: false });
          pendingStore.createIndex('created_at', 'created_at', { unique: false });
        }

        // 3. Conversations Store: cached summary
        if (!db.objectStoreNames.contains(STORE_CONVERSATIONS)) {
          const convStore = db.createObjectStore(STORE_CONVERSATIONS, { keyPath: 'id' });
          convStore.createIndex('updated_at', 'updated_at', { unique: false });
        }

        // 4. Synchronization metadata store
        if (!db.objectStoreNames.contains(STORE_METADATA)) {
          db.createObjectStore(STORE_METADATA, { keyPath: 'key' });
        }
      };

      request.onsuccess = (event) => {
        dbInstance = (event.target as IDBOpenDBRequest).result;

        dbInstance.onversionchange = () => {
          dbInstance?.close();
          dbInstance = null;
          dbInitPromise = null;
        };

        resolve(dbInstance);
      };

      request.onerror = () => {
        dbInitPromise = null;
        reject(request.error || new Error('Failed to open IndexedDB.'));
      };

      request.onblocked = () => {
        console.warn('[PChat IndexedDB] Database upgrade blocked by another open tab.');
      };
    } catch (err) {
      dbInitPromise = null;
      reject(err);
    }
  });

  return dbInitPromise;
}

// -----------------------------------------------------------------------------
// Message History Storage & Non-Destructive Merging
// -----------------------------------------------------------------------------

/**
 * Saves a list of messages into IndexedDB.
 * Updates existing records or adds new ones without destroying local messages.
 */
export async function saveMessagesToLocalDB(messages: MessageItem[]): Promise<void> {
  if (!messages || messages.length === 0 || !isIndexedDBAvailable()) return;
  try {
    const db = await openLocalDB();
    const tx = db.transaction(STORE_MESSAGES, 'readwrite');
    const store = tx.objectStore(STORE_MESSAGES);

    for (const msg of messages) {
      if (!msg || !msg.id) continue;
      // Sanitize to plain object suitable for IndexedDB structured clone
      const cleanMsg: MessageItem = {
        id: msg.id,
        conversation_id: msg.conversation_id,
        sender_id: msg.sender_id,
        text: msg.text || '',
        reply_to_id: msg.reply_to_id || null,
        parent_message_id: msg.parent_message_id || msg.reply_to_id || null,
        status: msg.status || 'sent',
        is_edited: Boolean(msg.is_edited),
        is_deleted: Boolean(msg.is_deleted),
        created_at: msg.created_at,
        updated_at: msg.updated_at || msg.created_at,
        audio_url: msg.audio_url || null,
        audio_duration: typeof msg.audio_duration === 'number' ? msg.audio_duration : null,
        reactions: msg.reactions || {},
        sender: msg.sender ? {
          id: msg.sender.id,
          username: msg.sender.username,
          display_name: msg.sender.display_name,
          avatar_url: msg.sender.avatar_url || '',
        } : undefined,
        reply_to: msg.reply_to ? { ...msg.reply_to } : null,
        parent_message: msg.parent_message ? { ...msg.parent_message } : null,
        client_temp_id: msg.client_temp_id || null,
      };
      store.put(cleanMsg);
    }

    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('[PChat IndexedDB] saveMessages error:', err);
  }
}

/**
 * Loads cached messages from IndexedDB for an active conversation.
 */
export async function getMessagesFromLocalDB(conversationId: string, limit = 200): Promise<MessageItem[]> {
  if (!conversationId || !isIndexedDBAvailable()) return [];
  try {
    const db = await openLocalDB();
    const tx = db.transaction(STORE_MESSAGES, 'readonly');
    const store = tx.objectStore(STORE_MESSAGES);
    const index = store.index('conversation_id');
    const request = index.getAll(conversationId);

    return new Promise((resolve) => {
      request.onsuccess = () => {
        const all: MessageItem[] = request.result || [];
        // Sort chronologically ascending by created_at
        all.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
        resolve(all.slice(-limit));
      };
      request.onerror = () => {
        resolve([]);
      };
    });
  } catch (err) {
    console.warn('[PChat IndexedDB] getMessages error:', err);
    return [];
  }
}

/**
 * Update an individual message in IndexedDB (reactions, edit, status, deletion)
 */
export async function updateLocalMessage(messageId: string, updater: (prev: MessageItem) => MessageItem): Promise<void> {
  if (!messageId || !isIndexedDBAvailable()) return;
  try {
    const db = await openLocalDB();
    const tx = db.transaction(STORE_MESSAGES, 'readwrite');
    const store = tx.objectStore(STORE_MESSAGES);
    const getReq = store.get(messageId);

    getReq.onsuccess = () => {
      const existing = getReq.result as MessageItem | undefined;
      if (existing) {
        const updated = updater(existing);
        store.put(updated);
      }
    };
  } catch (err) {
    console.warn('[PChat IndexedDB] updateLocalMessage error:', err);
  }
}

// -----------------------------------------------------------------------------
// Offline Pending Outgoing Queue
// -----------------------------------------------------------------------------

export interface PendingOutgoingMessage {
  client_temp_id: string;
  conversation_id: string;
  text: string;
  reply_to_id: string | null;
  parent_message_id: string | null;
  audio_url?: string | null;
  audio_duration?: number | null;
  image_url?: string | null;
  created_at: string;
  retry_count: number;
}

/**
 * Queues a message locally when offline or waiting for confirmation.
 */
export async function queuePendingMessage(msg: PendingOutgoingMessage): Promise<void> {
  if (!isIndexedDBAvailable()) return;
  try {
    const db = await openLocalDB();
    const tx = db.transaction(STORE_PENDING, 'readwrite');
    tx.objectStore(STORE_PENDING).put(msg);
  } catch (err) {
    console.warn('[PChat IndexedDB] queuePendingMessage error:', err);
  }
}

/**
 * Removes a pending message once server persistence is confirmed.
 */
export async function removePendingMessage(clientTempId: string): Promise<void> {
  if (!clientTempId || !isIndexedDBAvailable()) return;
  try {
    const db = await openLocalDB();
    const tx = db.transaction(STORE_PENDING, 'readwrite');
    tx.objectStore(STORE_PENDING).delete(clientTempId);
  } catch (err) {
    console.warn('[PChat IndexedDB] removePendingMessage error:', err);
  }
}

/**
 * Retrieves all pending outgoing messages for replay when back online.
 */
export async function getAllPendingMessages(): Promise<PendingOutgoingMessage[]> {
  if (!isIndexedDBAvailable()) return [];
  try {
    const db = await openLocalDB();
    const tx = db.transaction(STORE_PENDING, 'readonly');
    const request = tx.objectStore(STORE_PENDING).getAll();

    return new Promise((resolve) => {
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => resolve([]);
    });
  } catch (err) {
    return [];
  }
}

// -----------------------------------------------------------------------------
// Synchronization Cursors & Safe Merging Rules
// -----------------------------------------------------------------------------

/**
 * Merges local cached messages with incoming server messages.
 * Critical Rule: Never replaces complete local history with an incomplete API response.
 * Merges by stable server ID, preserves optimistic messages, and updates status/reactions.
 */
export function mergeMessageLists(
  localMessages: MessageItem[],
  serverMessages: MessageItem[]
): MessageItem[] {
  const map = new Map<string, MessageItem>();

  // 1. Index local messages first
  for (const m of localMessages) {
    if (m && m.id) {
      map.set(m.id, m);
    }
  }

  // 2. Reconcile with incoming server messages
  for (const s of serverMessages) {
    if (!s || !s.id) continue;

    // Check if we have an optimistic pending copy with client_temp_id
    if (s.client_temp_id && map.has(s.client_temp_id)) {
      map.delete(s.client_temp_id);
    }

    // Also look for any local pending message with matching client_temp_id or identical text + sender within 10s
    for (const [key, localMsg] of map.entries()) {
      if (
        (s.client_temp_id && (localMsg.client_temp_id === s.client_temp_id || localMsg.id === s.client_temp_id)) ||
        (localMsg.status === 'pending' &&
          localMsg.sender_id === s.sender_id &&
          localMsg.text === s.text &&
          Math.abs(new Date(localMsg.created_at).getTime() - new Date(s.created_at).getTime()) < 12000)
      ) {
        map.delete(key);
      }
    }

    const existing = map.get(s.id);
    if (!existing) {
      map.set(s.id, s);
    } else {
      // Merge updates (edits, reactions, status progression: sent -> delivered -> read)
      map.set(s.id, {
        ...existing,
        ...s,
        reactions: s.reactions || existing.reactions,
        // Status should only progress forward, never downgrade
        status: (existing.status === 'read' && s.status !== 'read') ? 'read' : s.status,
      });
    }
  }

  // 3. Return sorted chronologically
  const result = Array.from(map.values());
  result.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
  return result;
}

/**
 * Record last known synchronization cursor (timestamp / message ID) per conversation
 */
export async function setSyncCursor(conversationId: string, lastMessageId: string, timestamp: string): Promise<void> {
  if (!isIndexedDBAvailable()) return;
  try {
    const db = await openLocalDB();
    const tx = db.transaction(STORE_METADATA, 'readwrite');
    tx.objectStore(STORE_METADATA).put({
      key: `cursor_${conversationId}`,
      last_message_id: lastMessageId,
      timestamp,
    });
  } catch (err) {
    // ignore
  }
}

export async function getSyncCursor(conversationId: string): Promise<{ last_message_id: string; timestamp: string } | null> {
  if (!isIndexedDBAvailable()) return null;
  try {
    const db = await openLocalDB();
    const tx = db.transaction(STORE_METADATA, 'readonly');
    const req = tx.objectStore(STORE_METADATA).get(`cursor_${conversationId}`);
    return new Promise((resolve) => {
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

// -----------------------------------------------------------------------------
// Cached Conversations Store
// -----------------------------------------------------------------------------

export async function saveConversationsToLocalDB(conversations: ConversationItem[]): Promise<void> {
  if (!conversations || conversations.length === 0 || !isIndexedDBAvailable()) return;
  try {
    const db = await openLocalDB();
    const tx = db.transaction(STORE_CONVERSATIONS, 'readwrite');
    const store = tx.objectStore(STORE_CONVERSATIONS);
    for (const c of conversations) {
      if (c && c.id) {
        store.put(c);
      }
    }
  } catch (err) {
    console.warn('[PChat IndexedDB] saveConversations error:', err);
  }
}

export async function getConversationsFromLocalDB(): Promise<ConversationItem[]> {
  if (!isIndexedDBAvailable()) return [];
  try {
    const db = await openLocalDB();
    const tx = db.transaction(STORE_CONVERSATIONS, 'readonly');
    const req = tx.objectStore(STORE_CONVERSATIONS).getAll();
    return new Promise((resolve) => {
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => resolve([]);
    });
  } catch {
    return [];
  }
}
