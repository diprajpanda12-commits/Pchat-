export interface AvatarOption {
  id: string;
  name: string;
  url: string;
  category: 'Popular' | 'Heroes' | 'Vibe' | 'Special';
  badgeColor: string;
  description: string;
}

export const AVATAR_CATALOG: AvatarOption[] = [
  {
    id: 'emerald',
    name: 'Emerald Bamboo',
    url: '/avatars/panda-emerald.svg',
    category: 'Popular',
    badgeColor: 'from-emerald-500 to-teal-600',
    description: 'Classic panda with fresh bamboo and rosy cheeks',
  },
  {
    id: 'cyber',
    name: 'Cyberpunk Visor',
    url: '/avatars/panda-cyber.svg',
    category: 'Heroes',
    badgeColor: 'from-cyan-500 to-blue-600',
    description: 'Neon cyan visor with futuristic circuit styling',
  },
  {
    id: 'royal',
    name: 'Royal Crown',
    url: '/avatars/panda-royal.svg',
    category: 'Special',
    badgeColor: 'from-purple-600 to-indigo-700',
    description: 'Majestic starry crown with ruby & sapphire gems',
  },
  {
    id: 'sunset',
    name: 'Golden Sunset',
    url: '/avatars/panda-sunset.svg',
    category: 'Vibe',
    badgeColor: 'from-amber-500 to-orange-600',
    description: 'Cool aviator sunglasses with warm golden rays',
  },
  {
    id: 'ninja',
    name: 'Stealth Ninja',
    url: '/avatars/panda-ninja.svg',
    category: 'Heroes',
    badgeColor: 'from-red-600 to-rose-700',
    description: 'Crimson headband and stealth ninja mask',
  },
  {
    id: 'astro',
    name: 'Cosmic Astro',
    url: '/avatars/panda-astro.svg',
    category: 'Heroes',
    badgeColor: 'from-sky-500 to-indigo-600',
    description: 'Deep space bubble helmet and starlight reflections',
  },
  {
    id: 'gamer',
    name: 'RGB Pro Gamer',
    url: '/avatars/panda-gamer.svg',
    category: 'Popular',
    badgeColor: 'from-fuchsia-500 to-cyan-500',
    description: 'High-end RGB lighted headset with boom mic',
  },
  {
    id: 'chef',
    name: 'Master Chef',
    url: '/avatars/panda-chef.svg',
    category: 'Special',
    badgeColor: 'from-orange-500 to-amber-600',
    description: 'Crisp white toque blanche and joyful culinary spirit',
  },
  {
    id: 'zen',
    name: 'Zen Blossom',
    url: '/avatars/panda-zen.svg',
    category: 'Vibe',
    badgeColor: 'from-teal-500 to-emerald-700',
    description: 'Gentle cherry blossom flower and serene meditation',
  },
  {
    id: 'detective',
    name: 'Sleuth Detective',
    url: '/avatars/panda-detective.svg',
    category: 'Special',
    badgeColor: 'from-amber-700 to-stone-800',
    description: 'Tweed fedora and investigative monocle',
  },
  {
    id: 'classic',
    name: 'Studio Classic',
    url: '/avatars/panda-classic.svg',
    category: 'Popular',
    badgeColor: 'from-slate-600 to-slate-900',
    description: 'High-gloss minimalist panda with sparkling eyes',
  },
  {
    id: 'magic',
    name: 'Arcane Wizard',
    url: '/avatars/panda-magic.svg',
    category: 'Heroes',
    badgeColor: 'from-violet-600 to-purple-800',
    description: 'Pointed starry wizard hat with mystical sparkles',
  },
];

export const DEFAULT_AVATAR = AVATAR_CATALOG[0].url;

export function resolveAvatarUrl(url?: string | null): string {
  if (!url) return DEFAULT_AVATAR;
  // If it's a known avatar or starts with / or http
  return url;
}
