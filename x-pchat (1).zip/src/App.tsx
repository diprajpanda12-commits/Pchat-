/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.js';
import { ChatProvider, useChat } from './context/ChatContext.js';
import { LanguageProvider } from './context/LanguageContext.js';
import { ThemeProvider, useTheme } from './context/ThemeContext.js';
import { Header } from './components/Header.js';
import { Sidebar } from './components/Sidebar.js';
import { ChatArea } from './components/ChatArea.js';
import { AuthScreen } from './components/AuthScreen.js';
import { GroupModal } from './components/GroupModal.js';
import { UserSearchModal } from './components/UserSearchModal.js';
import { ProfileModal } from './components/ProfileModal.js';
import { TestRunnerModal } from './components/TestRunnerModal.js';
import { DjangoDocsModal } from './components/DjangoDocsModal.js';
import { ConnectionMonitorModal } from './components/ConnectionMonitorModal.js';
import { OfflineIndicator } from './components/OfflineIndicator.js';
import { InAppNotificationToast } from './components/InAppNotificationToast.js';
import { NotificationSettingsModal } from './components/NotificationSettingsModal.js';

function MainApp() {
  const { user, isLoading } = useAuth();
  const { activeConversation, selectConversation } = useChat();
  const { theme, toggleTheme, isDark } = useTheme();

  const [isGroupModalOpen, setIsGroupModalOpen] = useState(false);
  const [groupModalMode, setGroupModalMode] = useState<'create' | 'manage'>('create');
  const [isUserSearchOpen, setIsUserSearchOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isTestRunnerOpen, setIsTestRunnerOpen] = useState(false);
  const [isDjangoDocsOpen, setIsDjangoDocsOpen] = useState(false);
  const [isConnectionMonitorOpen, setIsConnectionMonitorOpen] = useState(false);
  const [isNotificationSettingsOpen, setIsNotificationSettingsOpen] = useState(false);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-400">
        <div className="w-20 h-20 rounded-2xl bg-slate-900 border border-slate-800/80 flex items-center justify-center mb-4 overflow-hidden shadow-2xl shadow-purple-950/40 animate-pulse">
          <img src="/pchat-logo.png" alt="PChat" className="w-full h-full object-cover" />
        </div>
        <p className="text-sm font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
          Loading PChat (Panda Chat)...
        </p>
      </div>
    );
  }

  if (!user) {
    return <AuthScreen />;
  }

  return (
    <div className={`h-screen flex flex-col ${isDark ? 'dark bg-slate-950 text-slate-100' : 'light bg-slate-50 text-slate-900'} overflow-hidden select-none`}>
      {/* Top Header */}
      <Header
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenTestRunner={() => setIsTestRunnerOpen(true)}
        onOpenDjangoDocs={() => setIsDjangoDocsOpen(true)}
        onOpenConnectionMonitor={() => setIsConnectionMonitorOpen(true)}
        onOpenNotificationSettings={() => setIsNotificationSettingsOpen(true)}
        theme={theme}
        onToggleTheme={toggleTheme}
      />

      {/* Main Chat Layout */}
      <div className="flex-1 flex overflow-hidden relative min-w-0 w-full">
        {/* Sidebar: always visible on desktop; on mobile visible if no activeConversation selected */}
        <div className={`h-full shrink-0 ${activeConversation ? 'hidden md:flex' : 'flex w-full md:w-auto'}`}>
          <Sidebar
            onOpenNewGroup={() => {
              setGroupModalMode('create');
              setIsGroupModalOpen(true);
            }}
            onOpenUserSearch={() => setIsUserSearchOpen(true)}
            onOpenProfile={() => setIsProfileOpen(true)}
            onOpenNotificationSettings={() => setIsNotificationSettingsOpen(true)}
          />
        </div>

        {/* Chat Area: visible on desktop or if activeConversation selected */}
        <div className={`flex-1 min-w-0 h-full ${!activeConversation ? 'hidden md:flex' : 'flex w-full'}`}>
          <ChatArea
            onOpenGroupDetails={() => {
              setGroupModalMode('manage');
              setIsGroupModalOpen(true);
            }}
            onBackToSidebar={() => selectConversation(null)}
          />
        </div>
      </div>

      {/* In-App Message Notification Toast */}
      <InAppNotificationToast />

      {/* Offline Toast Indicator */}
      <OfflineIndicator />

      {/* Modals */}
      <GroupModal
        isOpen={isGroupModalOpen}
        onClose={() => setIsGroupModalOpen(false)}
        mode={groupModalMode}
      />

      <UserSearchModal
        isOpen={isUserSearchOpen}
        onClose={() => setIsUserSearchOpen(false)}
      />

      <ProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
      />

      <NotificationSettingsModal
        isOpen={isNotificationSettingsOpen}
        onClose={() => setIsNotificationSettingsOpen(false)}
      />

      <TestRunnerModal
        isOpen={isTestRunnerOpen}
        onClose={() => setIsTestRunnerOpen(false)}
      />

      <DjangoDocsModal
        isOpen={isDjangoDocsOpen}
        onClose={() => setIsDjangoDocsOpen(false)}
      />

      <ConnectionMonitorModal
        isOpen={isConnectionMonitorOpen}
        onClose={() => setIsConnectionMonitorOpen(false)}
        onOpenTestRunner={() => setIsTestRunnerOpen(true)}
      />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <AuthProvider>
          <ChatProvider>
            <MainApp />
          </ChatProvider>
        </AuthProvider>
      </LanguageProvider>
    </ThemeProvider>
  );
}
