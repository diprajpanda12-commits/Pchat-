import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Automatically reload on dynamic import chunk mismatch across app updates
if (typeof window !== 'undefined') {
  window.addEventListener('vite:preloadError', (event) => {
    console.warn('Chunk preload error detected, refreshing page for latest bundle...', event);
    window.location.reload();
  });
}

// Service worker registration & cache self-healing
if ('serviceWorker' in navigator && process.env.NODE_ENV === 'production') {
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register('/sw.js')
      .then((reg) => {
        reg.update();
      })
      .catch((err) => {
        console.warn('SW registration notice:', err);
      });
  });
}

interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class RootErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.warn('PChat Root Error caught:', error, errorInfo);
  }

  handleCleanReload = async () => {
    try {
      if (typeof window !== 'undefined') {
        localStorage.removeItem('pchat_token');
        localStorage.removeItem('pchat_last_active_conv');
        sessionStorage.clear();
        if ('caches' in window) {
          const keys = await caches.keys();
          await Promise.all(keys.map((k) => caches.delete(k)));
        }
        if ('serviceWorker' in navigator) {
          const regs = await navigator.serviceWorker.getRegistrations();
          await Promise.all(regs.map((r) => r.unregister()));
        }
      }
    } catch {
      // ignore
    }
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-center text-white select-none">
          <div className="w-20 h-20 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center mb-4 shadow-xl">
            <span className="text-3xl">🐼</span>
          </div>
          <h1 className="text-xl font-bold text-white mb-2">Welcome to PChat</h1>
          <p className="text-xs text-slate-400 max-w-sm mb-6 leading-relaxed">
            The application detected an updated version. Click below to load the latest live chat interface.
          </p>
          <button
            type="button"
            onClick={this.handleCleanReload}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs shadow-lg transition cursor-pointer"
          >
            Launch PChat
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

const rootElem = document.getElementById('root');
if (rootElem) {
  createRoot(rootElem).render(
    <RootErrorBoundary>
      <App />
    </RootErrorBoundary>
  );
}
