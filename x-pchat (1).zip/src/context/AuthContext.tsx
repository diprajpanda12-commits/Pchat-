import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

export interface UserProfile {
  id: string;
  username: string;
  email: string;
  display_name: string;
  bio: string;
  avatar_url: string;
  is_online: boolean;
  last_seen: string;
  created_at: string;
}

interface AuthContextType {
  user: UserProfile | null;
  token: string | null;
  isLoading: boolean;
  login: (username: string, password: string, easyLogin?: boolean, avatarUrl?: string, displayName?: string) => Promise<{ success: boolean; user?: UserProfile; error?: string }>;
  register: (username: string, email: string, password: string, displayName?: string) => Promise<{ success: boolean; user?: UserProfile; error?: string }>;
  logout: () => Promise<void>;
  updateProfile: (updates: { display_name?: string; bio?: string; avatar_url?: string; current_password?: string; new_password?: string }) => Promise<{ success: boolean; error?: string }>;
  deleteAccount: () => Promise<{ success: boolean; error?: string }>;
  fastSwitchTo: (username: string) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('pchat_token'));
  const [isLoading, setIsLoading] = useState(true);

  const fetchCurrentUser = useCallback(async (authToken?: string, retryCount = 0) => {
    try {
      const headers: Record<string, string> = {};
      if (authToken) {
        headers['Authorization'] = `Bearer ${authToken}`;
      }

      const res = await fetch('/api/auth/me/', {
        headers,
        credentials: 'include',
      });

      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        if (data.token) {
          localStorage.setItem('pchat_token', data.token);
          setToken(data.token);
        }
      } else if (res.status === 401) {
        localStorage.removeItem('pchat_token');
        setToken(null);
        setUser(null);
      } else if (res.status >= 500 && retryCount < 2) {
        // Cold start or temporary server glitch: retry before giving up
        setTimeout(() => {
          fetchCurrentUser(authToken, retryCount + 1);
        }, 1500 * (retryCount + 1));
        return;
      }
    } catch (err) {
      console.warn('Network issue connecting to auth service:', err);
      if (retryCount < 2) {
        setTimeout(() => {
          fetchCurrentUser(authToken, retryCount + 1);
        }, 1500 * (retryCount + 1));
        return;
      }
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    // Attempt authentication via token in localStorage OR existing HTTP-only cookie
    fetchCurrentUser(token || undefined);
  }, [token, fetchCurrentUser]);

  const login = async (
    username: string,
    password: string,
    easyLogin: boolean = true,
    avatarUrl?: string,
    displayName?: string
  ) => {
    try {
      const res = await fetch('/api/auth/login/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          username,
          password,
          easy_login: easyLogin,
          avatar_url: avatarUrl,
          display_name: displayName,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Login failed.' };
      }
      localStorage.setItem('pchat_token', data.token);
      setToken(data.token);
      setUser(data.user);
      return { success: true, user: data.user };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error during login.' };
    }
  };

  const register = async (username: string, email: string, password: string, displayName?: string) => {
    try {
      const res = await fetch('/api/auth/register/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          username,
          email,
          password,
          display_name: displayName,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Registration failed.' };
      }
      localStorage.setItem('pchat_token', data.token);
      setToken(data.token);
      setUser(data.user);
      return { success: true, user: data.user };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error during registration.' };
    }
  };

  const logout = async () => {
    if (token) {
      try {
        await fetch('/api/auth/logout/', {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
          credentials: 'include',
        });
      } catch (err) {
        console.error('Logout error:', err);
      }
    }
    localStorage.removeItem('pchat_token');
    setToken(null);
    setUser(null);
  };

  const updateProfile = async (updates: any) => {
    if (!token) return { success: false, error: 'Not authenticated.' };
    try {
      const res = await fetch('/api/profile/', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(updates),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Update failed.' };
      }
      setUser(data.user);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error.' };
    }
  };

  const deleteAccount = async (): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch('/api/profile/', {
        method: 'DELETE',
        headers: {
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        credentials: 'include',
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Failed to delete account.' };
      }
      localStorage.removeItem('pchat_token');
      try {
        const stored = localStorage.getItem('pchat_saved_accounts');
        if (stored && user?.username) {
          const parsed = JSON.parse(stored);
          const filtered = parsed.filter((a: any) => a.username !== user.username);
          localStorage.setItem('pchat_saved_accounts', JSON.stringify(filtered));
        }
      } catch {}
      setToken(null);
      setUser(null);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error.' };
    }
  };

  // Quick switcher for instant multi-user testing
  const fastSwitchTo = async (username: string) => {
    return (await login(username, 'Panda@123')).success;
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isLoading,
        login,
        register,
        logout,
        updateProfile,
        deleteAccount,
        fastSwitchTo,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
