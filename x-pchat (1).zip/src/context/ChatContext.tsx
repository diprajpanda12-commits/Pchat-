import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import { useAuth } from './AuthContext.js';
import {
  saveMessagesToLocalDB,
  getMessagesFromLocalDB,
  queuePendingMessage,
  removePendingMessage,
  getAllPendingMessages,
  mergeMessageLists,
  updateLocalMessage,
  saveConversationsToLocalDB,
  getConversationsFromLocalDB,
} from '../utils/localDB.js';

export interface MessageSender {
  id: string;
  username: string;
  display_name: string;
  avatar_url: string;
}

export interface MessageItem {
  id: string;
  conversation_id: string;
  sender_id: string;
  text: string;
  reply_to_id: string | null;
  parent_message_id?: string | null;
  status: 'pending' | 'sent' | 'delivered' | 'read';
  is_edited: boolean;
  is_deleted: boolean;
  created_at: string;
  updated_at: string;
  reactions?: Record<string, string[]>;
  audio_url?: string | null;
  audio_duration?: number | null;
  image_url?: string | null;
  sender?: MessageSender;
  reply_to?: MessageItem | null;
  parent_message?: MessageItem | null;
  client_temp_id?: string | null;
}

export interface ConversationMember {
  id: string;
  role: 'admin' | 'member';
  joined_at: string;
  username: string;
  display_name: string;
  avatar_url: string;
  is_online: boolean;
  last_seen: string;
}

export interface ConversationItem {
  id: string;
  type: 'direct' | 'group';
  title: string;
  avatar_url: string;
  created_by: string;
  created_at: string;
  updated_at: string;
  members: ConversationMember[];
  last_message: MessageItem | null;
  unread_count: number;
  is_muted?: boolean;
  recipient: {
    id: string;
    username: string;
    display_name: string;
    avatar_url: string;
    is_online: boolean;
    last_seen: string;
  } | null;
}

export interface InAppToastItem {
  id: string;
  conversation_id: string;
  title: string;
  body: string;
  avatar_url?: string;
  sender_name?: string;
}

export interface ScheduledMessageItem {
  id: string;
  conversation_id: string;
  sender_id: string;
  text: string;
  reply_to_id: string | null;
  parent_message_id?: string | null;
  scheduled_for: string;
  created_at: string;
  status: 'pending' | 'sent' | 'cancelled';
}

interface ChatContextType {
  conversations: ConversationItem[];
  activeConversation: ConversationItem | null;
  messages: MessageItem[];
  scheduledMessages: ScheduledMessageItem[];
  connectionStatus: 'connected' | 'connecting' | 'disconnected';
  typingUsers: string[];
  typingUsersMap: Record<string, { [uid: string]: string }>;
  isLoadingMessages: boolean;
  hasMoreMessages: boolean;
  loadOlderMessages: () => Promise<boolean>;
  retryPendingMessages: () => Promise<void>;
  totalUnreadCount: number;
  soundEnabled: boolean;
  toggleSound: () => void;
  vibrationEnabled: boolean;
  toggleVibration: () => void;
  toggleMuteConversation: (conversationId: string) => Promise<boolean>;
  inAppToast: InAppToastItem | null;
  dismissInAppToast: () => void;
  pushSupported: boolean;
  pushSubscribed: boolean;
  pushPermission: NotificationPermission;
  subscribeToPush: () => Promise<boolean>;
  unsubscribeFromPush: () => Promise<boolean>;
  sendTestPush: () => Promise<boolean>;
  selectConversation: (id: string | null) => void;
  sendMessage: (text: string, replyToId?: string | null, parentMessageId?: string | null) => Promise<boolean>;
  sendAudioMessage: (audioBlob: Blob, durationSeconds: number, replyToId?: string | null, parentMessageId?: string | null) => Promise<boolean>;
  sendImageMessage: (imageDataUrl: string, caption?: string, replyToId?: string | null, parentMessageId?: string | null) => Promise<boolean>;
  scheduleMessage: (text: string, scheduledForIso: string, replyToId?: string | null, parentMessageId?: string | null) => Promise<boolean>;
  cancelScheduledMessage: (id: string) => Promise<boolean>;
  loadScheduledMessages: (convId: string) => Promise<void>;
  addReaction: (messageId: string, emoji: string) => Promise<boolean>;
  editMessage: (messageId: string, newText: string) => Promise<boolean>;
  deleteMessage: (messageId: string) => Promise<boolean>;
  markConversationAsRead: (conversationId: string) => void;
  createDirectChat: (recipientId: string) => Promise<string | null>;
  createGroupChat: (title: string, avatarUrl: string, memberIds: string[]) => Promise<string | null>;
  sendTypingSignal: (isTyping: boolean) => void;
  refreshConversations: () => Promise<void>;
  currentPingMs: number | null;
  sendPing: () => Promise<number>;
  addMemberToGroup: (conversationId: string, userId: string) => Promise<boolean>;
  removeMemberFromGroup: (conversationId: string, userId: string) => Promise<boolean>;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

// Web Audio synthesizer for pleasant notification chime
function playNotificationChime() {
  if (typeof window !== 'undefined' && localStorage.getItem('pchat_sound_enabled') === 'false') {
    return;
  }
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
    osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.12); // A5

    gain.gain.setValueAtTime(0.08, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.26);
  } catch (e) {
    // AudioContext blocked by browser policy until interaction
  }
}

function triggerNotificationVibration() {
  if (typeof window !== 'undefined' && localStorage.getItem('pchat_vibration_enabled') === 'false') {
    return;
  }
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate([200, 100, 200]);
    } catch (_e) {
      // Vibration not permitted or not supported on this device
    }
  }
}

function urlBase64ToUint8Array(base64String: string) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/\-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, token, isLoading: isAuthLoading } = useAuth();
  const [conversations, setConversations] = useState<ConversationItem[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('pchat_last_active_conv');
    }
    return null;
  });
  const [messages, setMessages] = useState<MessageItem[]>([]);
  const [scheduledMessages, setScheduledMessages] = useState<ScheduledMessageItem[]>([]);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'connecting' | 'disconnected'>('disconnected');
  const [typingUsersMap, setTypingUsersMap] = useState<Record<string, { [uid: string]: string }>>({});
  const [currentPingMs, setCurrentPingMs] = useState<number | null>(null);

  const wsRef = useRef<WebSocket | null>(null);
  const typingTimeoutRef = useRef<any>(null);
  const pendingPingResolveRef = useRef<((latency: number) => void) | null>(null);
  const wasDisconnectedRef = useRef<boolean>(false);
  const reconnectAttemptsRef = useRef<number>(0);
  const reconnectTimerRef = useRef<any>(null);
  const heartbeatTimerRef = useRef<any>(null);
  const activeConversationIdRef = useRef<string | null>(activeConversationId);
  const tokenRef = useRef<string | null>(token);
  const userRef = useRef<any>(user);

  useEffect(() => {
    activeConversationIdRef.current = activeConversationId;
  }, [activeConversationId]);

  useEffect(() => {
    tokenRef.current = token;
    userRef.current = user;
  }, [token, user]);

  // 0ms instant offline cache hydration from IndexedDB
  useEffect(() => {
    getConversationsFromLocalDB()
      .then((cached) => {
        if (cached && cached.length > 0) {
          setConversations((prev) => (prev.length === 0 ? cached : prev));
        }
      })
      .catch((e) => console.warn('[PChat IndexedDB] Initial conversations load notice:', e));
  }, []);

  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('pchat_sound_enabled') !== 'false';
    }
    return true;
  });

  const toggleSound = useCallback(() => {
    setSoundEnabled((prev) => {
      const next = !prev;
      if (typeof window !== 'undefined') {
        localStorage.setItem('pchat_sound_enabled', String(next));
      }
      return next;
    });
  }, []);

  const conversationsRef = useRef<ConversationItem[]>(conversations);
  const recentSentMessagesRef = useRef<Map<string, number>>(new Map());
  useEffect(() => {
    conversationsRef.current = conversations;
  }, [conversations]);

  const [vibrationEnabled, setVibrationEnabled] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('pchat_vibration_enabled') !== 'false';
    }
    return true;
  });

  const toggleVibration = useCallback(() => {
    setVibrationEnabled((prev) => {
      const next = !prev;
      if (typeof window !== 'undefined') {
        localStorage.setItem('pchat_vibration_enabled', String(next));
      }
      return next;
    });
  }, []);

  const [inAppToast, setInAppToast] = useState<InAppToastItem | null>(null);
  const dismissInAppToast = useCallback(() => {
    setInAppToast(null);
  }, []);

  useEffect(() => {
    if (inAppToast) {
      const timer = setTimeout(() => {
        setInAppToast(null);
      }, 5500);
      return () => clearTimeout(timer);
    }
  }, [inAppToast]);

  const [pushSupported, setPushSupported] = useState<boolean>(false);
  const [pushSubscribed, setPushSubscribed] = useState<boolean>(false);
  const [pushPermission, setPushPermission] = useState<NotificationPermission>('default');

  useEffect(() => {
    if (typeof window !== 'undefined' && 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window) {
      setPushSupported(true);
      setPushPermission(Notification.permission);

      navigator.serviceWorker.ready.then((reg) => {
        reg.pushManager.getSubscription().then((sub) => {
          setPushSubscribed(!!sub);
        });
      }).catch((e) => console.warn('Push manager check note:', e));
    }
  }, [user]);

  const subscribeToPush = useCallback(async (): Promise<boolean> => {
    const curToken = tokenRef.current;
    if (!curToken || !pushSupported) return false;
    try {
      const permission = await Notification.requestPermission();
      setPushPermission(permission);
      if (permission !== 'granted') return false;

      const keyRes = await fetch('/api/push/vapid-key/', {
        headers: { Authorization: `Bearer ${curToken}` },
      });
      if (!keyRes.ok) return false;
      const { publicKey } = await keyRes.json();
      if (!publicKey) return false;

      const reg = await navigator.serviceWorker.ready;
      let sub = await reg.pushManager.getSubscription();
      if (!sub) {
        const applicationServerKey = urlBase64ToUint8Array(publicKey);
        sub = await reg.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey,
        });
      }

      const saveRes = await fetch('/api/push/subscribe/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${curToken}`,
        },
        body: JSON.stringify({ subscription: sub.toJSON() }),
      });

      if (saveRes.ok) {
        setPushSubscribed(true);
        return true;
      }
      return false;
    } catch (err) {
      console.warn('Push subscription failed:', err);
      return false;
    }
  }, [pushSupported]);

  const unsubscribeFromPush = useCallback(async (): Promise<boolean> => {
    const curToken = tokenRef.current;
    if (!curToken) return false;
    try {
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.getSubscription();
      if (sub) {
        const endpoint = sub.endpoint;
        await sub.unsubscribe();
        await fetch('/api/push/unsubscribe/', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${curToken}`,
          },
          body: JSON.stringify({ endpoint }),
        });
      }
      setPushSubscribed(false);
      return true;
    } catch (err) {
      console.warn('Push unsubscribe error:', err);
      return false;
    }
  }, []);

  const sendTestPush = useCallback(async (): Promise<boolean> => {
    const curToken = tokenRef.current;
    if (!curToken) return false;
    try {
      const res = await fetch('/api/push/test/', {
        method: 'POST',
        headers: { Authorization: `Bearer ${curToken}` },
      });
      return res.ok;
    } catch (err) {
      console.warn('Send test push error:', err);
      return false;
    }
  }, []);

  const markConversationAsRead = useCallback(async (convId: string) => {
    const curToken = tokenRef.current;
    if (!curToken || !convId) return;
    setConversations((prev) =>
      prev.map((c) => (c.id === convId ? { ...c, unread_count: 0 } : c))
    );
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      try {
        ws.send(JSON.stringify({
          type: 'message:read',
          conversation_id: convId,
        }));
      } catch {}
    }
    try {
      await fetch(`/api/conversations/${convId}/read/`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${curToken}` },
      });
    } catch (err) {
      console.warn('markConversationAsRead error:', err);
    }
  }, []);

  const toggleMuteConversation = useCallback(async (convId: string): Promise<boolean> => {
    const curToken = tokenRef.current;
    if (!curToken) return false;
    const currentConv = conversationsRef.current.find((c) => c.id === convId);
    const targetMuted = !currentConv?.is_muted;
    // Optimistic local update
    setConversations((prev) =>
      prev.map((c) => (c.id === convId ? { ...c, is_muted: targetMuted } : c))
    );
    try {
      const res = await fetch(`/api/conversations/${convId}/mute/`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${curToken}`,
        },
        body: JSON.stringify({ is_muted: targetMuted }),
      });
      if (res.ok) {
        return true;
      }
    } catch (err) {
      console.warn('toggleMute error:', err);
    }
    // Rollback if request failed
    setConversations((prev) =>
      prev.map((c) => (c.id === convId ? { ...c, is_muted: !targetMuted } : c))
    );
    return false;
  }, []);

  const selectConversation = useCallback((id: string | null) => {
    setActiveConversationId(id);
    if (id) {
      if (typeof window !== 'undefined') {
        localStorage.setItem('pchat_last_active_conv', id);
      }
      setConversations((prev) =>
        prev.map((c) => (c.id === id ? { ...c, unread_count: 0 } : c))
      );
      markConversationAsRead(id);
      setInAppToast((prev) => (prev?.conversation_id === id ? null : prev));
    } else {
      if (typeof window !== 'undefined') {
        localStorage.removeItem('pchat_last_active_conv');
      }
    }
  }, [markConversationAsRead]);

  // Handle push notification click when focused or resumed
  useEffect(() => {
    const handleSwMessage = (e: MessageEvent) => {
      if (e.data?.type === 'NAVIGATE_CONVERSATION' && e.data?.conversation_id) {
        selectConversation(e.data.conversation_id);
      }
    };
    if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
      navigator.serviceWorker.addEventListener('message', handleSwMessage);
      return () => navigator.serviceWorker.removeEventListener('message', handleSwMessage);
    }
  }, [selectConversation]);

  // Handle ?conv= URL param on initial load
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const convParam = params.get('conv');
      if (convParam) {
        selectConversation(convParam);
        window.history.replaceState({}, '', window.location.pathname);
      }
    }
  }, [selectConversation]);

  const totalUnreadCount = conversations.reduce((acc, c) => acc + (c.unread_count || 0), 0);

  // Sync document title with unread counter for a real-life messenger experience
  useEffect(() => {
    if (typeof document !== 'undefined') {
      if (totalUnreadCount > 0) {
        document.title = `(${totalUnreadCount}) PChat - Panda Chat`;
      } else {
        document.title = 'PChat - Panda Chat';
      }
    }
  }, [totalUnreadCount]);

  const typingTimeoutsRef = useRef<Record<string, any>>({});

  // Load conversations list with resilience to network glitches
  const refreshConversations = useCallback(async (retryCount = 0) => {
    if (!token || !user) return;
    try {
      const res = await fetch('/api/conversations/', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        const convList: ConversationItem[] = data.conversations || [];
        setConversations(convList);
        saveConversationsToLocalDB(convList);

        // Auto restore previous active conversation on initial load or desktop view
        if (convList.length > 0) {
          const storedConvId = typeof window !== 'undefined' ? localStorage.getItem('pchat_last_active_conv') : null;
          setActiveConversationId((currentActive) => {
            if (currentActive && convList.some((c) => c.id === currentActive)) {
              return currentActive;
            }
            if (storedConvId && convList.some((c) => c.id === storedConvId)) {
              return storedConvId;
            }
            // If on desktop screen, default to first conversation
            if (typeof window !== 'undefined' && window.innerWidth >= 768) {
              return convList[0].id;
            }
            return currentActive || null;
          });
        }
      }
    } catch (err) {
      // Graceful backoff retry if server is temporarily starting up
      if (retryCount < 2) {
        setTimeout(() => {
          refreshConversations(retryCount + 1);
        }, 1200 * (retryCount + 1));
      }
    }
  }, [token, user]);

  useEffect(() => {
    if (token && user) {
      refreshConversations();
    } else if (!isAuthLoading && !token) {
      // Only reset when auth is fully resolved and user is definitely unauthenticated
      setConversations([]);
      setActiveConversationId(null);
      setMessages([]);
    }
  }, [token, user, isAuthLoading, refreshConversations]);

  const loadMessagesSeqRef = useRef<number>(0);
  const [hasMoreMessages, setHasMoreMessages] = useState<boolean>(false);

  // Synchronize any messages missed during WebSocket downtime or app backgrounding
  const syncMissedMessages = useCallback(async (convId: string, retryCount = 0) => {
    const currentToken = tokenRef.current;
    if (!currentToken || !userRef.current || !convId) return;

    try {
      const res = await fetch(`/api/conversations/${convId}/messages/?limit=100`, {
        headers: { Authorization: `Bearer ${currentToken}` },
      });
      if (res.ok) {
        const data = await res.json();
        const serverMessages: MessageItem[] = data.messages || [];

        if (convId === activeConversationIdRef.current) {
          setMessages((prevMessages) => {
            const merged = mergeMessageLists(prevMessages, serverMessages);
            saveMessagesToLocalDB(merged);
            return merged;
          });
        } else {
          saveMessagesToLocalDB(serverMessages);
        }

        // Mark as read locally in conversation preview
        setConversations((prev) =>
          prev.map((c) => (c.id === convId ? { ...c, unread_count: 0 } : c))
        );
      } else if (res.status >= 500 && retryCount < 2) {
        setTimeout(() => syncMissedMessages(convId, retryCount + 1), 1000);
      }
    } catch (err) {
      console.warn('Sync missed messages fetch error:', err);
      if (retryCount < 2) {
        setTimeout(() => syncMissedMessages(convId, retryCount + 1), 1200);
      }
    }
  }, []);

  // Flush and retry all offline queued messages in IndexedDB
  const retryPendingMessages = useCallback(async () => {
    const curToken = tokenRef.current;
    if (!curToken) return;
    try {
      const pending = await getAllPendingMessages();
      if (!pending || pending.length === 0) return;

      for (const p of pending) {
        try {
          const res = await fetch(`/api/conversations/${p.conversation_id}/messages/`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${curToken}`,
            },
            body: JSON.stringify({
              text: p.text,
              reply_to_id: p.reply_to_id,
              parent_message_id: p.parent_message_id,
              audio_url: p.audio_url || undefined,
              audio_duration: p.audio_duration || undefined,
              client_temp_id: p.client_temp_id,
            }),
          });
          if (res.ok) {
            const data = await res.json();
            await removePendingMessage(p.client_temp_id);
            setMessages((prev) => {
              const updated = prev.map((m) =>
                m.id === p.client_temp_id || m.client_temp_id === p.client_temp_id
                  ? { ...data.message, client_temp_id: p.client_temp_id }
                  : m
              );
              saveMessagesToLocalDB(updated);
              return updated;
            });
          }
        } catch (err) {
          console.warn('[PChat] Pending message retry attempt failed:', err);
        }
      }
      refreshConversations();
    } catch (err) {
      console.warn('[PChat] retryPendingMessages error:', err);
    }
  }, [refreshConversations]);

  // Listen for browser online, visibility change, and tab focus events to re-establish connection and catch up on missed messages
  useEffect(() => {
    const handleOnline = () => {
      if (tokenRef.current && userRef.current) {
        reconnectAttemptsRef.current = 0;
        if (reconnectTimerRef.current) {
          clearTimeout(reconnectTimerRef.current);
          reconnectTimerRef.current = null;
        }
        const curConv = activeConversationIdRef.current;
        if (curConv) {
          syncMissedMessages(curConv);
        }
        refreshConversations();
        retryPendingMessages();
      }
    };

    const handleOffline = () => {
      setConnectionStatus('disconnected');
      wasDisconnectedRef.current = true;
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible' && tokenRef.current && userRef.current) {
        const curConv = activeConversationIdRef.current;
        if (curConv) {
          syncMissedMessages(curConv);
        }
        refreshConversations();
        retryPendingMessages();
      }
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('focus', handleVisibilityChange);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('focus', handleVisibilityChange);
    };
  }, [refreshConversations, syncMissedMessages, retryPendingMessages]);

  // Load saved messages from local IndexedDB first, then synchronize with authoritative server database
  const loadMessages = useCallback(async (convId: string, retryCount = 0) => {
    if (!convId) return;
    const seq = ++loadMessagesSeqRef.current;
    setIsLoadingMessages(true);

    // 1. Instant local read from IndexedDB for 0ms offline display
    try {
      const cached = await getMessagesFromLocalDB(convId);
      if (seq === loadMessagesSeqRef.current && convId === activeConversationIdRef.current) {
        if (cached && cached.length > 0) {
          setMessages(cached);
        }
      }
    } catch (dbErr) {
      console.warn('[PChat] Local cache read notice:', dbErr);
    }

    const curToken = tokenRef.current;
    if (!curToken) {
      setIsLoadingMessages(false);
      return;
    }

    // 2. Authoritative network fetch from server
    try {
      const res = await fetch(`/api/conversations/${convId}/messages/?limit=100`, {
        headers: { Authorization: `Bearer ${curToken}` },
      });
      if (res.ok) {
        const data = await res.json();
        const serverMessages: MessageItem[] = data.messages || [];
        setHasMoreMessages(Boolean(data.pagination?.has_more));

        if (seq === loadMessagesSeqRef.current && convId === activeConversationIdRef.current) {
          setMessages((currentMessages) => {
            const merged = mergeMessageLists(currentMessages, serverMessages);
            saveMessagesToLocalDB(merged);
            return merged;
          });

          // Mark as read locally in conversations list without triggering full reload loop
          setConversations((prev) =>
            prev.map((c) => (c.id === convId ? { ...c, unread_count: 0 } : c))
          );
        }
      } else if (res.status >= 500 && retryCount < 2) {
        setTimeout(() => {
          if (seq === loadMessagesSeqRef.current) {
            loadMessages(convId, retryCount + 1);
          }
        }, 1000);
      }
    } catch (err) {
      console.warn('[PChat] Messages fetch waiting for active connection:', err);
      if (retryCount < 2) {
        setTimeout(() => {
          if (seq === loadMessagesSeqRef.current) {
            loadMessages(convId, retryCount + 1);
          }
        }, 1000);
      }
    } finally {
      if (seq === loadMessagesSeqRef.current) {
        setIsLoadingMessages(false);
      }
    }
  }, []);

  // Paginated load older messages from server
  const loadOlderMessages = useCallback(async (): Promise<boolean> => {
    const curConv = activeConversationIdRef.current;
    const curToken = tokenRef.current;
    if (!curConv || !curToken || !hasMoreMessages || messages.length === 0) return false;

    const oldestId = messages[0]?.id;
    if (!oldestId) return false;

    try {
      const res = await fetch(`/api/conversations/${curConv}/messages/?limit=50&before_id=${oldestId}`, {
        headers: { Authorization: `Bearer ${curToken}` },
      });
      if (res.ok) {
        const data = await res.json();
        const olderMsgs: MessageItem[] = data.messages || [];
        setHasMoreMessages(Boolean(data.pagination?.has_more));

        if (olderMsgs.length > 0 && curConv === activeConversationIdRef.current) {
          setMessages((prev) => {
            const merged = mergeMessageLists(olderMsgs, prev);
            saveMessagesToLocalDB(merged);
            return merged;
          });
          return true;
        }
      }
    } catch (err) {
      console.warn('[PChat] loadOlderMessages error:', err);
    }
    return false;
  }, [hasMoreMessages, messages]);

  // Fetch scheduled messages for the conversation
  const loadScheduledMessages = useCallback(async (convId: string) => {
    const curToken = tokenRef.current;
    if (!curToken || !userRef.current) return;
    try {
      const res = await fetch(`/api/conversations/${convId}/messages/scheduled/`, {
        headers: { Authorization: `Bearer ${curToken}` },
      });
      if (res.ok) {
        const data = await res.json();
        setScheduledMessages(data.scheduled_messages || []);
      }
    } catch (err) {
      console.warn('Error loading scheduled messages:', err);
    }
  }, []);

  const scheduleMessage = useCallback(async (
    text: string,
    scheduledForIso: string,
    replyToId: string | null = null,
    parentMessageId: string | null = null
  ): Promise<boolean> => {
    const curToken = tokenRef.current;
    const curConv = activeConversationIdRef.current;
    if (!text.trim() || !curConv || !curToken) return false;
    try {
      const parentId = parentMessageId || replyToId;
      const res = await fetch(`/api/conversations/${curConv}/messages/schedule/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${curToken}`,
        },
        body: JSON.stringify({
          text: text.trim(),
          scheduled_for: scheduledForIso,
          reply_to_id: parentId,
          parent_message_id: parentId,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.scheduled_message) {
          setScheduledMessages((prev) => [...prev, data.scheduled_message]);
        }
        return true;
      }
    } catch (err) {
      console.error('Failed to schedule message:', err);
    }
    return false;
  }, []);

  const cancelScheduledMessage = useCallback(async (id: string): Promise<boolean> => {
    const curToken = tokenRef.current;
    if (!curToken) return false;
    try {
      const res = await fetch(`/api/messages/scheduled/${id}/`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${curToken}` },
      });
      if (res.ok) {
        setScheduledMessages((prev) => prev.filter((sm) => sm.id !== id));
        return true;
      }
    } catch (err) {
      console.error('Failed to cancel scheduled message:', err);
    }
    return false;
  }, []);

  useEffect(() => {
    if (activeConversationId) {
      loadMessages(activeConversationId);
      loadScheduledMessages(activeConversationId);
    } else {
      setMessages([]);
      setScheduledMessages([]);
    }
  }, [activeConversationId, loadMessages, loadScheduledMessages]);

  // WebSocket Connection Management with auto-reconnect and missed messages sync
  useEffect(() => {
    if (!token || !user) {
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
      setConnectionStatus('disconnected');
      return;
    }

    let isSubscribed = true;

    const connectWebSocket = () => {
      if (!isSubscribed) return;
      setConnectionStatus('connecting');

      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const host = window.location.host;
      const wsUrl = activeConversationId
        ? `${protocol}//${host}/ws/chat/${activeConversationId}?token=${encodeURIComponent(token)}`
        : `${protocol}//${host}/ws/general?token=${encodeURIComponent(token)}`;

      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        if (!isSubscribed) return;
        setConnectionStatus('connected');
        reconnectAttemptsRef.current = 0; // Reset backoff counter

        // Trigger automatic catch-up fetch for missed messages on reconnect
        const currentConv = activeConversationIdRef.current;
        if (currentConv) {
          syncMissedMessages(currentConv);
        }
        refreshConversations();
        wasDisconnectedRef.current = false;
      };

      ws.onclose = () => {
        if (!isSubscribed) return;
        setConnectionStatus('disconnected');
        wasDisconnectedRef.current = true;

        // Exponential backoff with jitter (500ms min, 15000ms max, +/- 20% jitter)
        const attempts = reconnectAttemptsRef.current;
        const baseDelay = Math.min(1000 * Math.pow(1.5, attempts), 15000);
        const jitter = (Math.random() * 0.4 - 0.2) * baseDelay;
        const delay = Math.max(500, Math.round(baseDelay + jitter));

        reconnectAttemptsRef.current = attempts + 1;

        if (reconnectTimerRef.current) {
          clearTimeout(reconnectTimerRef.current);
        }
        reconnectTimerRef.current = setTimeout(() => {
          if (isSubscribed && tokenRef.current && userRef.current) {
            connectWebSocket();
          }
        }, delay);
      };

      ws.onerror = () => {
        if (!isSubscribed) return;
        setConnectionStatus('disconnected');
        wasDisconnectedRef.current = true;
      };

      ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);

        switch (data.type) {
          case 'message:new': {
            const incomingMsg: MessageItem = data.message;
            const convId = data.conversation_id;

            // Remove from local pending queue if we sent this
            if (incomingMsg.client_temp_id) {
              removePendingMessage(incomingMsg.client_temp_id);
            }
            saveMessagesToLocalDB([incomingMsg]);

            const targetConv = conversationsRef.current.find((c) => c.id === convId);
            const isMuted = targetConv?.is_muted === true;

            // If this message belongs to the active conversation
            if (activeConversationId === convId) {
              setMessages((prev) => {
                // Deduplicate Rule 1: Exact server ID exists
                if (prev.some((m) => m.id === incomingMsg.id)) {
                  return prev.map((m) => (m.id === incomingMsg.id ? { ...m, ...incomingMsg } : m));
                }

                // Deduplicate Rule 2: Reconcile optimistic temp ID
                if (incomingMsg.client_temp_id) {
                  const tempIdx = prev.findIndex(
                    (m) => m.id === incomingMsg.client_temp_id || m.client_temp_id === incomingMsg.client_temp_id
                  );
                  if (tempIdx !== -1) {
                    const next = [...prev];
                    next[tempIdx] = { ...incomingMsg, client_temp_id: incomingMsg.client_temp_id };
                    return next;
                  }
                }

                // Deduplicate Rule 3: Reconcile sender's in-flight pending message by content
                if (incomingMsg.sender_id === user.id) {
                  const matchPendingIdx = prev.findIndex(
                    (m) => m.status === 'pending' &&
                           m.text === incomingMsg.text &&
                           Math.abs(new Date(m.created_at).getTime() - new Date(incomingMsg.created_at).getTime()) < 12000
                  );
                  if (matchPendingIdx !== -1) {
                    const next = [...prev];
                    next[matchPendingIdx] = incomingMsg;
                    return next;
                  }
                }

                // Deduplicate Rule 4: Receiver double-broadcast guard (same sender + identical text within 2.5s)
                const isDupForReceiver = prev.some(
                  (m) => m.id === incomingMsg.id ||
                         (m.sender_id === incomingMsg.sender_id &&
                          m.text === incomingMsg.text &&
                          Math.abs(new Date(m.created_at).getTime() - new Date(incomingMsg.created_at).getTime()) < 2500)
                );
                if (isDupForReceiver) {
                  return prev;
                }

                return [...prev, incomingMsg];
              });

              // Send delivery & read acknowledgment back to server if sent by someone else
              if (incomingMsg.sender_id !== user.id && ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify({
                  type: 'message:delivered',
                  message_id: incomingMsg.id,
                  conversation_id: convId,
                }));
                ws.send(JSON.stringify({
                  type: 'message:read',
                  message_id: incomingMsg.id,
                  conversation_id: convId,
                }));
                if (!isMuted) {
                  playNotificationChime();
                  triggerNotificationVibration();
                }
              }
            } else {
              // Message in another conversation: chime, vibrate, show toast, and increment badge
              if (incomingMsg.sender_id !== user.id) {
                if (!isMuted) {
                  playNotificationChime();
                  triggerNotificationVibration();

                  const senderName = incomingMsg.sender?.display_name || 'Someone';
                  const title = targetConv?.type === 'group'
                    ? `${targetConv.title || '🎋 Group'} · ${senderName}`
                    : senderName;
                  const bodyPreview = incomingMsg.audio_url
                    ? '🎤 Voice message'
                    : (incomingMsg.text || 'New message');

                  setInAppToast({
                    id: incomingMsg.id,
                    conversation_id: convId,
                    title,
                    body: bodyPreview,
                    avatar_url: incomingMsg.sender?.avatar_url || '/avatars/panda-emerald.svg',
                    sender_name: senderName,
                  });

                  if (typeof Notification !== 'undefined' && Notification.permission === 'granted' && document.visibilityState !== 'visible') {
                    try {
                      new Notification(title, {
                        body: bodyPreview,
                        icon: '/pchat-logo.png',
                        badge: '/icon.svg',
                        tag: `pchat-${convId}`,
                      });
                    } catch (_e) {}
                  }
                }

                setConversations((prev) =>
                  prev.map((c) => {
                    if (c.id === convId) {
                      return {
                        ...c,
                        last_message: incomingMsg,
                        unread_count: (c.unread_count || 0) + 1,
                      };
                    }
                    return c;
                  })
                );
              }
            }

            // Update conversations list latest preview from server
            refreshConversations();
            break;
          }

          case 'message:delivered': {
            const { message_id, conversation_id } = data;
            setMessages((prev) =>
              prev.map((m) =>
                (m.id === message_id || (conversation_id && m.conversation_id === conversation_id)) && m.status === 'sent'
                  ? { ...m, status: 'delivered' }
                  : m
              )
            );
            updateLocalMessage(message_id, (m) => ({ ...m, status: 'delivered' }));
            break;
          }

          case 'message:read': {
            const { message_id, conversation_id } = data;
            setMessages((prev) =>
              prev.map((m) =>
                m.id === message_id || (conversation_id && m.conversation_id === conversation_id && m.status !== 'read')
                  ? { ...m, status: 'read' }
                  : m
              )
            );
            updateLocalMessage(message_id, (m) => ({ ...m, status: 'read' }));
            break;
          }

          case 'message:edited': {
            const { message_id, text, updated_at } = data;
            setMessages((prev) =>
              prev.map((m) =>
                m.id === message_id ? { ...m, text, is_edited: true, updated_at } : m
              )
            );
            updateLocalMessage(message_id, (m) => ({ ...m, text, is_edited: true, updated_at }));
            refreshConversations();
            break;
          }

          case 'message:deleted': {
            const { message_id } = data;
            setMessages((prev) =>
              prev.map((m) =>
                m.id === message_id
                  ? { ...m, is_deleted: true, text: 'This message was deleted' }
                  : m
              )
            );
            updateLocalMessage(message_id, (m) => ({ ...m, is_deleted: true, text: 'This message was deleted' }));
            refreshConversations();
            break;
          }

          case 'message:reaction': {
            const { message_id, reactions } = data;
            setMessages((prev) =>
              prev.map((m) =>
                m.id === message_id ? { ...m, reactions } : m
              )
            );
            updateLocalMessage(message_id, (m) => ({ ...m, reactions }));
            break;
          }

          case 'typing:status': {
            const { conversation_id, user_id, display_name, is_typing } = data;
            if (!user_id || user_id === user.id) break;

            const timerKey = `${conversation_id}_${user_id}`;
            if (typingTimeoutsRef.current[timerKey]) {
              clearTimeout(typingTimeoutsRef.current[timerKey]);
              delete typingTimeoutsRef.current[timerKey];
            }

            setTypingUsersMap((prev) => {
              const currentConv = { ...(prev[conversation_id] || {}) };
              if (is_typing) {
                currentConv[user_id] = display_name;
              } else {
                delete currentConv[user_id];
              }
              return { ...prev, [conversation_id]: currentConv };
            });

            // Auto-clear typing indicator after 3.5s in case typing:stop is lost
            if (is_typing) {
              typingTimeoutsRef.current[timerKey] = setTimeout(() => {
                setTypingUsersMap((prev) => {
                  const currentConv = { ...(prev[conversation_id] || {}) };
                  delete currentConv[user_id];
                  return { ...prev, [conversation_id]: currentConv };
                });
                delete typingTimeoutsRef.current[timerKey];
              }, 3500);
            }
            break;
          }

          case 'presence:status': {
            const { user_id, is_online } = data;
            setConversations((prev) =>
              prev.map((conv) => {
                let updatedRecipient = conv.recipient;
                if (conv.recipient && conv.recipient.id === user_id) {
                  updatedRecipient = { ...conv.recipient, is_online };
                }
                const updatedMembers = conv.members.map((m) =>
                  m.id === user_id ? { ...m, is_online } : m
                );
                return {
                  ...conv,
                  recipient: updatedRecipient,
                  members: updatedMembers,
                };
              })
            );
            break;
          }

          case 'conversation:update': {
            if (data.latest_payload) {
              if (data.latest_payload.type === 'typing:status') {
                const { conversation_id, user_id, display_name, is_typing } = data.latest_payload;
                if (user_id && user_id !== user.id) {
                  const timerKey = `${conversation_id}_${user_id}`;
                  if (typingTimeoutsRef.current[timerKey]) {
                    clearTimeout(typingTimeoutsRef.current[timerKey]);
                    delete typingTimeoutsRef.current[timerKey];
                  }

                  setTypingUsersMap((prev) => {
                    const currentConv = { ...(prev[conversation_id] || {}) };
                    if (is_typing) {
                      currentConv[user_id] = display_name;
                    } else {
                      delete currentConv[user_id];
                    }
                    return { ...prev, [conversation_id]: currentConv };
                  });

                  if (is_typing) {
                    typingTimeoutsRef.current[timerKey] = setTimeout(() => {
                      setTypingUsersMap((prev) => {
                        const currentConv = { ...(prev[conversation_id] || {}) };
                        delete currentConv[user_id];
                        return { ...prev, [conversation_id]: currentConv };
                      });
                      delete typingTimeoutsRef.current[timerKey];
                    }, 3500);
                  }
                }
              } else if (data.latest_payload.type === 'message:new') {
                const incomingMsg = data.latest_payload.message;
                const convId = data.conversation_id;
                if (incomingMsg && incomingMsg.sender_id !== user.id) {
                  playNotificationChime();
                  setConversations((prev) =>
                    prev.map((c) =>
                      c.id === convId
                        ? { ...c, last_message: incomingMsg, unread_count: (c.unread_count || 0) + 1 }
                        : c
                    )
                  );
                }
              }
            }
            refreshConversations();
            break;
          }

          case 'conversation:created': {
            const newConv = data.conversation;
            if (newConv) {
              setConversations((prev) => {
                if (prev.some((c) => c.id === newConv.id)) {
                  return prev.map((c) => (c.id === newConv.id ? newConv : c));
                }
                return [newConv, ...prev];
              });
              if (newConv.created_by !== user.id) {
                playNotificationChime();
              }
            }
            refreshConversations();
            break;
          }

          case 'scheduled:dispatched': {
            const { scheduled_id } = data;
            setScheduledMessages((prev) => prev.filter((sm) => sm.id !== scheduled_id));
            break;
          }

          case 'pong': {
            if (data.echoTimestamp) {
              const rtt = Date.now() - data.echoTimestamp;
              setCurrentPingMs(rtt);
              if (pendingPingResolveRef.current) {
                pendingPingResolveRef.current(rtt);
                pendingPingResolveRef.current = null;
              }
            }
            break;
          }

          default:
            break;
        }
      } catch (err) {
        console.warn('Error handling WebSocket message:', err);
      }
    };
  };

    connectWebSocket();

    if (heartbeatTimerRef.current) {
      clearInterval(heartbeatTimerRef.current);
    }
    heartbeatTimerRef.current = setInterval(() => {
      const ws = wsRef.current;
      if (ws && ws.readyState === WebSocket.OPEN) {
        try {
          ws.send(JSON.stringify({ type: 'ping', timestamp: Date.now() }));
        } catch {}
      } else if (ws && (ws.readyState === WebSocket.CLOSED || ws.readyState === WebSocket.CLOSING)) {
        if (!reconnectTimerRef.current && isSubscribed && tokenRef.current && userRef.current) {
          connectWebSocket();
        }
      }
    }, 25000);

    return () => {
      isSubscribed = false;
      if (reconnectTimerRef.current) {
        clearTimeout(reconnectTimerRef.current);
        reconnectTimerRef.current = null;
      }
      if (heartbeatTimerRef.current) {
        clearInterval(heartbeatTimerRef.current);
        heartbeatTimerRef.current = null;
      }
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
    };
  }, [token, user, activeConversationId, refreshConversations, syncMissedMessages]);

  // Send message with optimistic update & duplicate prevention
  const sendMessage = async (text: string, replyToId: string | null = null, parentMessageId: string | null = null): Promise<boolean> => {
    const cleanText = text.trim();
    if (!cleanText || !activeConversationId || !user) return false;

    // Check duplicate send guard within 1200ms
    const dedupKey = `${activeConversationId}:${cleanText}`;
    const nowMs = Date.now();
    const lastSentMs = recentSentMessagesRef.current.get(dedupKey);
    if (lastSentMs && nowMs - lastSentMs < 1200) {
      return true;
    }
    recentSentMessagesRef.current.set(dedupKey, nowMs);
    if (recentSentMessagesRef.current.size > 50) {
      for (const [k, t] of recentSentMessagesRef.current.entries()) {
        if (nowMs - t > 10000) recentSentMessagesRef.current.delete(k);
      }
    }

    const parentId = parentMessageId || replyToId;
    const tempId = `temp_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const now = new Date().toISOString();
    const parentMsg = parentId ? messages.find((m) => m.id === parentId) || null : null;

    const optimisticMsg: MessageItem = {
      id: tempId,
      conversation_id: activeConversationId,
      sender_id: user.id,
      text: cleanText,
      reply_to_id: parentId,
      parent_message_id: parentId,
      status: 'pending',
      is_edited: false,
      is_deleted: false,
      created_at: now,
      updated_at: now,
      sender: {
        id: user.id,
        username: user.username,
        display_name: user.display_name,
        avatar_url: user.avatar_url,
      },
      reply_to: parentMsg,
      parent_message: parentMsg,
      client_temp_id: tempId,
    };

    // Add optimistic message and persist to IndexedDB
    setMessages((prev) => [...prev, optimisticMsg]);
    saveMessagesToLocalDB([optimisticMsg]);
    queuePendingMessage({
      client_temp_id: tempId,
      conversation_id: activeConversationId,
      text: cleanText,
      reply_to_id: parentId,
      parent_message_id: parentId,
      created_at: now,
      retry_count: 0,
    });

    // Send via WebSocket if open
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({
        type: 'message:send',
        conversation_id: activeConversationId,
        text: cleanText,
        reply_to_id: parentId,
        parent_message_id: parentId,
        client_temp_id: tempId,
      }));
      return true;
    }

    // Fallback: HTTP POST /api/conversations/:id/messages/
    try {
      const res = await fetch(`/api/conversations/${activeConversationId}/messages/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          text: cleanText,
          reply_to_id: parentId,
          parent_message_id: parentId,
          client_temp_id: tempId,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const serverMsg: MessageItem = data.message;
        removePendingMessage(tempId);
        setMessages((prev) => {
          const next = prev.map((m) => (m.id === tempId ? { ...serverMsg, client_temp_id: tempId } : m));
          saveMessagesToLocalDB(next);
          return next;
        });
        refreshConversations();
        return true;
      }
    } catch (err) {
      console.warn('HTTP Send failed (queued in IndexedDB):', err);
    }
    return false;
  };

  const sendAudioMessage = async (audioBlob: Blob, durationSeconds: number, replyToId: string | null = null, parentMessageId: string | null = null): Promise<boolean> => {
    if (!activeConversationId || !user) return false;
    try {
      const parentId = parentMessageId || replyToId;
      const base64Audio = await blobToBase64(audioBlob);
      const roundedDuration = Math.round(durationSeconds) || 1;
      const tempId = `temp_voice_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const now = new Date().toISOString();
      const parentMsg = parentId ? messages.find((m) => m.id === parentId) || null : null;

      const optimisticMsg: MessageItem = {
        id: tempId,
        conversation_id: activeConversationId,
        sender_id: user.id,
        text: '🎤 Voice message',
        reply_to_id: parentId,
        parent_message_id: parentId,
        status: 'pending',
        is_edited: false,
        is_deleted: false,
        created_at: now,
        updated_at: now,
        audio_url: base64Audio,
        audio_duration: roundedDuration,
        reactions: {},
        sender: {
          id: user.id,
          username: user.username,
          display_name: user.display_name,
          avatar_url: user.avatar_url,
        },
        reply_to: parentMsg,
        parent_message: parentMsg,
        client_temp_id: tempId,
      };

      setMessages((prev) => [...prev, optimisticMsg]);
      saveMessagesToLocalDB([optimisticMsg]);
      queuePendingMessage({
        client_temp_id: tempId,
        conversation_id: activeConversationId,
        text: '🎤 Voice message',
        reply_to_id: parentId,
        parent_message_id: parentId,
        audio_url: base64Audio,
        audio_duration: roundedDuration,
        created_at: now,
        retry_count: 0,
      });

      const ws = wsRef.current;
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
          type: 'message:send',
          conversation_id: activeConversationId,
          text: '🎤 Voice message',
          reply_to_id: parentId,
          parent_message_id: parentId,
          audio_url: base64Audio,
          audio_duration: roundedDuration,
          client_temp_id: tempId,
        }));
        return true;
      }

      const res = await fetch(`/api/conversations/${activeConversationId}/messages/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          text: '🎤 Voice message',
          reply_to_id: parentId,
          parent_message_id: parentId,
          audio_url: base64Audio,
          audio_duration: roundedDuration,
          client_temp_id: tempId,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const serverMsg: MessageItem = data.message;
        removePendingMessage(tempId);
        setMessages((prev) => {
          const next = prev.map((m) => (m.id === tempId ? { ...serverMsg, client_temp_id: tempId } : m));
          saveMessagesToLocalDB(next);
          return next;
        });
        refreshConversations();
        return true;
      }
    } catch (err) {
      console.warn('Failed to send audio message (queued in IndexedDB):', err);
    }
    return false;
  };

  const sendImageMessage = async (
    imageDataUrl: string,
    caption?: string,
    replyToId: string | null = null,
    parentMessageId: string | null = null
  ): Promise<boolean> => {
    if (!activeConversationId || !user) return false;
    try {
      const parentId = parentMessageId || replyToId;
      const cleanCaption = caption && caption.trim() ? caption.trim() : '';
      const effectiveText = cleanCaption || '📷 Photo';
      const tempId = `temp_img_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const now = new Date().toISOString();
      const parentMsg = parentId ? messages.find((m) => m.id === parentId) || null : null;

      const optimisticMsg: MessageItem = {
        id: tempId,
        conversation_id: activeConversationId,
        sender_id: user.id,
        text: effectiveText,
        reply_to_id: parentId,
        parent_message_id: parentId,
        status: 'pending',
        is_edited: false,
        is_deleted: false,
        created_at: now,
        updated_at: now,
        image_url: imageDataUrl,
        reactions: {},
        sender: {
          id: user.id,
          username: user.username,
          display_name: user.display_name,
          avatar_url: user.avatar_url,
        },
        reply_to: parentMsg,
        parent_message: parentMsg,
        client_temp_id: tempId,
      };

      setMessages((prev) => [...prev, optimisticMsg]);
      saveMessagesToLocalDB([optimisticMsg]);
      queuePendingMessage({
        client_temp_id: tempId,
        conversation_id: activeConversationId,
        text: effectiveText,
        reply_to_id: parentId,
        parent_message_id: parentId,
        image_url: imageDataUrl,
        created_at: now,
        retry_count: 0,
      });

      // Try uploading to server for static permanent URL
      let finalImageUrl = imageDataUrl;
      if (imageDataUrl.startsWith('data:image/')) {
        try {
          const uploadRes = await fetch('/api/upload/image/', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({ data: imageDataUrl }),
          });
          if (uploadRes.ok) {
            const uploadData = await uploadRes.json();
            if (uploadData.url) {
              finalImageUrl = uploadData.url;
            }
          }
        } catch {
          // Keep data URL on offline fallback
        }
      }

      const ws = wsRef.current;
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
          type: 'message:send',
          conversation_id: activeConversationId,
          text: effectiveText,
          reply_to_id: parentId,
          parent_message_id: parentId,
          image_url: finalImageUrl,
          client_temp_id: tempId,
        }));
        return true;
      }

      const res = await fetch(`/api/conversations/${activeConversationId}/messages/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          text: effectiveText,
          reply_to_id: parentId,
          parent_message_id: parentId,
          image_url: finalImageUrl,
          client_temp_id: tempId,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const serverMsg: MessageItem = data.message;
        removePendingMessage(tempId);
        setMessages((prev) => {
          const next = prev.map((m) => (m.id === tempId ? { ...serverMsg, client_temp_id: tempId } : m));
          saveMessagesToLocalDB(next);
          return next;
        });
        refreshConversations();
        return true;
      }
    } catch (err) {
      console.warn('Failed to send image message (queued in IndexedDB):', err);
    }
    return false;
  };

  const addReaction = async (messageId: string, emoji: string): Promise<boolean> => {
    if (!user) return false;
    const cleanEmoji = emoji.trim();

    // Optimistically toggle reaction locally
    setMessages((prev) =>
      prev.map((m) => {
        if (m.id !== messageId) return m;
        const currentReactions: Record<string, string[]> = { ...(m.reactions || {}) };
        const users = currentReactions[cleanEmoji] ? [...currentReactions[cleanEmoji]] : [];
        const uIdx = users.indexOf(user.id);
        if (uIdx > -1) {
          users.splice(uIdx, 1);
          if (users.length === 0) {
            delete currentReactions[cleanEmoji];
          } else {
            currentReactions[cleanEmoji] = users;
          }
        } else {
          currentReactions[cleanEmoji] = [...users, user.id];
        }
        return { ...m, reactions: currentReactions };
      })
    );

    // Send via WebSocket if available
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({
        type: 'message:reaction',
        message_id: messageId,
        emoji: cleanEmoji,
      }));
      return true;
    }

    // Fallback via HTTP
    try {
      const res = await fetch(`/api/messages/${messageId}/reactions/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ emoji: cleanEmoji }),
      });
      if (res.ok) {
        const data = await res.json();
        setMessages((prev) =>
          prev.map((m) => (m.id === messageId ? { ...m, reactions: data.reactions } : m))
        );
        return true;
      }
    } catch (err) {
      console.error('Failed to toggle reaction via HTTP:', err);
    }
    return false;
  };

  const editMessage = async (messageId: string, newText: string): Promise<boolean> => {
    if (!token || !newText.trim()) return false;
    try {
      const res = await fetch(`/api/messages/${messageId}/`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ text: newText.trim() }),
      });
      return res.ok;
    } catch (err) {
      console.error('Failed to edit message:', err);
      return false;
    }
  };

  const deleteMessage = async (messageId: string): Promise<boolean> => {
    if (!token) return false;
    try {
      const res = await fetch(`/api/messages/${messageId}/`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      return res.ok;
    } catch (err) {
      console.error('Failed to delete message:', err);
      return false;
    }
  };

  const sendTypingSignal = (isTyping: boolean) => {
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN && activeConversationId) {
      ws.send(JSON.stringify({
        type: isTyping ? 'typing:start' : 'typing:stop',
        conversation_id: activeConversationId,
      }));
    }
  };

  const createDirectChat = async (recipientId: string): Promise<string | null> => {
    if (!token) return null;
    try {
      const res = await fetch('/api/conversations/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          type: 'direct',
          recipient_id: recipientId,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        await refreshConversations();
        setActiveConversationId(data.conversation.id);
        return data.conversation.id;
      }
    } catch (err) {
      console.error('Failed to create direct chat:', err);
    }
    return null;
  };

  const createGroupChat = async (title: string, avatarUrl: string, memberIds: string[]): Promise<string | null> => {
    if (!token) return null;
    try {
      const res = await fetch('/api/conversations/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          type: 'group',
          title,
          avatar_url: avatarUrl,
          member_ids: memberIds,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        await refreshConversations();
        setActiveConversationId(data.conversation.id);
        return data.conversation.id;
      }
    } catch (err) {
      console.error('Failed to create group chat:', err);
    }
    return null;
  };

  const addMemberToGroup = async (conversationId: string, userId: string): Promise<boolean> => {
    if (!token) return false;
    try {
      const res = await fetch(`/api/conversations/${conversationId}/members/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ user_id: userId }),
      });
      if (res.ok) {
        await refreshConversations();
        return true;
      }
    } catch (err) {
      console.error('Failed to add member:', err);
    }
    return false;
  };

  const removeMemberFromGroup = async (conversationId: string, userId: string): Promise<boolean> => {
    if (!token) return false;
    try {
      const res = await fetch(`/api/conversations/${conversationId}/members/${userId}/`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        await refreshConversations();
        return true;
      }
    } catch (err) {
      console.error('Failed to remove member:', err);
    }
    return false;
  };

  const sendPing = async (): Promise<number> => {
    return new Promise((resolve) => {
      const ws = wsRef.current;
      if (!ws || ws.readyState !== WebSocket.OPEN) {
        resolve(-1);
        return;
      }
      const sentTime = Date.now();
      pendingPingResolveRef.current = (latency) => {
        resolve(latency);
      };
      ws.send(JSON.stringify({ type: 'ping', timestamp: sentTime }));
      setTimeout(() => {
        if (pendingPingResolveRef.current) {
          pendingPingResolveRef.current = null;
          resolve(-1);
        }
      }, 3500);
    });
  };

  const activeConversation = conversations.find((c) => c.id === activeConversationId) || null;
  const currentTypingMap = (activeConversationId && typingUsersMap[activeConversationId]) || {};
  const currentTypingUsers = Object.values(currentTypingMap);

  return (
    <ChatContext.Provider
      value={{
        conversations,
        activeConversation,
        messages,
        scheduledMessages,
        connectionStatus,
        typingUsers: currentTypingUsers,
        typingUsersMap,
        isLoadingMessages,
        hasMoreMessages,
        loadOlderMessages,
        retryPendingMessages,
        currentPingMs,
        sendPing,
        totalUnreadCount,
        soundEnabled,
        toggleSound,
        vibrationEnabled,
        toggleVibration,
        toggleMuteConversation,
        inAppToast,
        dismissInAppToast,
        pushSupported,
        pushSubscribed,
        pushPermission,
        subscribeToPush,
        unsubscribeFromPush,
        sendTestPush,
        selectConversation,
        sendMessage,
        sendAudioMessage,
        sendImageMessage,
        scheduleMessage,
        cancelScheduledMessage,
        loadScheduledMessages,
        addReaction,
        editMessage,
        deleteMessage,
        markConversationAsRead,
        createDirectChat,
        createGroupChat,
        sendTypingSignal,
        refreshConversations,
        addMemberToGroup,
        removeMemberFromGroup,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export function useChat() {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
}
