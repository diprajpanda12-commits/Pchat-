import React, { useState, useRef, useEffect } from 'react';
import {
  Globe,
  LogOut,
  User as UserIcon,
  Wifi,
  WifiOff,
  Volume2,
  VolumeX,
  ChevronDown,
  Activity,
  Beaker,
  ShieldCheck,
  Moon,
  Sun,
  MessageSquare,
  Users,
  Bell,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.js';
import { useLanguage } from '../context/LanguageContext.js';
import { useChat } from '../context/ChatContext.js';
import { PWAInstallButton } from './PWAInstallButton.js';
import { AppLogo } from './AppLogo.js';
import { ThemeToggleButton } from './ThemeToggleButton.js';

interface Props {
  onOpenProfile: () => void;
  onOpenTestRunner: () => void;
  onOpenDjangoDocs: () => void;
  onOpenConnectionMonitor: () => void;
  onOpenNotificationSettings?: () => void;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
}

export const Header: React.FC<Props> = ({
  onOpenProfile,
  onOpenTestRunner,
  onOpenDjangoDocs,
  onOpenConnectionMonitor,
  onOpenNotificationSettings,
  theme,
  onToggleTheme,
}) => {
  const { user, logout } = useAuth();
  const { language, setLanguage, t } = useLanguage();
  const { connectionStatus, currentPingMs, soundEnabled, toggleSound, conversations, selectConversation } = useChat();

  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setIsMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="h-16 border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-xl px-4 sm:px-6 flex items-center justify-between gap-4 md:gap-8 z-30 shrink-0 select-none">
      {/* Zone 1: Single text element Brand wordmark with panda icon & real-time connection status */}
      <div className="flex items-center gap-3 shrink-0">
        <a href="/" className="flex items-center gap-2.5 group cursor-pointer text-decoration-none">
          <AppLogo size="sm" withGlow={connectionStatus === 'connected'} />
          <div className="flex flex-col">
            <span className="text-base font-extrabold tracking-tight text-white group-hover:text-emerald-400 transition-colors whitespace-nowrap">
              PChat
            </span>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
              {connectionStatus === 'connected' ? (
                <span className="flex items-center gap-1 text-emerald-400 font-medium">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>{t.connected}</span>
                  {currentPingMs !== null && currentPingMs >= 0 && (
                    <span className="text-[10px] font-mono tabular-nums text-slate-400">
                      · {currentPingMs}ms
                    </span>
                  )}
                </span>
              ) : connectionStatus === 'connecting' ? (
                <span className="flex items-center gap-1 text-amber-400">
                  <Wifi className="w-3 h-3 animate-pulse" />
                  <span>{t.connecting}</span>
                </span>
              ) : (
                <span className="flex items-center gap-1 text-rose-400">
                  <WifiOff className="w-3 h-3" />
                  <span>{t.offline}</span>
                </span>
              )}
            </div>
          </div>
        </a>
      </div>

      {/* Zone 2: Navigation affordances (concise text links with subtle hover effects) */}
      <nav className="hidden lg:flex items-center gap-6 text-xs font-semibold text-slate-400 shrink-0">
        <button
          type="button"
          onClick={() => {
            const grove = conversations.find(c => c.id === 'conv_panda_hangout' || c.id === 'conv_bamboo_grove');
            if (grove) selectConversation(grove.id);
          }}
          className="flex items-center gap-1.5 hover:text-emerald-400 transition-colors whitespace-nowrap cursor-pointer"
        >
          <Users className="w-3.5 h-3.5 text-emerald-400" />
          <span>Bamboo Grove</span>
        </button>

        <button
          type="button"
          onClick={onOpenConnectionMonitor}
          className="flex items-center gap-1.5 hover:text-teal-300 transition-colors whitespace-nowrap cursor-pointer"
        >
          <Activity className="w-3.5 h-3.5 text-teal-400" />
          <span>Real-Time Monitor</span>
        </button>

        <button
          type="button"
          onClick={onOpenTestRunner}
          className="flex items-center gap-1.5 hover:text-emerald-300 transition-colors whitespace-nowrap cursor-pointer"
        >
          <Beaker className="w-3.5 h-3.5 text-emerald-400" />
          <span>Verification Suite</span>
        </button>

        <button
          type="button"
          onClick={onOpenDjangoDocs}
          className="flex items-center gap-1.5 hover:text-slate-200 transition-colors whitespace-nowrap cursor-pointer"
        >
          <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
          <span>Docs</span>
        </button>
      </nav>

      {/* Zone 3: Quick Action Affordances & User Profile Menu */}
      <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
        {/* Dedicated Dark Theme ON / OFF Toggle Button */}
        <ThemeToggleButton showLabel={true} />

        {/* Audio Mute/Unmute toggle */}
        <button
          type="button"
          onClick={toggleSound}
          title={soundEnabled ? t.mute_sounds || 'Mute notification chime' : t.unmute_sounds || 'Unmute notification chime'}
          className={`p-2 rounded-xl transition cursor-pointer border ${
            soundEnabled
              ? 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800/80 hover:text-white'
              : 'bg-rose-950/40 text-rose-400 border-rose-900/60 hover:bg-rose-900/50'
          }`}
        >
          {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4" />}
        </button>

        {/* Notification Settings quick button */}
        {onOpenNotificationSettings && (
          <button
            type="button"
            onClick={onOpenNotificationSettings}
            title="Notification Settings (FCM & Push)"
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800/80 hover:text-white transition cursor-pointer"
          >
            <Bell className="w-4 h-4 text-emerald-400" />
          </button>
        )}

        {/* PWA Install Button */}
        <PWAInstallButton lang={language} />

        {/* Language Switcher */}
        <button
          type="button"
          onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
          title={language === 'en' ? 'বাংলা ভাষায় পরিবর্তন করুন' : 'Switch to English'}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800/80 text-xs font-semibold transition cursor-pointer"
        >
          <Globe className="w-3.5 h-3.5 text-emerald-400" />
          <span className="whitespace-nowrap">{language === 'en' ? 'বাংলা' : 'EN'}</span>
        </button>

        {/* User Account Menu Dropdown */}
        {user && (
          <div className="relative pl-1 border-l border-slate-800/80" ref={menuRef}>
            <button
              type="button"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-slate-900 transition cursor-pointer border border-transparent hover:border-slate-800"
            >
              <img
                src={user.avatar_url || '/avatars/panda-emerald.svg'}
                alt={user.display_name}
                referrerPolicy="no-referrer"
                onError={(e) => {
                  e.currentTarget.src = '/avatars/panda-emerald.svg';
                }}
                className="w-8 h-8 rounded-full border border-emerald-500/40 object-cover bg-slate-800 shadow-xs"
              />
              <span className="text-xs font-semibold text-slate-200 hidden md:block max-w-[120px] truncate">
                {user.display_name}
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
            </button>

            {/* Dropdown Menu Modal */}
            {isMenuOpen && (
              <div className="absolute right-0 top-12 w-64 rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl p-2 z-50 text-xs animate-in fade-in zoom-in-95">
                {/* User card header */}
                <div className="p-2.5 border-b border-slate-800/80 mb-1">
                  <p className="font-bold text-white truncate text-sm">{user.display_name}</p>
                  <p className="text-[11px] text-slate-400 font-mono truncate">@{user.username}</p>
                  <p className="text-[10px] text-slate-500 truncate mt-0.5">{user.email}</p>
                </div>

                {/* Profile Modal trigger */}
                <button
                  type="button"
                  onClick={() => {
                    setIsMenuOpen(false);
                    onOpenProfile();
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-slate-200 hover:bg-slate-800 hover:text-white transition text-left cursor-pointer"
                >
                  <UserIcon className="w-4 h-4 text-emerald-400" />
                  <span>{t.user_profile}</span>
                </button>

                {/* Notification Settings modal trigger */}
                {onOpenNotificationSettings && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsMenuOpen(false);
                      onOpenNotificationSettings();
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-slate-200 hover:bg-slate-800 hover:text-white transition text-left cursor-pointer"
                  >
                    <Bell className="w-4 h-4 text-emerald-400" />
                    <span>Notification Settings</span>
                  </button>
                )}

                {/* Theme toggle */}
                <button
                  type="button"
                  onClick={() => {
                    onToggleTheme();
                  }}
                  className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-slate-200 hover:bg-slate-800 hover:text-white transition text-left cursor-pointer"
                >
                  <div className="flex items-center gap-2.5">
                    {theme === 'dark' ? (
                      <Moon className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <Sun className="w-4 h-4 text-amber-400" />
                    )}
                    <span>Theme: {theme === 'dark' ? 'Obsidian Slate' : 'Clean Contrast'}</span>
                  </div>
                </button>

                {/* Submenu for Advanced System Diagnostics */}
                <div className="pt-1 mt-1 border-t border-slate-800/80">
                  <button
                    type="button"
                    onClick={() => {
                      setIsMenuOpen(false);
                      onOpenConnectionMonitor();
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-slate-300 hover:bg-slate-800 hover:text-white transition text-left cursor-pointer"
                  >
                    <Activity className="w-4 h-4 text-teal-400" />
                    <span>Real-Time Monitor</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setIsMenuOpen(false);
                      onOpenDjangoDocs();
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-slate-300 hover:bg-slate-800 hover:text-white transition text-left cursor-pointer"
                  >
                    <ShieldCheck className="w-4 h-4 text-teal-400" />
                    <span>Architecture Guide</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setIsMenuOpen(false);
                      onOpenTestRunner();
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-slate-300 hover:bg-slate-800 hover:text-white transition text-left cursor-pointer"
                  >
                    <Beaker className="w-4 h-4 text-emerald-400" />
                    <span>Automated Tests</span>
                  </button>
                </div>

                {/* Sign Out */}
                <div className="pt-1 mt-1 border-t border-slate-800/80">
                  <button
                    type="button"
                    onClick={() => {
                      setIsMenuOpen(false);
                      logout();
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-rose-400 hover:bg-rose-950/40 hover:text-rose-300 transition text-left cursor-pointer"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>{t.logout}</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </header>
  );
};
