import React, { useState } from 'react';
import {
  Search,
  Plus,
  Users,
  UserPlus,
  Check,
  CheckCheck,
  Clock,
  Mic,
  X,
  MessageSquare,
  CheckCircle2,
  LogOut,
  Download,
  FileText,
  FileJson,
  Bell,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.js';
import { useChat } from '../context/ChatContext.js';
import { useLanguage } from '../context/LanguageContext.js';
import { ThemeToggleButton } from './ThemeToggleButton.js';

interface Props {
  onOpenNewGroup: () => void;
  onOpenUserSearch: () => void;
  onOpenProfile?: () => void;
  onOpenNotificationSettings?: () => void;
}

export const Sidebar: React.FC<Props> = ({
  onOpenNewGroup,
  onOpenUserSearch,
  onOpenProfile,
  onOpenNotificationSettings,
}) => {
  const { user, logout } = useAuth();
  const {
    conversations,
    activeConversation,
    selectConversation,
    typingUsersMap,
    totalUnreadCount,
  } = useChat();
  const { t, language } = useLanguage();
  const [filter, setFilter] = useState<'all' | 'unread' | 'direct' | 'group'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showExportModal, setShowExportModal] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  const handleExportChat = async (format: 'json' | 'txt') => {
    if (!activeConversation) return;
    setIsExporting(true);
    setShowExportModal(false);

    const safeTitle = (activeConversation.title || 'conversation').replace(/[^a-zA-Z0-9_\u0980-\u09FF-]/g, '_').slice(0, 30) || 'chat';
    const dateStr = new Date().toISOString().slice(0, 10);
    const filename = `pchat-${safeTitle}-${dateStr}.${format}`;

    try {
      const token = localStorage.getItem('pchat_auth_token') || '';
      const res = await fetch(`/api/conversations/${activeConversation.id}/export/?format=${format}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error('Export request failed');
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Sidebar export error:', err);
    } finally {
      setIsExporting(false);
    }
  };

  // Unread counts by category
  const directUnreadCount = conversations
    .filter((c) => c.type === 'direct')
    .reduce((acc, c) => acc + (c.unread_count || 0), 0);

  const groupUnreadCount = conversations
    .filter((c) => c.type === 'group')
    .reduce((acc, c) => acc + (c.unread_count || 0), 0);

  const filteredConversations = conversations.filter((conv) => {
    // Filter by category
    if (filter === 'unread' && (!conv.unread_count || conv.unread_count <= 0)) return false;
    if (filter === 'direct' && conv.type !== 'direct') return false;
    if (filter === 'group' && conv.type !== 'group') return false;

    // Filter by search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      if (conv.type === 'direct') {
        const name = conv.recipient?.display_name.toLowerCase() || '';
        const uname = conv.recipient?.username.toLowerCase() || '';
        return name.includes(q) || uname.includes(q);
      } else {
        return conv.title.toLowerCase().includes(q);
      }
    }
    return true;
  });

  const formatTimestamp = (dateStr?: string) => {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    if (isToday) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    const isYesterday = new Date(now.setDate(now.getDate() - 1)).toDateString() === date.toDateString();
    if (isYesterday) {
      return t.yesterday || 'Yesterday';
    }
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  return (
    <aside className="w-full md:w-80 lg:w-96 h-full flex flex-col bg-slate-950 border-r border-slate-800/80 shrink-0 select-none">
      {/* Top User Workspace Strip */}
      <div className="p-3.5 border-b border-slate-800/80 bg-slate-900/60">
        <div className="flex items-center justify-between gap-3">
          {/* User profile capsule */}
          <button
            type="button"
            onClick={onOpenProfile}
            title={t.user_profile}
            className="flex items-center gap-2.5 min-w-0 text-left p-1 rounded-xl hover:bg-slate-800/80 transition cursor-pointer group"
          >
            <div className="relative shrink-0">
              <img
                src={user?.avatar_url || '/avatars/panda-emerald.svg'}
                alt={user?.display_name || 'User'}
                referrerPolicy="no-referrer"
                onError={(e) => {
                  e.currentTarget.src = '/avatars/panda-emerald.svg';
                }}
                className="w-10 h-10 rounded-full object-cover bg-slate-800 ring-2 ring-emerald-500/30 group-hover:ring-emerald-400 transition"
              />
              <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-slate-900" />
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-1">
                <span className="font-bold text-xs md:text-sm text-slate-100 truncate group-hover:text-emerald-300 transition">
                  {user?.display_name}
                </span>
                <span className="text-[10px] text-emerald-400">🐼</span>
              </div>
              <p className="text-[11px] text-slate-400 font-mono truncate">
                @{user?.username}
              </p>
            </div>
          </button>

          {/* Quick Action Buttons for real messaging */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={onOpenUserSearch}
              title={t.new_chat || 'New Direct Chat'}
              className="p-2 rounded-xl bg-slate-800 hover:bg-emerald-600/20 text-slate-300 hover:text-emerald-400 border border-slate-700/80 transition active:scale-95 cursor-pointer shadow-xs"
            >
              <UserPlus className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onOpenNewGroup}
              title={t.new_group || 'New Group'}
              className="p-2 rounded-xl bg-slate-800 hover:bg-emerald-600/20 text-slate-300 hover:text-emerald-400 border border-slate-700/80 transition active:scale-95 cursor-pointer shadow-xs"
            >
              <Users className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Search Input & Category Filters */}
      <div className="p-3 border-b border-slate-800/80 space-y-2.5 bg-slate-950/80">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.search_placeholder}
            className="w-full bg-slate-900 text-slate-100 text-xs rounded-xl pl-9 pr-8 py-2 border border-slate-800 focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20 transition placeholder:text-slate-500"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-2.5 text-slate-400 hover:text-white transition p-0.5 rounded cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Segmented Filter Controls */}
        <div className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl text-xs font-medium border border-slate-800/90 overflow-x-auto scrollbar-none">
          {/* All */}
          <button
            type="button"
            onClick={() => setFilter('all')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition text-xs whitespace-nowrap cursor-pointer ${
              filter === 'all'
                ? 'bg-slate-800 text-white font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>{t.all || 'All'}</span>
            {totalUnreadCount > 0 && (
              <span className="min-w-4 h-4 px-1 rounded-full bg-emerald-500 text-slate-950 font-mono font-bold text-[10px] flex items-center justify-center">
                {totalUnreadCount > 99 ? '99+' : totalUnreadCount}
              </span>
            )}
          </button>

          {/* Unread Only filter */}
          <button
            type="button"
            onClick={() => setFilter('unread')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition text-xs whitespace-nowrap cursor-pointer ${
              filter === 'unread'
                ? 'bg-emerald-600 text-white font-semibold shadow-xs'
                : totalUnreadCount > 0
                ? 'text-emerald-400 font-semibold hover:text-emerald-300'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>{t.unread || 'Unread'}</span>
            {totalUnreadCount > 0 && (
              <span
                className={`min-w-4 h-4 px-1 rounded-full font-mono font-bold text-[10px] flex items-center justify-center ${
                  filter === 'unread' ? 'bg-white text-emerald-700' : 'bg-emerald-500 text-slate-950'
                }`}
              >
                {totalUnreadCount > 99 ? '99+' : totalUnreadCount}
              </span>
            )}
          </button>

          {/* Direct */}
          <button
            type="button"
            onClick={() => setFilter('direct')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition text-xs whitespace-nowrap cursor-pointer ${
              filter === 'direct'
                ? 'bg-slate-800 text-white font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>{language === 'bn' ? 'ব্যক্তিগত' : 'Direct'}</span>
            {directUnreadCount > 0 && (
              <span className="min-w-4 h-4 px-1 rounded-full bg-emerald-500 text-slate-950 font-mono font-bold text-[10px] flex items-center justify-center">
                {directUnreadCount > 99 ? '99+' : directUnreadCount}
              </span>
            )}
          </button>

          {/* Groups */}
          <button
            type="button"
            onClick={() => setFilter('group')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition text-xs whitespace-nowrap cursor-pointer ${
              filter === 'group'
                ? 'bg-slate-800 text-white font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>{language === 'bn' ? 'গ্রুপ' : 'Groups'}</span>
            {groupUnreadCount > 0 && (
              <span className="min-w-4 h-4 px-1 rounded-full bg-emerald-500 text-slate-950 font-mono font-bold text-[10px] flex items-center justify-center">
                {groupUnreadCount > 99 ? '99+' : groupUnreadCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Conversations List (Anti-slop: No thick left borders; clean rounded items with surface contrast) */}
      <div className="flex-1 overflow-y-auto p-2 space-y-1">
        {filteredConversations.length === 0 ? (
          <div className="p-8 text-center text-slate-400 space-y-2.5">
            <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto text-slate-400 shadow-md">
              {filter === 'unread' ? (
                <CheckCircle2 className="w-6 h-6 text-emerald-400" />
              ) : (
                <Search className="w-5 h-5 text-emerald-400" />
              )}
            </div>
            <p className="text-sm font-semibold text-slate-200">
              {filter === 'unread'
                ? t.all_caught_up || 'All caught up!'
                : t.no_conversations}
            </p>
            <p className="text-xs text-slate-400 max-w-[220px] mx-auto">
              {filter === 'unread'
                ? t.no_unread_messages || 'No unread messages right now.'
                : t.no_conversations_sub}
            </p>
            {filter !== 'unread' && (
              <button
                type="button"
                onClick={onOpenUserSearch}
                className="mt-3 inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-md shadow-emerald-950/40 transition active:scale-95 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{t.new_chat}</span>
              </button>
            )}
          </div>
        ) : (
          filteredConversations.map((conv) => {
            const isSelected = activeConversation?.id === conv.id;
            const isDirect = conv.type === 'direct';
            const title = isDirect ? conv.recipient?.display_name || 'PChat User' : conv.title;
            const avatar = isDirect
              ? conv.recipient?.avatar_url || '/avatars/panda-emerald.svg'
              : conv.avatar_url || '/avatars/panda-zen.svg';
            const isOnline = isDirect ? !!conv.recipient?.is_online : false;
            const lastMsg = conv.last_message;
            const isLastMsgSender = lastMsg && lastMsg.sender_id === user?.id;
            const hasUnread = conv.unread_count > 0;
            const convTypingMap = typingUsersMap[conv.id] || {};
            const convTypingNames = Object.values(convTypingMap);
            const isConvTyping = convTypingNames.length > 0;

            return (
              <button
                key={conv.id}
                type="button"
                onClick={() => selectConversation(conv.id)}
                className={`w-full text-left p-3 rounded-2xl flex items-center gap-3 transition-all relative cursor-pointer border ${
                  isSelected
                    ? 'bg-slate-900 border-slate-700/80 shadow-md ring-1 ring-emerald-500/20'
                    : hasUnread
                    ? 'bg-slate-900/60 hover:bg-slate-900 border-slate-800'
                    : 'bg-transparent hover:bg-slate-900/50 border-transparent hover:border-slate-800/60'
                }`}
              >
                {/* Avatar with status indicators */}
                <div className="relative shrink-0">
                  <img
                    src={avatar}
                    alt={title}
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      e.currentTarget.src = '/avatars/panda-emerald.svg';
                    }}
                    className={`w-12 h-12 rounded-full object-cover bg-slate-800 border shadow-xs relative z-10 ${
                      isSelected
                        ? 'border-emerald-500 ring-2 ring-emerald-500/20'
                        : hasUnread
                        ? 'border-emerald-500/80'
                        : 'border-slate-700/80'
                    }`}
                  />

                  {/* Direct Online / Offline Status Dot */}
                  {isDirect && (
                    <span className="absolute bottom-0 right-0 z-20 flex h-3.5 w-3.5 items-center justify-center">
                      {isOnline && (
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                      )}
                      <span
                        className={`relative inline-flex rounded-full h-3 w-3 border-2 border-slate-950 shadow-xs ${
                          isOnline ? 'bg-emerald-500' : 'bg-slate-600'
                        }`}
                        title={isOnline ? 'Online' : 'Offline'}
                      />
                    </span>
                  )}

                  {/* Group Icon Badge */}
                  {!isDirect && (
                    <span
                      className="absolute -bottom-1 -right-1 z-20 p-1 rounded-full bg-slate-900 border border-slate-700 text-emerald-400 shadow-xs"
                      title="Group conversation"
                    >
                      <Users className="w-3 h-3" />
                    </span>
                  )}
                </div>

                {/* Conversation Details & Last Message Preview */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-0.5">
                    <div className="flex items-center gap-1.5 min-w-0 pr-1">
                      <h3
                        className={`text-xs md:text-sm truncate ${
                          isSelected
                            ? 'font-bold text-emerald-300'
                            : hasUnread
                            ? 'font-bold text-white'
                            : 'font-semibold text-slate-200'
                        }`}
                      >
                        {title}
                      </h3>
                      {hasUnread && (
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />
                      )}
                    </div>

                    {lastMsg && (
                      <span
                        className={`text-[10px] shrink-0 font-mono tabular-nums ${
                          hasUnread ? 'text-emerald-400 font-bold' : 'text-slate-400'
                        }`}
                      >
                        {formatTimestamp(lastMsg.created_at)}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <div className="text-xs truncate pr-1 flex items-center gap-1 flex-1 min-w-0">
                      {/* Real-time typing indicator inside conversation list */}
                      {isConvTyping ? (
                        <span className="text-emerald-400 font-semibold flex items-center gap-1.5 animate-pulse truncate text-xs">
                          <span className="flex gap-0.5 shrink-0">
                            <span className="w-1 h-1 bg-emerald-400 rounded-full animate-bounce"></span>
                            <span className="w-1 h-1 bg-emerald-400 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                            <span className="w-1 h-1 bg-emerald-400 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                          </span>
                          <span className="truncate">{convTypingNames.join(', ')} is typing...</span>
                        </span>
                      ) : (
                        <>
                          {isLastMsgSender && (
                            <span className="inline-flex shrink-0">
                              {lastMsg.status === 'pending' && <Clock className="w-3 h-3 text-slate-400 animate-spin" />}
                              {lastMsg.status === 'sent' && <Check className="w-3 h-3 text-slate-400" />}
                              {lastMsg.status === 'delivered' && <CheckCheck className="w-3 h-3 text-slate-400" />}
                              {lastMsg.status === 'read' && <CheckCheck className="w-3.5 h-3.5 text-sky-400" />}
                            </span>
                          )}

                          {/* Last message text or audio indicator */}
                          <span
                            className={`truncate ${
                              hasUnread ? 'text-slate-100 font-medium' : 'text-slate-400'
                            }`}
                          >
                            {lastMsg ? (
                              lastMsg.is_deleted ? (
                                <span className="italic text-slate-400">{t.message_deleted}</span>
                              ) : lastMsg.audio_url ? (
                                <span className="flex items-center gap-1 text-emerald-400 font-medium">
                                  <Mic className="w-3 h-3" />
                                  <span>Voice note ({lastMsg.audio_duration ? `${lastMsg.audio_duration}s` : 'audio'})</span>
                                </span>
                              ) : (
                                lastMsg.text
                              )
                            ) : (
                              <span className="italic text-slate-400">{t.no_conversations}</span>
                            )}
                          </span>
                        </>
                      )}
                    </div>

                    {/* Unread Message Counter Badge using data from ChatProvider */}
                    {hasUnread && (
                      <span
                        className="shrink-0 flex items-center justify-center min-w-5 h-5 px-1.5 rounded-full bg-emerald-500 text-slate-950 font-black text-[11px] font-mono tabular-nums shadow-sm shadow-emerald-500/25 ring-2 ring-slate-900 animate-in zoom-in-75"
                        title={`${conv.unread_count} unread message${conv.unread_count > 1 ? 's' : ''}`}
                      >
                        {conv.unread_count > 99 ? '99+' : conv.unread_count}
                      </span>
                    )}
                  </div>
                </div>
              </button>
            );
          })
        )}
      </div>

      {/* Bottom User Workspace & Logout Section */}
      <footer className="p-3 border-t border-slate-800/80 bg-slate-900/80 shrink-0">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="relative shrink-0">
              <img
                src={user?.avatar_url || '/avatars/panda-emerald.svg'}
                alt={user?.display_name || 'User'}
                referrerPolicy="no-referrer"
                onError={(e) => {
                  e.currentTarget.src = '/avatars/panda-emerald.svg';
                }}
                className="w-8 h-8 rounded-full object-cover bg-slate-800 border border-slate-700/80"
              />
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-slate-900" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-white truncate">{user?.display_name}</p>
              <p className="text-[10px] text-emerald-400 font-medium flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>Connected</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {activeConversation && (
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowExportModal(!showExportModal)}
                  title={language === 'bn' ? 'সক্রিয় চ্যাট এক্সপোর্ট করুন' : 'Export Active Chat (JSON / TXT)'}
                  disabled={isExporting}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-emerald-950/60 text-slate-300 hover:text-emerald-400 border border-slate-700/70 hover:border-emerald-700/50 transition cursor-pointer text-xs font-semibold shadow-xs active:scale-95"
                >
                  <Download className={`w-3.5 h-3.5 text-emerald-400 ${isExporting ? 'animate-bounce' : ''}`} />
                  <span className="hidden sm:inline">{language === 'bn' ? 'এক্সপোর্ট' : 'Export'}</span>
                </button>

                {showExportModal && (
                  <div className="absolute right-0 bottom-full mb-2 w-56 rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl p-2 z-50 animate-in fade-in zoom-in-95">
                    <div className="px-2.5 py-1.5 border-b border-slate-800/80 mb-1">
                      <p className="text-[11px] font-bold text-slate-200">
                        {language === 'bn' ? 'চ্যাট হিস্ট্রি ডাউনলোড' : 'Export Chat'}
                      </p>
                      <p className="text-[10px] text-slate-400 truncate">
                        {activeConversation.title}
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleExportChat('txt')}
                      className="w-full flex items-center gap-2 px-2 py-1.5 rounded-xl text-left text-xs text-slate-200 hover:bg-slate-800 hover:text-white transition cursor-pointer group"
                    >
                      <FileText className="w-3.5 h-3.5 text-emerald-400" />
                      <div className="min-w-0">
                        <span className="font-semibold block truncate">
                          {language === 'bn' ? 'টেক্সট ফাইল (.txt)' : 'Text File (.txt)'}
                        </span>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleExportChat('json')}
                      className="w-full flex items-center gap-2 px-2 py-1.5 rounded-xl text-left text-xs text-slate-200 hover:bg-slate-800 hover:text-white transition cursor-pointer group mt-0.5"
                    >
                      <FileJson className="w-3.5 h-3.5 text-sky-400" />
                      <div className="min-w-0">
                        <span className="font-semibold block truncate">
                          {language === 'bn' ? 'জেসন ফাইল (.json)' : 'JSON File (.json)'}
                        </span>
                      </div>
                    </button>
                  </div>
                )}
              </div>
            )}

            {onOpenNotificationSettings && (
              <button
                type="button"
                onClick={onOpenNotificationSettings}
                title="Notification Settings"
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/70 transition cursor-pointer shadow-xs active:scale-95"
              >
                <Bell className="w-4 h-4 text-emerald-400" />
              </button>
            )}

            <ThemeToggleButton showLabel={false} />

            <button
              type="button"
              onClick={logout}
              title={t.logout || 'Log Out'}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-950/60 text-slate-300 hover:text-rose-300 border border-slate-700/70 hover:border-rose-900/50 transition cursor-pointer text-xs font-semibold shadow-xs active:scale-95"
            >
              <LogOut className="w-3.5 h-3.5 text-rose-400" />
              <span>{t.logout || 'Log Out'}</span>
            </button>
          </div>
        </div>
      </footer>
    </aside>
  );
};
