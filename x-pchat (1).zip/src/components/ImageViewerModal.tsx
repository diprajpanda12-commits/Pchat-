import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  ZoomIn,
  ZoomOut,
  RotateCw,
  Download,
  ExternalLink,
  Maximize2,
  Minimize2,
  Calendar,
  User,
  Image as ImageIcon,
} from 'lucide-react';

export interface ImageViewerData {
  url?: string;
  imageUrl?: string;
  caption?: string;
  senderName?: string;
  senderAvatar?: string;
  timestamp?: string;
}

interface Props {
  isOpen: boolean;
  image: ImageViewerData | null;
  onClose: () => void;
}

export const ImageViewerModal: React.FC<Props> = ({ isOpen, image, onClose }) => {
  const [zoomLevel, setZoomLevel] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [isLoaded, setIsLoaded] = useState(false);

  const activeUrl = image?.imageUrl || image?.url || '';

  // Reset transformations on new image or modal open
  useEffect(() => {
    if (isOpen) {
      setZoomLevel(1);
      setRotation(0);
      setPosition({ x: 0, y: 0 });
      setIsLoaded(false);
    }
  }, [isOpen, activeUrl]);

  // Keyboard shortcut listener
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      } else if (e.key === '+' || e.key === '=') {
        e.preventDefault();
        handleZoomIn();
      } else if (e.key === '-' || e.key === '_') {
        e.preventDefault();
        handleZoomOut();
      } else if (e.key === '0') {
        e.preventDefault();
        handleReset();
      } else if (e.key.toLowerCase() === 'r') {
        e.preventDefault();
        handleRotate();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, zoomLevel]);

  if (!isOpen || !image) return null;

  const handleZoomIn = () => {
    setZoomLevel((prev) => Math.min(prev + 0.25, 4));
  };

  const handleZoomOut = () => {
    setZoomLevel((prev) => {
      const next = Math.max(prev - 0.25, 0.5);
      if (next <= 1) {
        setPosition({ x: 0, y: 0 });
      }
      return next;
    });
  };

  const handleReset = () => {
    setZoomLevel(1);
    setRotation(0);
    setPosition({ x: 0, y: 0 });
  };

  const handleRotate = () => {
    setRotation((prev) => (prev + 90) % 360);
  };

  const handleDownload = () => {
    try {
      const a = document.createElement('a');
      a.href = activeUrl;
      const ext = activeUrl.split(';')[0].split('/')[1] || 'jpg';
      const cleanDate = new Date().toISOString().slice(0, 10);
      a.download = `pchat-image-${cleanDate}.${ext.replace('+xml', '')}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (err) {
      console.warn('Direct download fallback:', err);
      window.open(activeUrl, '_blank');
    }
  };

  const handleOpenOriginal = () => {
    window.open(activeUrl, '_blank', 'noopener,noreferrer');
  };

  // Drag-to-pan handlers when zoomed in
  const handleMouseDown = (e: React.MouseEvent) => {
    if (zoomLevel > 1) {
      setIsDragging(true);
      setDragStart({ x: e.clientX - position.x, y: e.clientY - position.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging && zoomLevel > 1) {
      setPosition({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y,
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    if (e.deltaY < 0) {
      handleZoomIn();
    } else {
      handleZoomOut();
    }
  };

  const formatTimestamp = (iso?: string) => {
    if (!iso) return '';
    try {
      const d = new Date(iso);
      return d.toLocaleString([], {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return '';
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Image Preview Viewer"
      className="fixed inset-0 z-50 flex flex-col bg-slate-950/95 backdrop-blur-xl animate-in fade-in duration-200 select-none overflow-hidden"
    >
      {/* Top Controls Toolbar */}
      <header className="flex items-center justify-between px-4 py-3 bg-slate-900/80 border-b border-slate-800/80 z-20 shrink-0">
        {/* Left: Sender & Timestamp info */}
        <div className="flex items-center gap-3 min-w-0">
          {image.senderAvatar ? (
            <img
              src={image.senderAvatar}
              alt={image.senderName || 'Sender'}
              className="w-9 h-9 rounded-full object-cover border border-emerald-500/40 bg-slate-800 shrink-0"
              onError={(e) => {
                e.currentTarget.src = '/avatars/panda-emerald.svg';
              }}
            />
          ) : (
            <div className="w-9 h-9 rounded-full bg-emerald-600/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
              <ImageIcon className="w-4 h-4" />
            </div>
          )}

          <div className="min-w-0">
            <h3 className="text-sm font-bold text-white truncate flex items-center gap-1.5">
              <span>{image.senderName || 'Photo Attachment'}</span>
              <span className="text-xs text-emerald-400">🐼</span>
            </h3>
            {image.timestamp && (
              <p className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
                <Calendar className="w-3 h-3 text-slate-500" />
                <span>{formatTimestamp(image.timestamp)}</span>
              </p>
            )}
          </div>
        </div>

        {/* Center/Right: Interactive Controls */}
        <div className="flex items-center gap-1 sm:gap-2">
          {/* Zoom Controls */}
          <div className="flex items-center bg-slate-800/90 rounded-xl p-0.5 border border-slate-700/80">
            <button
              type="button"
              onClick={handleZoomOut}
              disabled={zoomLevel <= 0.5}
              title="Zoom Out (-)"
              className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-700/70 transition disabled:opacity-40 cursor-pointer"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handleReset}
              title="Reset Zoom (0)"
              className="px-2 py-1 text-xs font-mono font-semibold text-emerald-400 hover:text-emerald-300 hover:bg-slate-700/70 rounded-md transition cursor-pointer"
            >
              {Math.round(zoomLevel * 100)}%
            </button>
            <button
              type="button"
              onClick={handleZoomIn}
              disabled={zoomLevel >= 4}
              title="Zoom In (+)"
              className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-700/70 transition disabled:opacity-40 cursor-pointer"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
          </div>

          {/* Rotate Button */}
          <button
            type="button"
            onClick={handleRotate}
            title="Rotate 90° Clockwise (R)"
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/80 transition cursor-pointer"
          >
            <RotateCw className="w-4 h-4" />
          </button>

          {/* Download Original Image */}
          <button
            type="button"
            onClick={handleDownload}
            title="Download image to device"
            className="p-2 rounded-xl bg-slate-800 hover:bg-emerald-600/30 text-slate-300 hover:text-emerald-400 border border-slate-700/80 transition cursor-pointer"
          >
            <Download className="w-4 h-4" />
          </button>

          {/* Open in New Window/Tab */}
          <button
            type="button"
            onClick={handleOpenOriginal}
            title="Open in new window"
            className="hidden sm:inline-flex p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/80 transition cursor-pointer"
          >
            <ExternalLink className="w-4 h-4" />
          </button>

          {/* Close Modal Button */}
          <button
            type="button"
            onClick={onClose}
            title="Close viewer (Esc)"
            className="p-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 transition cursor-pointer active:scale-95 ml-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Interactive Stage */}
      <main
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onWheel={handleWheel}
        className={`flex-1 flex items-center justify-center p-4 relative overflow-hidden ${
          zoomLevel > 1 ? (isDragging ? 'cursor-grabbing' : 'cursor-grab') : 'cursor-default'
        }`}
      >
        {/* Loading spinner while image is rendering */}
        {!isLoaded && (
          <div className="absolute inset-0 flex items-center justify-center z-10">
            <div className="flex flex-col items-center gap-3 bg-slate-900/80 border border-slate-800 p-4 rounded-2xl shadow-xl">
              <div className="w-7 h-7 border-3 border-emerald-500 border-t-transparent rounded-full animate-spin" />
              <span className="text-xs text-slate-300 font-medium">Loading full image...</span>
            </div>
          </div>
        )}

        <img
          src={activeUrl}
          alt={image.caption || 'Full view image'}
          onLoad={() => setIsLoaded(true)}
          style={{
            transform: `translate(${position.x}px, ${position.y}px) scale(${zoomLevel}) rotate(${rotation}deg)`,
            transition: isDragging ? 'none' : 'transform 0.2s cubic-bezier(0.2, 0.8, 0.2, 1)',
          }}
          className="max-h-[82vh] max-w-[92vw] object-contain rounded-xl shadow-2xl transition-opacity duration-300 pointer-events-auto"
          draggable={false}
          onDoubleClick={() => {
            if (zoomLevel === 1) {
              setZoomLevel(2);
            } else {
              handleReset();
            }
          }}
        />
      </main>

      {/* Bottom Caption Banner & Keyboard Hint */}
      <footer className="px-4 py-3 bg-slate-900/90 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 z-20 shrink-0">
        <div className="flex-1 min-w-0 pr-3">
          {image.caption ? (
            <p className="text-sm text-slate-100 font-medium leading-relaxed break-words bg-slate-800/60 border border-slate-700/60 px-3 py-1.5 rounded-xl inline-block max-w-full">
              {image.caption}
            </p>
          ) : (
            <span className="text-xs text-slate-400 italic">No caption</span>
          )}
        </div>

        <div className="flex items-center gap-3 text-[11px] text-slate-400 font-mono shrink-0">
          <span className="hidden md:inline">
            Double-click to {zoomLevel === 1 ? 'zoom' : 'reset'}
          </span>
          <span className="hidden sm:inline">•</span>
          <span>Scroll to zoom</span>
          <span className="hidden sm:inline">•</span>
          <span className="hidden sm:inline">Press Esc to exit</span>
        </div>
      </footer>
    </div>
  );
};
