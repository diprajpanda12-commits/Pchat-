import React from 'react';

interface AppLogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  withGlow?: boolean;
  withText?: boolean;
  withBadge?: boolean;
  badgeText?: string;
  className?: string;
}

const SIZE_MAP = {
  xs: { box: 'w-6 h-6', rounded: 'rounded-lg', icon: 24 },
  sm: { box: 'w-8 h-8', rounded: 'rounded-xl', icon: 32 },
  md: { box: 'w-10 h-10', rounded: 'rounded-xl', icon: 40 },
  lg: { box: 'w-14 h-14', rounded: 'rounded-2xl', icon: 56 },
  xl: { box: 'w-20 h-20', rounded: 'rounded-3xl', icon: 80 },
  '2xl': { box: 'w-28 h-28', rounded: 'rounded-3xl', icon: 112 },
};

export const AppLogo: React.FC<AppLogoProps> = ({
  size = 'md',
  withGlow = false,
  withText = false,
  withBadge = false,
  badgeText = 'Messenger',
  className = '',
}) => {
  const config = SIZE_MAP[size];

  return (
    <div className={`inline-flex items-center gap-3 ${className}`}>
      <div className="relative shrink-0">
        {/* Glow backdrop if requested */}
        {withGlow && (
          <div className="absolute -inset-1.5 bg-gradient-to-tr from-emerald-500/40 via-teal-400/30 to-cyan-500/40 rounded-3xl blur-md pointer-events-none animate-pulse" />
        )}

        {/* Logo Container */}
        <div
          className={`relative ${config.box} ${config.rounded} shadow-xl shadow-cyan-950/30 overflow-hidden flex items-center justify-center transition-transform hover:scale-105`}
        >
          <img
            src="/pchat-logo.png"
            alt="PChat - Panda Chat"
            className="w-full h-full object-cover select-none"
            loading="eager"
            onError={(e) => {
              e.currentTarget.src = '/assets/aistudio/file_00000000ddb482119121a713a32a5e24_720761be.png';
            }}
          />
        </div>
      </div>

      {withText && (
        <div className="flex flex-col text-left">
          <div className="flex items-center gap-2">
            <span className="font-black tracking-tight text-white text-lg bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 bg-clip-text text-transparent">
              PChat
            </span>
            {withBadge && (
              <span className="text-[11px] font-semibold tracking-wider text-slate-400">
                · {badgeText}
              </span>
            )}
          </div>
          <span className="text-[11px] text-slate-400 font-medium">Real-Time Messaging</span>
        </div>
      )}
    </div>
  );
};
