import React, { useState, useEffect } from 'react';
import {
  LogIn,
  UserPlus,
  Lock,
  Mail,
  User,
  ShieldCheck,
  Globe,
  Sparkles,
  MessageSquare,
  Mic,
  Smile,
  Eye,
  EyeOff,
  AlertCircle,
  X,
  ArrowRight,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.js';
import { useLanguage } from '../context/LanguageContext.js';
import { PWAInstallButton } from './PWAInstallButton.js';
import { AppLogo } from './AppLogo.js';
import { AVATAR_CATALOG } from '../utils/avatars.js';
import { ThemeToggleButton } from './ThemeToggleButton.js';

interface SavedAccount {
  username: string;
  display_name: string;
  avatar_url: string;
}

const UNNECESSARY_ACCOUNTS = new Set(['dip_panda', 'maya_chen', 'panda_bot']);

export const AuthScreen: React.FC = () => {
  const { login, register } = useAuth();
  const { t, language, setLanguage } = useLanguage();

  const [tab, setTab] = useState<'login' | 'register'>('login');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState(AVATAR_CATALOG[0].url);
  const [rememberMe, setRememberMe] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Saved accounts list for easy 1-click select (auto-purges unnecessary accounts)
  const [savedAccounts, setSavedAccounts] = useState<SavedAccount[]>(() => {
    try {
      const stored = localStorage.getItem('pchat_saved_accounts');
      if (!stored) return [];
      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed)) {
        const clean = parsed.filter(
          (a) =>
            a &&
            typeof a === 'object' &&
            typeof a.username === 'string' &&
            a.username.trim().length > 0 &&
            !UNNECESSARY_ACCOUNTS.has(a.username.toLowerCase())
        );
        localStorage.setItem('pchat_saved_accounts', JSON.stringify(clean));
        return clean;
      }
      return [];
    } catch {
      return [];
    }
  });

  const saveAccountToRecent = (acc: SavedAccount) => {
    if (!acc || !acc.username) return;
    try {
      const updated = [acc, ...savedAccounts.filter((a) => a && a.username !== acc.username)].slice(0, 3);
      setSavedAccounts(updated);
      localStorage.setItem('pchat_saved_accounts', JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  const removeSavedAccount = (e: React.MouseEvent, uname: string) => {
    e.stopPropagation();
    const updated = savedAccounts.filter((a) => a && a.username !== uname);
    setSavedAccounts(updated);
    localStorage.setItem('pchat_saved_accounts', JSON.stringify(updated));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const cleanUsername = username.trim();
    if (!cleanUsername) {
      setError('Please enter your username or email.');
      return;
    }

    if (!password) {
      setError('Please enter your password.');
      return;
    }

    if (password.length < 4) {
      setError('Password must be at least 4 characters long.');
      return;
    }

    setIsLoading(true);

    if (tab === 'login') {
      const res = await login(cleanUsername, password);
      if (!res.success) {
        setError(res.error || 'Invalid credentials. Please verify your username and password.');
      } else {
        // Save to remembered accounts for easy future login using canonical user profile
        saveAccountToRecent({
          username: res.user?.username || cleanUsername.toLowerCase().replace(/\s+/g, '_'),
          display_name: res.user?.display_name || cleanUsername,
          avatar_url: res.user?.avatar_url || selectedAvatar,
        });
      }
    } else {
      const cleanEmail = email.trim() || `${cleanUsername.toLowerCase().replace(/\s+/g, '_')}@pchat.app`;
      const cleanName = displayName.trim() || cleanUsername;

      const res = await register(cleanUsername, cleanEmail, password, cleanName);
      if (!res.success) {
        setError(res.error || 'Registration failed. That username or email may already be taken.');
      } else {
        saveAccountToRecent({
          username: res.user?.username || cleanUsername.toLowerCase().replace(/\s+/g, '_'),
          display_name: res.user?.display_name || cleanName,
          avatar_url: res.user?.avatar_url || selectedAvatar,
        });
      }
    }

    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-center items-center p-4 relative selection:bg-emerald-500 selection:text-white overflow-hidden">
      {/* Ambient background glows */}
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-purple-600/10 rounded-full blur-[130px] pointer-events-none" />
      <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-cyan-600/10 rounded-full blur-[130px] pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[520px] h-[520px] bg-emerald-600/10 rounded-full blur-[140px] pointer-events-none" />

      {/* Top utility bar */}
      <div className="absolute top-4 right-4 flex items-center gap-2 z-20">
        <ThemeToggleButton showLabel={true} />
        <PWAInstallButton lang={language} />
        <button
          type="button"
          onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 border border-slate-800 text-xs font-semibold transition cursor-pointer shadow-xs"
        >
          <Globe className="w-3.5 h-3.5 text-emerald-400" />
          <span>{language === 'en' ? 'বাংলা' : 'English'}</span>
        </button>
      </div>

      <div className="w-full max-w-md bg-slate-900/95 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl relative z-10">
        {/* Brand Header with AppLogo */}
        <div className="text-center mb-5">
          <div className="flex justify-center mb-2">
            <AppLogo size="xl" withGlow={true} />
          </div>

          <h1 className="text-2xl font-black text-white tracking-tight flex items-center justify-center gap-2 mt-2">
            <span className="bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 bg-clip-text text-transparent">
              PChat
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">{t.app_tagline}</p>
        </div>


        {/* Saved Accounts Quick Select (Easy Login) */}
        {tab === 'login' && savedAccounts.length > 0 && (
          <div className="mb-5 p-3 rounded-2xl bg-slate-950/70 border border-slate-800/80">
            <p className="text-[11px] font-semibold text-emerald-400 mb-2 flex items-center justify-between">
              <span>Recent Accounts on this Device:</span>
            </p>
            <div className="flex flex-col gap-1.5">
              {savedAccounts.map((acc) => (
                <div
                  key={acc.username}
                  onClick={() => {
                    setUsername(acc.username);
                    setError(null);
                  }}
                  className={`flex items-center justify-between p-2 rounded-xl border transition cursor-pointer ${
                    username === acc.username
                      ? 'bg-emerald-950/40 border-emerald-500/60 ring-1 ring-emerald-500/30'
                      : 'bg-slate-900/80 hover:bg-slate-800 border-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <img
                      src={acc.avatar_url || '/pchat-logo.png'}
                      alt={acc.display_name}
                      onError={(e) => {
                        e.currentTarget.src = '/pchat-logo.png';
                      }}
                      className="w-7 h-7 rounded-full object-cover bg-slate-800 border border-slate-700"
                    />
                    <div className="min-w-0 text-left">
                      <p className="text-xs font-semibold text-white truncate">{acc.display_name}</p>
                      <p className="text-[10px] text-slate-400 font-mono truncate">@{acc.username}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={(e) => removeSavedAccount(e, acc.username)}
                      title="Remove from device"
                      className="p-1 text-slate-500 hover:text-rose-400 transition"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                    <ArrowRight className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab Switcher: Sign In vs Create Account */}
        <div className="grid grid-cols-2 gap-1 bg-slate-950/80 p-1 rounded-2xl mb-5 border border-slate-800">
          <button
            type="button"
            onClick={() => {
              setTab('login');
              setError(null);
            }}
            className={`py-2 text-xs font-bold rounded-xl transition cursor-pointer ${
              tab === 'login'
                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {t.login}
          </button>
          <button
            type="button"
            onClick={() => {
              setTab('register');
              setError(null);
            }}
            className={`py-2 text-xs font-bold rounded-xl transition cursor-pointer ${
              tab === 'register'
                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {t.register}
          </button>
        </div>

        {/* Error notification alert */}
        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-950/80 border border-rose-800/80 text-rose-300 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        {/* Authentication Form */}
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {tab === 'register' && (
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">{t.display_name}</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="e.g. Maya Chen"
                  className="w-full bg-slate-800/90 text-slate-100 text-sm rounded-xl pl-9 pr-3 py-2.5 border border-slate-700/80 focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              {tab === 'login' ? 'Username or Email' : t.username}
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder={tab === 'login' ? 'e.g. maya or maya@pchat.app' : 'choose a username'}
                className="w-full bg-slate-800/90 text-slate-100 text-sm rounded-xl pl-9 pr-3 py-2.5 border border-slate-700/80 focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20"
              />
            </div>
          </div>

          {tab === 'register' && (
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">{t.email} (optional)</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="maya@example.com (optional)"
                  className="w-full bg-slate-800/90 text-slate-100 text-sm rounded-xl pl-9 pr-3 py-2.5 border border-slate-700/80 focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20"
                />
              </div>
            </div>
          )}

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-medium text-slate-300">{t.password}</label>
              <span className="text-[10px] text-slate-400">min 4 characters</span>
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-slate-800/90 text-slate-100 text-sm rounded-xl pl-9 pr-10 py-2.5 border border-slate-700/80 focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                title={showPassword ? t.hide_password : t.show_password}
                className="absolute right-3 top-3 text-slate-400 hover:text-slate-200 transition cursor-pointer"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {tab === 'login' ? (
            <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-3.5 h-3.5 rounded border-slate-700 bg-slate-800 text-emerald-500 focus:ring-0 focus:outline-hidden"
                />
                <span>{t.remember_me || 'Remember this device'}</span>
              </label>
              <span className="text-[11px] text-emerald-400/90">Instant Access</span>
            </div>
          ) : (
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-semibold text-slate-300">Choose Your Avatar ({AVATAR_CATALOG.length} styles)</label>
                <span className="text-[10px] text-emerald-400 font-medium">100% Offline Ready</span>
              </div>
              <div className="grid grid-cols-6 gap-1.5 max-h-36 overflow-y-auto p-1.5 bg-slate-950/80 rounded-2xl border border-slate-800">
                {AVATAR_CATALOG.map((av) => (
                  <button
                    type="button"
                    key={av.id}
                    onClick={() => setSelectedAvatar(av.url)}
                    title={`${av.name}: ${av.description}`}
                    className={`p-1 rounded-xl border transition cursor-pointer flex flex-col items-center ${
                      selectedAvatar === av.url
                        ? 'border-emerald-400 bg-emerald-500/20 ring-2 ring-emerald-400/50 scale-105 shadow-md shadow-emerald-950/40'
                        : 'border-slate-800 hover:border-slate-700 bg-slate-900/80'
                    }`}
                  >
                    <img src={av.url} alt={av.name} className="w-8 h-8 rounded-lg object-cover" />
                  </button>
                ))}
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:opacity-95 text-white font-bold text-sm shadow-lg shadow-emerald-950/50 flex items-center justify-center gap-2 transition active:scale-98 cursor-pointer mt-3"
          >
            {isLoading ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : tab === 'login' ? (
              <>
                <LogIn className="w-4 h-4" />
                <span>{t.login}</span>
              </>
            ) : (
              <>
                <UserPlus className="w-4 h-4" />
                <span>{t.register}</span>
              </>
            )}
          </button>
        </form>

        {/* Trust & Security footer */}
        <div className="mt-6 pt-4 border-t border-slate-800/80 text-center">
          <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-400 mb-2">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Real-time WebSocket • Secure Authentication</span>
          </div>
          <p className="text-[10px] text-slate-400">
            Create an account in 5 seconds to chat with anyone on PChat.
          </p>
        </div>
      </div>
    </div>
  );
};
