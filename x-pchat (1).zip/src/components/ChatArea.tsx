import React, { useState, useEffect, useRef } from 'react';
import {
  Send,
  Smile,
  Reply,
  Edit2,
  Trash2,
  Check,
  CheckCheck,
  Clock,
  CalendarClock,
  Calendar,
  ChevronUp,
  ChevronDown,
  CheckCircle2,
  Users,
  Info,
  X,
  Copy,
  ChevronLeft,
  Mic,
  Square,
  Search,
  Sparkles,
  MessageSquare,
  CornerDownRight,
  Bell,
  BellOff,
  Download,
  FileText,
  FileJson,
  Image as ImageIcon,
  Maximize2,
  Paperclip,
  Phone,
  Video,
  Loader2,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.js';
import { useChat, MessageItem, ScheduledMessageItem } from '../context/ChatContext.js';
import { useLanguage } from '../context/LanguageContext.js';
import { AudioMessagePlayer } from './AudioMessagePlayer.js';
import { EmojiPicker } from './EmojiPicker.js';
import { ImageViewerModal, ImageViewerData } from './ImageViewerModal.js';

interface Props {
  onOpenGroupDetails: () => void;
  onBackToSidebar: () => void;
}

const QUICK_REACTIONS = ['👍', '❤️', '😂', '🐼', '🔥', '🎉', '😮', '🎋'];

function renderHighlightedText(text: string, query: string) {
  if (!query.trim()) return text;
  const escaped = query.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const parts = text.split(new RegExp(`(${escaped})`, 'gi'));
  return parts.map((part, i) =>
    part.toLowerCase() === query.trim().toLowerCase() ? (
      <mark key={i} className="bg-amber-400 text-slate-950 font-bold px-0.5 rounded-xs">
        {part}
      </mark>
    ) : (
      part
    )
  );
}

// Render message content with interactive URLs and search highlighting
function renderMessageContent(text: string, query: string) {
  if (!text) return null;
  const urlRegex = /(https?:\/\/[^\s]+|www\.[^\s]+)/gi;
  const tokens: { type: 'text' | 'url'; value: string }[] = [];
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = urlRegex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      tokens.push({ type: 'text', value: text.slice(lastIndex, match.index) });
    }
    tokens.push({ type: 'url', value: match[0] });
    lastIndex = urlRegex.lastIndex;
  }
  if (lastIndex < text.length) {
    tokens.push({ type: 'text', value: text.slice(lastIndex) });
  }

  return tokens.map((token, idx) => {
    if (token.type === 'url') {
      const href = token.value.startsWith('http') ? token.value : `https://${token.value}`;
      return (
        <a
          key={idx}
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          onClick={(e) => e.stopPropagation()}
          className="underline underline-offset-2 text-emerald-300 hover:text-emerald-200 transition break-all font-medium"
        >
          {token.value}
        </a>
      );
    }
    return <span key={idx}>{renderHighlightedText(token.value, query)}</span>;
  });
}

function isDifferentDay(d1Str: string, d2Str?: string): boolean {
  if (!d2Str) return true;
  const d1 = new Date(d1Str);
  const d2 = new Date(d2Str);
  return (
    d1.getFullYear() !== d2.getFullYear() ||
    d1.getMonth() !== d2.getMonth() ||
    d1.getDate() !== d2.getDate()
  );
}

function formatDateSeparator(dateStr: string, lang: 'en' | 'bn'): string {
  const d = new Date(dateStr);
  const now = new Date();
  const isToday =
    d.getFullYear() === now.getFullYear() &&
    d.getMonth() === now.getMonth() &&
    d.getDate() === now.getDate();

  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);
  const isYesterday =
    d.getFullYear() === yesterday.getFullYear() &&
    d.getMonth() === yesterday.getMonth() &&
    d.getDate() === yesterday.getDate();

  if (isToday) return lang === 'bn' ? 'আজ' : 'Today';
  if (isYesterday) return lang === 'bn' ? 'গতকাল' : 'Yesterday';

  return d.toLocaleDateString(lang === 'bn' ? 'bn-BD' : 'en-US', {
    month: 'short',
    day: 'numeric',
    year: d.getFullYear() !== now.getFullYear() ? 'numeric' : undefined,
  });
}

function formatLastSeen(lastSeenStr: string, lang: 'en' | 'bn'): string {
  if (!lastSeenStr) return lang === 'bn' ? 'অফলাইন' : 'Offline';
  const d = new Date(lastSeenStr);
  if (isNaN(d.getTime())) return lang === 'bn' ? 'অফলাইন' : 'Offline';
  const now = new Date();
  const diffSec = Math.floor((now.getTime() - d.getTime()) / 1000);
  if (diffSec < 60) return lang === 'bn' ? 'এইমাত্র সক্রিয়' : 'Active just now';
  if (diffSec < 3600) {
    const mins = Math.floor(diffSec / 60);
    return lang === 'bn' ? `${mins} মিনিট আগে সক্রিয়` : `Active ${mins}m ago`;
  }
  const isToday =
    d.getFullYear() === now.getFullYear() &&
    d.getMonth() === now.getMonth() &&
    d.getDate() === now.getDate();
  const timeStr = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  if (isToday) return lang === 'bn' ? `আজ ${timeStr}` : `Active today at ${timeStr}`;
  return (
    (lang === 'bn' ? 'সক্রিয় ' : 'Active ') +
    d.toLocaleDateString(lang === 'bn' ? 'bn-BD' : 'en-US', {
      month: 'short',
      day: 'numeric',
    }) +
    ` ${timeStr}`
  );
}

function audioBufferToWav(buffer: AudioBuffer): ArrayBuffer {
  const numChannels = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;
  const format = 1; // PCM
  const bitDepth = 16;
  const bytesPerSample = bitDepth / 8;
  const blockAlign = numChannels * bytesPerSample;

  const dataLength = buffer.length * blockAlign;
  const bufferLength = 44 + dataLength;

  const arrayBuffer = new ArrayBuffer(bufferLength);
  const view = new DataView(arrayBuffer);

  const writeStr = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeStr(0, 'RIFF');
  view.setUint32(4, 36 + dataLength, true);
  writeStr(8, 'WAVE');
  writeStr(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, format, true);
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitDepth, true);
  writeStr(36, 'data');
  view.setUint32(40, dataLength, true);

  let offset = 44;
  for (let i = 0; i < buffer.length; i++) {
    for (let channel = 0; channel < numChannels; channel++) {
      const sample = Math.max(-1, Math.min(1, buffer.getChannelData(channel)[i]));
      const intSample = sample < 0 ? sample * 0x8000 : sample * 0x7fff;
      view.setInt16(offset, intSample, true);
      offset += 2;
    }
  }

  return arrayBuffer;
}

async function createSamplePandaAudioBlob(): Promise<{ blob: Blob; duration: number }> {
  try {
    const sampleRate = 22050;
    const durationSeconds = 3;
    const numFrames = sampleRate * durationSeconds;
    const OfflineCtxClass = window.OfflineAudioContext || (window as any).webkitOfflineAudioContext;
    if (!OfflineCtxClass) {
      throw new Error('OfflineAudioContext not available');
    }
    const offlineCtx = new OfflineCtxClass(1, numFrames, sampleRate);

    // Play cute melodic bamboo chime tones: E4, G4, C5, E5, D5
    const notes = [329.63, 392.0, 523.25, 659.25, 587.33];
    notes.forEach((freq, idx) => {
      const osc = offlineCtx.createOscillator();
      const gain = offlineCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, idx * 0.45);

      gain.gain.setValueAtTime(0, idx * 0.45);
      gain.gain.linearRampToValueAtTime(0.25, idx * 0.45 + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, idx * 0.45 + 0.4);

      osc.connect(gain);
      gain.connect(offlineCtx.destination);
      osc.start(idx * 0.45);
      osc.stop(idx * 0.45 + 0.45);
    });

    const rendered = await offlineCtx.startRendering();
    const wav = audioBufferToWav(rendered);
    return { blob: new Blob([wav], { type: 'audio/wav' }), duration: 3 };
  } catch {
    return { blob: new Blob(['PANDA_AUDIO_FALLBACK'], { type: 'audio/webm' }), duration: 3 };
  }
}

export const ChatArea: React.FC<Props> = ({ onOpenGroupDetails, onBackToSidebar }) => {
  const { user } = useAuth();
  const {
    activeConversation,
    messages,
    scheduledMessages,
    sendMessage,
    sendAudioMessage,
    sendImageMessage,
    scheduleMessage,
    cancelScheduledMessage,
    addReaction,
    editMessage,
    deleteMessage,
    typingUsers,
    sendTypingSignal,
    isLoadingMessages,
    hasMoreMessages,
    loadOlderMessages,
    toggleMuteConversation,
  } = useChat();
  const { t, language } = useLanguage();

  const [isLoadingOlder, setIsLoadingOlder] = useState(false);
  const [inputText, setInputText] = useState('');
  const [replyingTo, setReplyingTo] = useState<MessageItem | null>(null);
  const [editingMsg, setEditingMsg] = useState<MessageItem | null>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [scheduledDateTime, setScheduledDateTime] = useState('');
  const [showScheduledDrawer, setShowScheduledDrawer] = useState(false);
  const [scheduleFeedback, setScheduleFeedback] = useState<string | null>(null);
  const [activeReactionPickerMsgId, setActiveReactionPickerMsgId] = useState<string | null>(null);
  const [isSending, setIsSending] = useState(false);
  const [deleteConfirmMsgId, setDeleteConfirmMsgId] = useState<string | null>(null);
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const [searchInChat, setSearchInChat] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchMatchIndex, setSearchMatchIndex] = useState(0);
  const [callAlert, setCallAlert] = useState<string | null>(null);

  // Image viewer & attachment states
  const [viewerImage, setViewerImage] = useState<ImageViewerData | null>(null);
  const [pendingImage, setPendingImage] = useState<{ dataUrl: string; name: string; size: number } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleImageFile(file);
    }
    if (e.target) e.target.value = '';
  };

  const handleImageFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      return;
    }
    if (file.size > 15 * 1024 * 1024) {
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setPendingImage({
          dataUrl: reader.result,
          name: file.name,
          size: file.size,
        });
      }
    };
    reader.readAsDataURL(file);
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLTextAreaElement>) => {
    const items = e.clipboardData?.items;
    if (items) {
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          const file = items[i].getAsFile();
          if (file) {
            handleImageFile(file);
            e.preventDefault();
            return;
          }
        }
      }
    }
  };

  // Export chat states
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const exportMenuRef = useRef<HTMLDivElement>(null);

  // Close export menu on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (exportMenuRef.current && !exportMenuRef.current.contains(e.target as Node)) {
        setShowExportMenu(false);
      }
    };
    if (showExportMenu) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showExportMenu]);

  const handleExportChat = async (format: 'json' | 'txt') => {
    if (!activeConversation) return;
    setIsExporting(true);
    setShowExportMenu(false);

    const safeTitle = (activeConversation.title || 'conversation').replace(/[^a-zA-Z0-9_\u0980-\u09FF-]/g, '_').slice(0, 30) || 'chat';
    const dateStr = new Date().toISOString().slice(0, 10);
    const filename = `pchat-${safeTitle}-${dateStr}.${format}`;

    try {
      const token = localStorage.getItem('pchat_auth_token') || '';
      const res = await fetch(`/api/conversations/${activeConversation.id}/export/?format=${format}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!res.ok) {
        throw new Error('Failed to fetch export from server');
      }

      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.warn('Server export failed, using client memory export fallback:', err);
      try {
        let blob: Blob;
        if (format === 'json') {
          const exportData = {
            exported_at: new Date().toISOString(),
            conversation: activeConversation,
            total_messages: messages.length,
            messages,
          };
          blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
        } else {
          const header = [
            '====================================================================',
            `PChat Conversation History Export: ${activeConversation.title}`,
            `Export Date: ${new Date().toISOString()}`,
            `Total Messages: ${messages.length}`,
            '====================================================================\n',
          ];
          const lines = messages.map((m) => {
            const sender = m.sender_id === user?.id ? `${user?.display_name || 'Me'} (@${user?.username})` : 'Recipient';
            const voiceNote = m.audio_url ? ' [🎤 Voice Note]' : '';
            return `[${m.created_at}] ${sender}:\n  ${m.text || ''}${voiceNote}\n`;
          });
          blob = new Blob([header.join('\n') + lines.join('\n')], { type: 'text/plain;charset=utf-8' });
        }

        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
      } catch (fallbackErr) {
        console.error('Client export failed:', fallbackErr);
      }
    } finally {
      setIsExporting(false);
    }
  };

  // Thread-like reply view states
  const [activeThreadParent, setActiveThreadParent] = useState<MessageItem | null>(null);
  const [threadInputText, setThreadInputText] = useState('');
  const [isThreadSending, setIsThreadSending] = useState(false);
  const [showThreadEmojiPicker, setShowThreadEmojiPicker] = useState(false);

  // Voice recording states
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [micError, setMicError] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordIntervalRef = useRef<any>(null);
  const audioStreamRef = useRef<MediaStream | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const threadEndRef = useRef<HTMLDivElement>(null);
  const typingTimerRef = useRef<any>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Scroll thread replies when updated
  useEffect(() => {
    if (activeThreadParent) {
      threadEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, activeThreadParent]);

  // Clean up recording on unmount or active conversation change
  useEffect(() => {
    return () => {
      cancelRecording();
    };
  }, [activeConversation?.id]);

  // Handle typing debounce
  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputText(e.target.value);

    // Auto resize textarea
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }

    // Send typing start signal
    sendTypingSignal(true);

    if (typingTimerRef.current) {
      clearTimeout(typingTimerRef.current);
    }
    typingTimerRef.current = setTimeout(() => {
      sendTypingSignal(false);
    }, 1500);
  };

  const getMinDateTimeLocal = () => {
    const d = new Date(Date.now() + 60 * 1000);
    const offset = d.getTimezoneOffset() * 60000;
    return new Date(d.getTime() - offset).toISOString().slice(0, 16);
  };

  const setQuickScheduleMinutes = (mins: number) => {
    const d = new Date(Date.now() + mins * 60 * 1000);
    const offset = d.getTimezoneOffset() * 60000;
    setScheduledDateTime(new Date(d.getTime() - offset).toISOString().slice(0, 16));
  };

  const setTomorrowMorningSchedule = () => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    d.setHours(9, 0, 0, 0);
    const offset = d.getTimezoneOffset() * 60000;
    setScheduledDateTime(new Date(d.getTime() - offset).toISOString().slice(0, 16));
  };

  const isSendingRef = useRef(false);
  const isThreadSendingRef = useRef(false);

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (isSendingRef.current) return;
    const trimmed = inputText.trim();
    if (!trimmed && !editingMsg && !scheduledDateTime && !pendingImage) return;

    isSendingRef.current = true;
    setIsSending(true);
    try {
      if (editingMsg) {
        const success = await editMessage(editingMsg.id, trimmed);
        if (success) {
          setEditingMsg(null);
          setInputText('');
          if (textareaRef.current) textareaRef.current.style.height = 'auto';
        }
        return;
      }

      const replyId = replyingTo ? replyingTo.id : null;
      const parentMsgId = replyingTo ? (replyingTo.parent_message_id || replyingTo.id) : null;
      setInputText('');
      if (textareaRef.current) textareaRef.current.style.height = 'auto';
      setReplyingTo(null);
      setShowEmojiPicker(false);
      sendTypingSignal(false);

      if (pendingImage) {
        const imageToSend = pendingImage;
        setPendingImage(null);
        await sendImageMessage(imageToSend.dataUrl, trimmed, replyId, parentMsgId);
        return;
      }

      if (scheduledDateTime) {
        const scheduledIso = new Date(scheduledDateTime).toISOString();
        const success = await scheduleMessage(trimmed, scheduledIso, replyId, parentMsgId);
        if (success) {
          setScheduledDateTime('');
          setShowScheduleModal(false);
          setScheduleFeedback(
            `Message scheduled for ${new Date(scheduledIso).toLocaleTimeString([], {
              month: 'short',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit',
            })} ⏰`
          );
          setTimeout(() => setScheduleFeedback(null), 4000);
        }
        return;
      }

      await sendMessage(trimmed, replyId, parentMsgId);
    } finally {
      isSendingRef.current = false;
      setIsSending(false);
    }
  };

  const handleSendThreadReply = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (isThreadSendingRef.current) return;
    const trimmed = threadInputText.trim();
    if (!trimmed || !activeThreadParent) return;

    isThreadSendingRef.current = true;
    setIsThreadSending(true);
    try {
      setThreadInputText('');
      setShowThreadEmojiPicker(false);
      await sendMessage(trimmed, activeThreadParent.id, activeThreadParent.id);
    } finally {
      isThreadSendingRef.current = false;
      setIsThreadSending(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      e.stopPropagation();
      handleSend();
    }
  };

  // --- Voice Recording Logic ---
  const startRecording = async () => {
    setMicError(null);
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setMicError('Microphone access is not supported by your browser.');
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioStreamRef.current = stream;

      const mimeType = MediaRecorder.isTypeSupported('audio/webm')
        ? 'audio/webm'
        : MediaRecorder.isTypeSupported('audio/mp4')
        ? 'audio/mp4'
        : 'audio/ogg';

      const mediaRecorder = new MediaRecorder(stream, { mimeType });
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.start(100);
      setIsRecording(true);
      setRecordingSeconds(0);

      recordIntervalRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      console.warn('Microphone recording notice:', err?.message || err);
      const isDenied =
        err?.name === 'NotAllowedError' ||
        err?.name === 'SecurityError' ||
        String(err?.message || '').toLowerCase().includes('denied');
      if (isDenied) {
        setMicError('Microphone permission was not granted. You can enable it in your browser address bar or send a sample voice note below:');
      } else {
        setMicError('Microphone hardware is currently unavailable. You can send a sample voice note below:');
      }
    }
  };

  const handleSendSampleVoiceNote = async () => {
    try {
      const { blob, duration } = await createSamplePandaAudioBlob();
      const replyId = replyingTo ? replyingTo.id : null;
      const parentMsgId = replyingTo ? (replyingTo.parent_message_id || replyingTo.id) : null;
      await sendAudioMessage(blob, duration, replyId, parentMsgId);
      setReplyingTo(null);
      setMicError(null);
    } catch {
      setMicError(null);
    }
  };

  const stopAndSendRecording = () => {
    if (!mediaRecorderRef.current || !isRecording) return;

    const recorder = mediaRecorderRef.current;
    const finalDuration = recordingSeconds;

    recorder.onstop = async () => {
      const audioBlob = new Blob(audioChunksRef.current, { type: recorder.mimeType || 'audio/webm' });
      if (audioBlob.size > 100) {
        const replyId = replyingTo ? replyingTo.id : null;
        const parentMsgId = replyingTo ? (replyingTo.parent_message_id || replyingTo.id) : null;
        await sendAudioMessage(audioBlob, finalDuration, replyId, parentMsgId);
        setReplyingTo(null);
      }
      cleanupMediaStream();
    };

    recorder.stop();
    if (recordIntervalRef.current) {
      clearInterval(recordIntervalRef.current);
      recordIntervalRef.current = null;
    }
    setIsRecording(false);
    setRecordingSeconds(0);
  };

  const cancelRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.onstop = null;
      try {
        mediaRecorderRef.current.stop();
      } catch (e) {
        // ignore
      }
    }
    if (recordIntervalRef.current) {
      clearInterval(recordIntervalRef.current);
      recordIntervalRef.current = null;
    }
    cleanupMediaStream();
    setIsRecording(false);
    setRecordingSeconds(0);
  };

  const cleanupMediaStream = () => {
    if (audioStreamRef.current) {
      audioStreamRef.current.getTracks().forEach((track) => track.stop());
      audioStreamRef.current = null;
    }
  };

  const formatRecordTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const startEdit = (msg: MessageItem) => {
    setEditingMsg(msg);
    setInputText(msg.text);
    setReplyingTo(null);
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  const cancelEdit = () => {
    setEditingMsg(null);
    setInputText('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const copyToClipboard = (text: string, msgId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMsgId(msgId);
    setTimeout(() => setCopiedMsgId(null), 2000);
  };

  const formatMessageTime = (dateStr: string) => {
    const d = new Date(dateStr);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // Helper to format users who reacted
  const getReactionTooltip = (userIds: string[]) => {
    if (!activeConversation) return '';
    const names = userIds.map((uid) => {
      if (uid === user?.id) return 'You';
      const m = activeConversation.members.find((mem) => mem.id === uid);
      return m ? m.display_name : 'User';
    });
    return names.join(', ');
  };

  // Filter messages if search is active
  const filteredMessages = messages.filter((m) => {
    if (!searchInChat.trim()) return true;
    const q = searchInChat.trim().toLowerCase();
    const textMatch = m.text.toLowerCase().includes(q);
    const senderMatch =
      m.sender?.display_name?.toLowerCase().includes(q) ||
      m.sender?.username?.toLowerCase().includes(q);
    return textMatch || senderMatch;
  });

  const matchedMessageIds = searchInChat.trim()
    ? messages
        .filter((m) => {
          const q = searchInChat.trim().toLowerCase();
          return (
            m.text.toLowerCase().includes(q) ||
            m.sender?.display_name?.toLowerCase().includes(q) ||
            m.sender?.username?.toLowerCase().includes(q)
          );
        })
        .map((m) => m.id)
    : [];

  const jumpToMatch = (index: number) => {
    if (matchedMessageIds.length === 0) return;
    const targetIdx = (index + matchedMessageIds.length) % matchedMessageIds.length;
    setSearchMatchIndex(targetIdx);
    const targetId = matchedMessageIds[targetIdx];
    const elem = document.getElementById(`msg-${targetId}`);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  if (!activeConversation) {
    return (
      <main className="flex-1 hidden md:flex flex-col items-center justify-center p-8 text-center bg-slate-950 relative select-none">
        {/* Ambient subtle glow */}
        <div className="absolute w-96 h-96 rounded-full bg-emerald-500/5 blur-3xl pointer-events-none" />

        <div className="relative flex flex-col items-center max-w-md z-10">
          <div className="relative mb-6">
            <div className="absolute -inset-2 bg-gradient-to-tr from-emerald-500/20 via-teal-500/20 to-cyan-500/20 rounded-3xl blur-xl" />
            <img
              src="/pchat-logo.png"
              alt="PChat - Panda Chat"
              referrerPolicy="no-referrer"
              className="relative w-24 h-24 rounded-3xl shadow-2xl ring-1 ring-slate-800 object-cover"
            />
          </div>

          <h2 className="text-2xl font-extrabold text-white tracking-tight mb-2">
            Welcome to <span className="bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 bg-clip-text text-transparent">PChat</span>
          </h2>
          <p className="text-xs font-semibold tracking-wider text-emerald-400/90 uppercase mb-3">
            Real-Time Messaging · Voice Notes · Reactions
          </p>

          <p className="text-sm text-slate-400 leading-relaxed mb-6">
            {language === 'bn'
              ? 'বাঁদিকের তালিকা থেকে চ্যাট নির্বাচন করুন অথবা ভয়েস মেসেজ এবং ইমোজি রিঅ্যাকশন পাঠাতে নতুন কথোপকথন তৈরি করুন।'
              : 'Select a direct or group conversation from the sidebar to chat, record instant voice notes, and react to messages with real-time sync.'}
          </p>

          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>Instant WebSockets</span>
            </span>
            <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800">
              <Mic className="w-3.5 h-3.5 text-teal-400" />
              <span>Voice Notes</span>
            </span>
            <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800">
              <span>🐼 Panda Avatars</span>
            </span>
          </div>
        </div>
      </main>
    );
  }

  const isDirect = activeConversation.type === 'direct';
  const headerTitle = isDirect
    ? activeConversation.recipient?.display_name || 'PChat User'
    : activeConversation.title;
  const headerAvatar = isDirect
    ? activeConversation.recipient?.avatar_url || '/avatars/panda-emerald.svg'
    : activeConversation.avatar_url || '/avatars/panda-zen.svg';
  const isRecipientOnline = isDirect ? activeConversation.recipient?.is_online : false;

  return (
    <main className="flex-1 flex flex-col h-full bg-slate-950 overflow-hidden relative">
      {/* Top Header of Chat Area */}
      <header className="h-16 border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-xl px-4 sm:px-6 flex items-center justify-between z-20 shrink-0">
        <div className="flex items-center gap-3 min-w-0">
          {/* Back button for mobile */}
          <button
            onClick={onBackToSidebar}
            className="md:hidden p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            title="Back to conversations"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          {/* User/Group Avatar with Pulse Online Indicator */}
          <div className="relative shrink-0">
            <img
              src={headerAvatar}
              alt={headerTitle}
              referrerPolicy="no-referrer"
              onError={(e) => {
                e.currentTarget.src = '/avatars/panda-emerald.svg';
              }}
              className="w-10 h-10 rounded-full object-cover bg-slate-800 border border-slate-700/80 shadow-xs"
            />
            {isDirect && (
              <span className="absolute bottom-0 right-0 flex h-3 w-3 items-center justify-center">
                {isRecipientOnline && (
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                )}
                <span
                  className={`relative inline-flex rounded-full h-2.5 w-2.5 border-2 border-slate-950 ${
                    isRecipientOnline ? 'bg-emerald-500' : 'bg-slate-600'
                  }`}
                />
              </span>
            )}
          </div>

          <div className="min-w-0">
            <h2 className="font-bold text-sm md:text-base text-white truncate max-w-[150px] sm:max-w-xs md:max-w-md">
              {headerTitle}
            </h2>
            <div className="text-xs text-slate-400 flex items-center gap-1.5 truncate">
              {typingUsers.length > 0 ? (
                <span className="text-emerald-400 font-medium flex items-center gap-1.5 animate-pulse">
                  <span className="flex gap-0.5">
                    <span className="w-1 h-1 bg-emerald-400 rounded-full animate-bounce"></span>
                    <span className="w-1 h-1 bg-emerald-400 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                    <span className="w-1 h-1 bg-emerald-400 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                  </span>
                  <span>{typingUsers.join(', ')} {t.typing}</span>
                </span>
              ) : isDirect ? (
                isRecipientOnline ? (
                  <span className="text-emerald-400 font-medium flex items-center gap-1.5 truncate">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                    <span>{t.online}</span>
                    {activeConversation.recipient?.username && (
                      <span className="text-slate-400 font-mono text-[11px] truncate">
                        · @{activeConversation.recipient.username}
                      </span>
                    )}
                  </span>
                ) : (
                  <span className="text-slate-400 text-[11px] truncate flex items-center gap-1">
                    <span>
                      {activeConversation.recipient?.last_seen
                        ? formatLastSeen(activeConversation.recipient.last_seen, language)
                        : t.offline}
                    </span>
                    {activeConversation.recipient?.username && (
                      <span className="font-mono text-slate-400 truncate">
                        · @{activeConversation.recipient.username}
                      </span>
                    )}
                  </span>
                )
              ) : (
                <span className="flex items-center gap-1 text-slate-400 truncate">
                  <Users className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>{activeConversation.members.length} {t.member_count}</span>
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Right header actions */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Voice Call Button */}
          {isDirect && (
            <button
              type="button"
              onClick={() => {
                setCallAlert(
                  language === 'bn'
                    ? `ভয়েস কল শুরু হচ্ছে: ${headerTitle}...`
                    : `Connecting encrypted voice call to ${headerTitle}...`
                );
                setTimeout(() => setCallAlert(null), 3500);
              }}
              title={language === 'bn' ? 'ভয়েস কল' : 'Start voice call'}
              className="p-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-400 hover:text-emerald-400 border border-slate-800 transition cursor-pointer"
            >
              <Phone className="w-4 h-4" />
            </button>
          )}

          {/* Video Call Button */}
          {isDirect && (
            <button
              type="button"
              onClick={() => {
                setCallAlert(
                  language === 'bn'
                    ? `ভিডিও কল শুরু হচ্ছে: ${headerTitle}...`
                    : `Connecting HD video call to ${headerTitle}...`
                );
                setTimeout(() => setCallAlert(null), 3500);
              }}
              title={language === 'bn' ? 'ভিডিও কল' : 'Start video call'}
              className="p-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-400 hover:text-emerald-400 border border-slate-800 transition cursor-pointer"
            >
              <Video className="w-4 h-4" />
            </button>
          )}

          {/* Scheduled messages indicator button */}
          {scheduledMessages.length > 0 && (
            <button
              type="button"
              onClick={() => setShowScheduledDrawer(true)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 hover:bg-amber-500/20 text-xs font-semibold transition cursor-pointer"
              title="View pending scheduled messages"
            >
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">{scheduledMessages.length} Scheduled</span>
              <span className="sm:hidden">{scheduledMessages.length}</span>
            </button>
          )}

          {/* Mute/Unmute notification toggle */}
          <button
            type="button"
            onClick={() => {
              if (activeConversation) {
                toggleMuteConversation(activeConversation.id);
              }
            }}
            title={activeConversation?.is_muted ? 'Unmute this conversation' : 'Mute notifications for this conversation'}
            className={`p-2 rounded-xl transition cursor-pointer border ${
              activeConversation?.is_muted
                ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                : 'bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border-slate-800'
            }`}
          >
            {activeConversation?.is_muted ? <BellOff className="w-4 h-4" /> : <Bell className="w-4 h-4" />}
          </button>

          {/* Search inside conversation toggle */}
          <button
            onClick={() => {
              setIsSearchOpen(!isSearchOpen);
              if (isSearchOpen) setSearchInChat('');
            }}
            title="Search keyword in this conversation"
            className={`p-2 rounded-xl transition cursor-pointer border ${
              isSearchOpen
                ? 'bg-emerald-600/20 text-emerald-400 border-emerald-500/30'
                : 'bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border-slate-800'
            }`}
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Export Chat Button & Dropdown */}
          <div className="relative" ref={exportMenuRef}>
            <button
              type="button"
              onClick={() => setShowExportMenu(!showExportMenu)}
              title={language === 'bn' ? 'চ্যাট হিস্ট্রি ডাউনলোড করুন (JSON / TXT)' : 'Export Chat History (JSON / TXT)'}
              disabled={isExporting}
              className={`p-2 rounded-xl transition cursor-pointer border flex items-center justify-center ${
                showExportMenu
                  ? 'bg-emerald-600/20 text-emerald-400 border-emerald-500/30 ring-1 ring-emerald-500/30'
                  : 'bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border-slate-800'
              }`}
            >
              <Download className={`w-4 h-4 ${isExporting ? 'animate-bounce text-emerald-400' : ''}`} />
            </button>

            {showExportMenu && (
              <div className="absolute right-0 top-full mt-2 w-60 rounded-2xl bg-slate-900/95 backdrop-blur-md border border-slate-800 shadow-2xl p-2 z-50 animate-in fade-in zoom-in-95">
                <div className="px-2.5 py-1.5 border-b border-slate-800/80 mb-1">
                  <p className="text-[11px] font-bold text-slate-200 flex items-center justify-between">
                    <span>{language === 'bn' ? 'চ্যাট এক্সপোর্ট' : 'Export Chat History'}</span>
                    <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded-md">
                      {messages.length} msgs
                    </span>
                  </p>
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    {language === 'bn' ? 'ফরম্যাট পছন্দ করুন' : 'Select export format'}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => handleExportChat('txt')}
                  className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-left text-xs text-slate-200 hover:bg-slate-800 hover:text-white transition cursor-pointer group"
                >
                  <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 group-hover:bg-emerald-500 group-hover:text-slate-950 transition">
                    <FileText className="w-3.5 h-3.5" />
                  </div>
                  <div className="min-w-0">
                    <span className="font-semibold block truncate">
                      {language === 'bn' ? 'টেক্সট ফাইল (.txt)' : 'Text Transcript (.txt)'}
                    </span>
                    <span className="text-[10px] text-slate-400 block truncate">
                      {language === 'bn' ? 'পড়ার উপযোগী ডকুমেন্ট' : 'Readable message log'}
                    </span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => handleExportChat('json')}
                  className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-left text-xs text-slate-200 hover:bg-slate-800 hover:text-white transition cursor-pointer group mt-1"
                >
                  <div className="p-1.5 rounded-lg bg-sky-500/10 text-sky-400 group-hover:bg-sky-500 group-hover:text-slate-950 transition">
                    <FileJson className="w-3.5 h-3.5" />
                  </div>
                  <div className="min-w-0">
                    <span className="font-semibold block truncate">
                      {language === 'bn' ? 'জেসন ফাইল (.json)' : 'Structured Data (.json)'}
                    </span>
                    <span className="text-[10px] text-slate-400 block truncate">
                      {language === 'bn' ? 'সম্পূর্ণ চ্যাট ব্যাকআপ' : 'Full machine-readable backup'}
                    </span>
                  </div>
                </button>
              </div>
            )}
          </div>

          {!isDirect && (
            <button
              onClick={onOpenGroupDetails}
              title="Group info & members"
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-emerald-400 border border-slate-800 transition cursor-pointer"
            >
              <Info className="w-4 h-4" />
            </button>
          )}
        </div>
      </header>

      {/* Call Alert Toast Banner */}
      {callAlert && (
        <div className="bg-emerald-950/90 border-b border-emerald-500/40 px-4 py-2.5 text-xs text-emerald-200 flex items-center justify-between gap-2 animate-in slide-in-from-top-1 z-20 shadow-md">
          <div className="flex items-center gap-2 min-w-0">
            <Phone className="w-4 h-4 text-emerald-400 shrink-0 animate-pulse" />
            <span className="font-semibold text-emerald-300 truncate">{callAlert}</span>
          </div>
          <button
            onClick={() => setCallAlert(null)}
            className="p-1 text-emerald-400 hover:text-white cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* In-chat search bar */}
      {isSearchOpen && (
        <div className="bg-slate-900/95 border-b border-slate-800 px-4 py-2.5 flex items-center justify-between gap-3 animate-in slide-in-from-top-2 z-20 shadow-md">
          <div className="flex items-center gap-2 flex-1">
            <Search className="w-4 h-4 text-emerald-400 shrink-0" />
            <input
              type="text"
              value={searchInChat}
              onChange={(e) => {
                setSearchInChat(e.target.value);
                setSearchMatchIndex(0);
              }}
              onKeyDown={(e) => {
                if (e.key === 'Escape') {
                  setIsSearchOpen(false);
                  setSearchInChat('');
                } else if (e.key === 'Enter') {
                  e.preventDefault();
                  if (e.shiftKey) {
                    jumpToMatch(searchMatchIndex - 1);
                  } else {
                    jumpToMatch(searchMatchIndex + 1);
                  }
                }
              }}
              placeholder="Search keyword in this conversation (Press Enter for next)..."
              autoFocus
              className="flex-1 bg-slate-800/90 text-xs text-white rounded-lg px-3 py-1.5 border border-slate-700 focus:outline-hidden focus:border-emerald-500 placeholder:text-slate-400"
            />
            {searchInChat && (
              <button
                type="button"
                onClick={() => setSearchInChat('')}
                className="p-1 text-slate-400 hover:text-white text-xs cursor-pointer rounded-sm hover:bg-slate-800"
                title="Clear filter"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            {searchInChat.trim() && matchedMessageIds.length > 0 && (
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => jumpToMatch(searchMatchIndex - 1)}
                  className="p-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
                  title="Previous match (Shift+Enter)"
                >
                  <ChevronUp className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => jumpToMatch(searchMatchIndex + 1)}
                  className="p-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
                  title="Next match (Enter)"
                >
                  <ChevronDown className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
            <span className="text-[11px] font-mono text-slate-400">
              {searchInChat.trim() ? (
                <span className="text-emerald-400 font-semibold">
                  {matchedMessageIds.length > 0 ? `${searchMatchIndex + 1} of ` : ''}{matchedMessageIds.length} found
                </span>
              ) : (
                `${messages.length} messages`
              )}
            </span>
            <button
              type="button"
              onClick={() => {
                setIsSearchOpen(false);
                setSearchInChat('');
              }}
              className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer"
              title="Close search (Esc)"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Mic permission error banner */}
      {micError && (
        <div className="bg-amber-950/80 border-b border-amber-800/80 px-4 py-2.5 text-xs text-amber-200 flex flex-wrap items-center justify-between gap-2 animate-in slide-in-from-top-2">
          <div className="flex items-center gap-2">
            <Mic className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{micError}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleSendSampleVoiceNote}
              className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold text-[11px] transition cursor-pointer flex items-center gap-1 shadow-xs"
            >
              <span>Send Sample Panda Note</span> 🐼
            </button>
            <button
              onClick={() => setMicError(null)}
              className="p-1 text-amber-400 hover:text-white cursor-pointer"
              title="Dismiss"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Main Conversation & Thread Split Container */}
      <div className="flex-1 flex overflow-hidden relative">
        <div className="flex-1 flex flex-col h-full overflow-hidden">
          {/* Messages Scroll View */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3.5">
            {isLoadingMessages ? (
              <div className="flex items-center justify-center h-full text-slate-400 text-xs">
                <div className="w-5 h-5 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mr-2"></div>
                Loading messages...
              </div>
            ) : filteredMessages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-slate-400 text-center select-none py-12">
                <div className="w-16 h-16 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center mb-3 shadow-lg">
                  <span className="text-3xl">🐼</span>
                </div>
                <p className="text-sm font-semibold text-slate-200">
                  {searchInChat
                    ? 'No messages found matching search.'
                    : language === 'bn'
                    ? 'কোন বার্তা পাওয়া যায়নি'
                    : 'No messages here yet'}
                </p>
                <p className="text-xs text-slate-400 mt-1 max-w-xs">
                  {language === 'bn'
                    ? 'প্রথম বার্তা অথবা ভয়েস মেসেজ পাঠিয়ে রিয়েল-টাইম আড্ডা শুরু করুন!'
                    : 'Say hello with text, emojis, or record a voice note to start the conversation!'}
                </p>
              </div>
            ) : (
              <>
                {hasMoreMessages && (
                  <div className="flex justify-center py-2">
                    <button
                      type="button"
                      onClick={async () => {
                        setIsLoadingOlder(true);
                        await loadOlderMessages();
                        setIsLoadingOlder(false);
                      }}
                      disabled={isLoadingOlder}
                      className="px-4 py-1.5 text-xs font-medium rounded-full bg-slate-900/90 hover:bg-slate-800 text-emerald-400 border border-slate-700/80 transition-all flex items-center gap-1.5 shadow-sm disabled:opacity-50 cursor-pointer"
                    >
                      {isLoadingOlder ? (
                        <>
                          <div className="w-3.5 h-3.5 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
                          <span>Loading older messages...</span>
                        </>
                      ) : (
                        <>
                          <ChevronUp className="w-3.5 h-3.5" />
                          <span>Load older messages</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
                {filteredMessages.map((msg, index) => {
                  const isMe = msg.sender_id === user?.id;
                  const prevMsg = index > 0 ? filteredMessages[index - 1] : undefined;
                  const showDateSeparator = isDifferentDay(msg.created_at, prevMsg?.created_at);
                  const replyMsg = msg.reply_to;
                  const reactionsMap = msg.reactions || {};
                  const reactionEntries = Object.entries(reactionsMap);
                  const isReactionPickerOpen = activeReactionPickerMsgId === msg.id;

                  return (
                    <React.Fragment key={msg.id}>
                      {showDateSeparator && (
                        <div className="flex justify-center my-3 select-none">
                          <span className="px-3 py-1 rounded-full text-[11px] font-semibold bg-slate-900/90 text-slate-400 border border-slate-800/80 shadow-xs backdrop-blur-md">
                            {formatDateSeparator(msg.created_at, language)}
                          </span>
                        </div>
                      )}
                      <div
                        id={`msg-${msg.id}`}
                        className={`flex gap-2.5 ${isMe ? 'justify-end' : 'justify-start'} group relative transition-all duration-300 ${
                          matchedMessageIds[searchMatchIndex] === msg.id && searchInChat.trim()
                            ? 'p-1.5 rounded-2xl bg-amber-500/10 ring-2 ring-amber-400 ring-offset-2 ring-offset-slate-950'
                            : ''
                        }`}
                      >
                    {/* Incoming sender avatar in group conversations */}
                    {!isMe && (
                      <img
                        src={msg.sender?.avatar_url || '/avatars/panda-emerald.svg'}
                        alt={msg.sender?.display_name || 'User'}
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          e.currentTarget.src = '/avatars/panda-emerald.svg';
                        }}
                        className="w-8 h-8 rounded-full object-cover bg-slate-800 border border-slate-700/80 shrink-0 self-end mb-1 shadow-xs"
                      />
                    )}

                    <div className="relative max-w-[85%] sm:max-w-[70%]">
                      {/* Sender name for group conversations */}
                      {!isMe && !isDirect && msg.sender && (
                        <span className="text-[11px] font-semibold text-emerald-400 ml-1 mb-1 block">
                          {msg.sender.display_name}
                        </span>
                      )}

                      {/* Floating Action Bar (Emoji Reactions & Reply) */}
                      {!msg.is_deleted && (
                        <div
                          className={`absolute -top-7 opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity flex items-center gap-0.5 bg-slate-900/95 border border-slate-700/80 rounded-full px-1.5 py-0.5 shadow-xl z-30 ${
                            isMe ? 'right-0' : 'left-0'
                          }`}
                        >
                          {/* Quick Reactions Bar */}
                          <div className="flex items-center gap-0.5 pr-1 border-r border-slate-700/60">
                            {QUICK_REACTIONS.slice(0, 4).map((emoji) => {
                              const hasReacted = reactionsMap[emoji]?.includes(user?.id || '');
                              return (
                                <button
                                  key={emoji}
                                  type="button"
                                  onClick={() => addReaction(msg.id, emoji)}
                                  title={`React with ${emoji}`}
                                  className={`w-6 h-6 flex items-center justify-center text-xs rounded-full transition hover:scale-125 active:scale-95 cursor-pointer ${
                                    hasReacted ? 'bg-emerald-500/30' : 'hover:bg-slate-800'
                                  }`}
                                >
                                  {emoji}
                                </button>
                              );
                            })}
                            {/* Toggle full emoji picker for this message */}
                            <button
                              type="button"
                              onClick={() => setActiveReactionPickerMsgId(isReactionPickerOpen ? null : msg.id)}
                              title="More emoji reactions"
                              className="w-6 h-6 flex items-center justify-center text-xs text-slate-400 hover:text-emerald-400 hover:bg-slate-800 rounded-full transition cursor-pointer"
                            >
                              <Smile className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          {/* Reply Button */}
                          <button
                            type="button"
                            onClick={() => setReplyingTo(msg)}
                            title="Reply"
                            className="p-1 text-slate-400 hover:text-emerald-400 rounded-full hover:bg-slate-800 transition cursor-pointer"
                          >
                            <Reply className="w-3 h-3" />
                          </button>

                          {/* Thread View Button */}
                          <button
                            type="button"
                            onClick={() => setActiveThreadParent(msg)}
                            title="Open Thread"
                            className="p-1 text-slate-400 hover:text-teal-300 rounded-full hover:bg-slate-800 transition cursor-pointer"
                          >
                            <MessageSquare className="w-3 h-3" />
                          </button>

                          {/* Copy Text Button */}
                          {msg.text && (
                            <button
                              type="button"
                              onClick={() => copyToClipboard(msg.text, msg.id)}
                              title="Copy text"
                              className="p-1 text-slate-400 hover:text-slate-200 rounded-full hover:bg-slate-800 transition cursor-pointer"
                            >
                              <Copy className="w-3 h-3" />
                            </button>
                          )}

                          {/* Edit (Author only) */}
                          {isMe && !msg.audio_url && (
                            <button
                              type="button"
                              onClick={() => startEdit(msg)}
                              title="Edit"
                              className="p-1 text-slate-400 hover:text-amber-400 rounded-full hover:bg-slate-800 transition cursor-pointer"
                            >
                              <Edit2 className="w-3 h-3" />
                            </button>
                          )}

                          {/* Delete */}
                          {(isMe || activeConversation.created_by === user?.id) && (
                            deleteConfirmMsgId === msg.id ? (
                              <div className="flex items-center gap-1 pl-1">
                                <button
                                  type="button"
                                  onClick={() => {
                                    deleteMessage(msg.id);
                                    setDeleteConfirmMsgId(null);
                                  }}
                                  className="px-1.5 py-0.5 rounded-sm bg-rose-600 hover:bg-rose-500 text-white text-[10px] font-bold cursor-pointer"
                                >
                                  Confirm
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setDeleteConfirmMsgId(null)}
                                  className="px-1 py-0.5 text-slate-400 hover:text-white text-[10px] cursor-pointer"
                                >
                                  ✕
                                </button>
                              </div>
                            ) : (
                              <button
                                type="button"
                                onClick={() => setDeleteConfirmMsgId(msg.id)}
                                title="Delete"
                                className="p-1 text-slate-400 hover:text-rose-400 rounded-full hover:bg-slate-800 transition cursor-pointer"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            )
                          )}
                        </div>
                      )}

                      {/* Popover Emoji Tray for this specific message */}
                      {isReactionPickerOpen && (
                        <div className="absolute -top-72 left-0 z-40">
                          <EmojiPicker
                            onSelectEmoji={(emoji) => {
                              addReaction(msg.id, emoji);
                              setActiveReactionPickerMsgId(null);
                            }}
                            onClose={() => setActiveReactionPickerMsgId(null)}
                          />
                        </div>
                      )}

                      {/* Message Bubble */}
                      <div
                        className={`rounded-2xl px-4 py-2.5 shadow-md text-sm break-words transition relative ${
                          isMe
                            ? 'bg-gradient-to-br from-emerald-600 to-teal-700 text-white rounded-br-xs'
                            : 'bg-slate-900 text-slate-100 rounded-bl-xs border border-slate-800/90'
                        }`}
                      >
                        {/* Reply quote preview */}
                        {replyMsg && (
                          <div
                            className={`mb-2 pl-2.5 py-1 text-xs border-l-2 rounded-r-md ${
                              isMe
                                ? 'border-emerald-300 bg-emerald-800/60 text-emerald-100'
                                : 'border-emerald-500 bg-slate-950/60 text-slate-300'
                            }`}
                          >
                            <p className="font-semibold text-[10px] text-emerald-300">
                              {replyMsg.sender_id === user?.id ? 'You' : replyMsg.sender?.display_name || 'User'}
                            </p>
                            <p className="truncate italic text-[11px] opacity-90">{replyMsg.text}</p>
                          </div>
                        )}

                        {/* Audio Voice Note, Image Attachment, or Text Content */}
                        {msg.is_deleted ? (
                          <div className="text-[13px] italic opacity-60 flex items-center gap-1.5 py-0.5">
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>{t.message_deleted}</span>
                          </div>
                        ) : msg.image_url ? (
                          <div className="my-1">
                            <div
                              onClick={() =>
                                setViewerImage({
                                  url: msg.image_url!,
                                  caption: msg.text && msg.text !== '📷 Photo' ? msg.text : undefined,
                                  senderName: msg.sender?.display_name || (isMe ? 'You' : 'User'),
                                  senderAvatar: msg.sender?.avatar_url,
                                  timestamp: msg.created_at,
                                })
                              }
                              role="button"
                              tabIndex={0}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter' || e.key === ' ') {
                                  e.preventDefault();
                                  setViewerImage({
                                    url: msg.image_url!,
                                    caption: msg.text && msg.text !== '📷 Photo' ? msg.text : undefined,
                                    senderName: msg.sender?.display_name || (isMe ? 'You' : 'User'),
                                    senderAvatar: msg.sender?.avatar_url,
                                    timestamp: msg.created_at,
                                  });
                                }
                              }}
                              title="Click to view larger version"
                              className="group/img relative cursor-pointer overflow-hidden rounded-xl border border-black/10 dark:border-white/10 bg-slate-950/40 max-w-xs sm:max-w-sm transition-all duration-200 hover:ring-2 hover:ring-emerald-400 shadow-md"
                            >
                              <img
                                src={msg.image_url}
                                alt={msg.text && msg.text !== '📷 Photo' ? msg.text : 'Image thumbnail'}
                                loading="lazy"
                                className="w-full h-auto max-h-64 sm:max-h-72 object-cover transition-transform duration-300 group-hover/img:scale-105"
                              />
                              <div className="absolute inset-0 bg-slate-950/0 group-hover/img:bg-slate-950/40 transition-all flex items-center justify-center opacity-0 group-hover/img:opacity-100">
                                <span className="px-3 py-1.5 rounded-full bg-slate-900/90 text-white backdrop-blur-md shadow-xl flex items-center gap-1.5 text-xs font-semibold border border-slate-700/80">
                                  <Maximize2 className="w-3.5 h-3.5 text-emerald-400" />
                                  <span>View larger</span>
                                </span>
                              </div>
                            </div>
                            {msg.text && msg.text !== '📷 Photo' && (
                              <p className="text-[13.5px] mt-2 leading-relaxed whitespace-pre-wrap select-text break-words [overflow-wrap:anywhere]">
                                {renderMessageContent(msg.text, searchInChat)}
                              </p>
                            )}
                          </div>
                        ) : msg.audio_url ? (
                          <div className="my-0.5">
                            <AudioMessagePlayer
                              audioUrl={msg.audio_url}
                              duration={msg.audio_duration}
                              isSender={isMe}
                            />
                            {msg.text && msg.text !== '🎤 Voice message' && (
                              <p className="text-[13px] mt-1.5 leading-relaxed break-words [overflow-wrap:anywhere]">{renderMessageContent(msg.text, searchInChat)}</p>
                            )}
                          </div>
                        ) : (
                          <div className="text-[13.5px] leading-relaxed select-text whitespace-pre-wrap break-words [overflow-wrap:anywhere]">
                            {renderMessageContent(msg.text, searchInChat)}
                          </div>
                        )}

                        {/* Copy feedback */}
                        {copiedMsgId === msg.id && (
                          <span className="text-[10px] font-mono text-emerald-300 ml-1">Copied!</span>
                        )}

                        {/* Timestamp, edited indicator, status checks */}
                        <div
                          className={`flex items-center justify-end gap-1 text-[10px] mt-1 select-none font-mono tabular-nums ${
                            isMe ? 'text-emerald-200/90' : 'text-slate-400'
                          }`}
                        >
                          {msg.is_edited && !msg.is_deleted && (
                            <span className="italic opacity-80">{t.edited}</span>
                          )}
                          <span>{formatMessageTime(msg.created_at)}</span>

                          {/* Delivery Status */}
                          {isMe && (
                            <span className="inline-flex items-center ml-0.5">
                              {msg.status === 'pending' && <Clock className="w-3 h-3 animate-spin opacity-80" />}
                              {msg.status === 'sent' && <Check className="w-3 h-3 opacity-90" />}
                              {msg.status === 'delivered' && <CheckCheck className="w-3 h-3 text-slate-200" />}
                              {msg.status === 'read' && <CheckCheck className="w-3.5 h-3.5 text-sky-300" />}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Reaction Badges Chips below message */}
                      {reactionEntries.length > 0 && (
                        <div
                          className={`flex flex-wrap items-center gap-1 mt-1 z-10 ${
                            isMe ? 'justify-end' : 'justify-start'
                          }`}
                        >
                          {reactionEntries.map(([emoji, userIds]) => {
                            const hasReacted = userIds.includes(user?.id || '');
                            const tooltip = getReactionTooltip(userIds);

                            return (
                              <button
                                key={emoji}
                                type="button"
                                onClick={() => addReaction(msg.id, emoji)}
                                title={tooltip}
                                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs transition-all active:scale-95 cursor-pointer shadow-xs ${
                                  hasReacted
                                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-semibold'
                                    : 'bg-slate-900/90 hover:bg-slate-800 text-slate-300 border border-slate-700/60'
                                }`}
                              >
                                <span>{emoji}</span>
                                <span className="text-[10px] font-mono font-bold tabular-nums">{userIds.length}</span>
                              </button>
                            );
                          })}

                          {/* Add reaction '+' small button */}
                          <button
                            type="button"
                            onClick={() => setActiveReactionPickerMsgId(isReactionPickerOpen ? null : msg.id)}
                            title="Add reaction"
                            className="w-5 h-5 flex items-center justify-center rounded-full bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-emerald-400 border border-slate-800 text-[11px] transition cursor-pointer"
                          >
                            +
                          </button>
                        </div>
                      )}

                      {/* Thread Replies Button Chip */}
                      {(() => {
                        const threadReplies = messages.filter(
                          (m) => (m.parent_message_id === msg.id || m.reply_to_id === msg.id) && m.id !== msg.id
                        );
                        if (threadReplies.length === 0) return null;
                        return (
                          <div className={`mt-1 flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                            <button
                              type="button"
                              onClick={() => setActiveThreadParent(msg)}
                              className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-slate-900 hover:bg-slate-800 text-teal-300 hover:text-teal-200 border border-slate-700/80 text-[11px] font-semibold transition cursor-pointer shadow-xs group/thread"
                            >
                              <CornerDownRight className="w-3.5 h-3.5 text-teal-400 group-hover/thread:translate-x-0.5 transition-transform" />
                              <span className="tabular-nums">{threadReplies.length} {threadReplies.length === 1 ? 'reply' : 'replies'}</span>
                              <span className="text-[10px] text-slate-400 font-normal">· View thread</span>
                            </button>
                          </div>
                        );
                      })()}
                    </div>
                  </div>
                </React.Fragment>
              );
            })}
            </>
          )}

            {/* Real-time Typing Indicator in Message List */}
            {typingUsers.length > 0 && (
              <div className="flex items-center gap-2.5 animate-in fade-in slide-in-from-bottom-2 duration-200 pl-1 py-1">
                <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700/80 flex items-center justify-center text-sm shadow-xs shrink-0 select-none">
                  🐼
                </div>
                <div className="bg-slate-900 border border-slate-800 text-slate-300 rounded-2xl rounded-bl-xs px-3.5 py-2 shadow-xs flex items-center gap-2">
                  <div className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                    <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                    <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce"></span>
                  </div>
                  <span className="text-xs text-slate-300">
                    <strong className="text-emerald-400 font-semibold">{typingUsers.join(', ')}</strong> {typingUsers.length > 1 ? 'are typing...' : 'is typing...'}
                  </span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Replying Banner */}
          {replyingTo && (
            <div className="bg-slate-900 border-t border-slate-800 px-4 py-2 flex items-center justify-between text-xs text-slate-300 animate-in slide-in-from-bottom-2">
              <div className="flex items-center gap-2 overflow-hidden pr-2">
                <Reply className="w-4 h-4 text-emerald-400 shrink-0" />
                <div className="overflow-hidden">
                  <span className="font-semibold text-emerald-400">
                    {t.replying_to} {replyingTo.sender_id === user?.id ? 'You' : replyingTo.sender?.display_name}:
                  </span>
                  <p className="truncate text-slate-400">{replyingTo.text}</p>
                </div>
              </div>
              <button onClick={() => setReplyingTo(null)} className="p-1 text-slate-400 hover:text-white cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Editing Banner */}
          {editingMsg && (
            <div className="bg-slate-900 border-t border-slate-800 px-4 py-2 flex items-center justify-between text-xs text-amber-300 animate-in slide-in-from-bottom-2">
              <div className="flex items-center gap-2 overflow-hidden pr-2">
                <Edit2 className="w-4 h-4 text-amber-400 shrink-0" />
                <span className="font-semibold">{t.edit_message}:</span>
                <span className="truncate text-slate-400">{editingMsg.text}</span>
              </div>
              <button onClick={cancelEdit} className="p-1 text-slate-400 hover:text-white cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Main Emoji Picker Modal */}
          {showEmojiPicker && (
            <div className="absolute bottom-20 left-4 z-40">
              <EmojiPicker
                onSelectEmoji={(emoji) => {
                  setInputText((prev) => prev + emoji);
                }}
                onClose={() => setShowEmojiPicker(false)}
              />
            </div>
          )}

          {/* Schedule Datetime Picker Popover */}
          {showScheduleModal && (
            <div className="absolute bottom-20 left-4 sm:left-14 z-40 bg-slate-900 border border-slate-700/80 rounded-2xl p-4 shadow-2xl w-80 text-white animate-in zoom-in-95 duration-150 backdrop-blur-xl">
              <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
                <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                  <CalendarClock className="w-4 h-4" />
                  <span>Schedule Message</span>
                </div>
                <button
                  type="button"
                  onClick={() => setShowScheduleModal(false)}
                  className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-[11px] text-slate-400 uppercase tracking-wider font-semibold mb-1">
                    Select Date & Time
                  </label>
                  <input
                    type="datetime-local"
                    min={getMinDateTimeLocal()}
                    value={scheduledDateTime}
                    onChange={(e) => setScheduledDateTime(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden focus:border-amber-400 font-mono"
                  />
                </div>

                <div>
                  <span className="block text-[11px] text-slate-400 uppercase tracking-wider font-semibold mb-1.5">
                    Quick Presets
                  </span>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      type="button"
                      onClick={() => setQuickScheduleMinutes(15)}
                      className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 hover:text-white border border-slate-700 transition cursor-pointer text-left"
                    >
                      ⏰ In 15 mins
                    </button>
                    <button
                      type="button"
                      onClick={() => setQuickScheduleMinutes(60)}
                      className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 hover:text-white border border-slate-700 transition cursor-pointer text-left"
                    >
                      ⏰ In 1 hour
                    </button>
                    <button
                      type="button"
                      onClick={() => setQuickScheduleMinutes(180)}
                      className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 hover:text-white border border-slate-700 transition cursor-pointer text-left"
                    >
                      ⏰ In 3 hours
                    </button>
                    <button
                      type="button"
                      onClick={() => setTomorrowMorningSchedule()}
                      className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 hover:text-white border border-slate-700 transition cursor-pointer text-left"
                    >
                      ☀️ Tomorrow 9 AM
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => {
                      setScheduledDateTime('');
                      setShowScheduleModal(false);
                    }}
                    className="px-3 py-1.5 rounded-xl text-xs text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
                  >
                    Clear
                  </button>
                  <button
                    type="button"
                    disabled={!scheduledDateTime}
                    onClick={() => setShowScheduleModal(false)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
                      scheduledDateTime
                        ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold'
                        : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                    }`}
                  >
                    Set Schedule
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Scheduled Messages Drawer Modal */}
          {showScheduledDrawer && (
            <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
              <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col max-h-[80vh]">
                <div className="px-5 py-3.5 border-b border-slate-800 flex items-center justify-between bg-slate-950/50">
                  <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                    <CalendarClock className="w-4 h-4" />
                    <span>Scheduled Messages ({scheduledMessages.length})</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowScheduledDrawer(false)}
                    className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <div className="p-4 overflow-y-auto space-y-2.5 flex-1">
                  {scheduledMessages.length === 0 ? (
                    <div className="text-center py-8 text-slate-400 text-xs">
                      No pending scheduled messages for this conversation.
                    </div>
                  ) : (
                    scheduledMessages.map((sm) => (
                      <div
                        key={sm.id}
                        className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-3 flex items-start justify-between gap-3 shadow-xs"
                      >
                        <div className="space-y-1 min-w-0 flex-1">
                          <p className="text-sm text-slate-100 break-words font-medium">{sm.text}</p>
                          <div className="flex items-center gap-1.5 text-[11px] text-amber-400/90 font-mono">
                            <Clock className="w-3 h-3 shrink-0" />
                            <span>
                              {new Date(sm.scheduled_for).toLocaleString([], {
                                month: 'short',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => cancelScheduledMessage(sm.id)}
                          className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 transition cursor-pointer shrink-0"
                          title="Cancel scheduled message"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))
                  )}
                </div>
                <div className="p-3 border-t border-slate-800 bg-slate-950/30 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setShowScheduledDrawer(false)}
                    className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-white font-medium transition cursor-pointer"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Floating Real-Time Typing Indicator Bubble */}
          {typingUsers.length > 0 && (
            <div className="px-4 py-1.5 flex items-center gap-2 text-xs text-emerald-400 bg-slate-900/90 border-t border-slate-800/80 backdrop-blur-md animate-in slide-in-from-bottom-1">
              <div className="flex gap-1 items-center">
                <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce"></span>
                <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce [animation-delay:0.4s]"></span>
              </div>
              <span className="font-semibold text-emerald-300">{typingUsers.join(', ')}</span>
              <span className="text-slate-400">{typingUsers.length > 1 ? 'are typing...' : 'is typing...'}</span>
            </div>
          )}

          {/* Input Composer & Voice Recording Controller */}
          <footer className="p-2 sm:p-3 bg-slate-950/95 backdrop-blur-xl border-t border-slate-800/90 shrink-0 sticky bottom-0 z-20 box-border w-full max-w-full">
            {/* Scheduled preview banner */}
            {scheduledDateTime && (
              <div className="bg-amber-950/60 border border-amber-500/30 rounded-xl px-3 py-1.5 mb-2 flex items-center justify-between text-xs text-amber-200 animate-in fade-in">
                <div className="flex items-center gap-2">
                  <CalendarClock className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>
                    Will send at:{' '}
                    <strong className="text-white">
                      {new Date(scheduledDateTime).toLocaleString([], {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </strong>
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setScheduledDateTime('')}
                  className="p-1 hover:text-white rounded-md transition cursor-pointer"
                  title="Cancel schedule"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Schedule confirmation feedback toast */}
            {scheduleFeedback && (
              <div className="bg-emerald-950/70 border border-emerald-500/40 rounded-xl px-3 py-1.5 mb-2 flex items-center gap-2 text-xs text-emerald-300 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{scheduleFeedback}</span>
              </div>
            )}

            {/* Pending Image Attachment Preview */}
            {pendingImage && (
              <div className="relative mb-2.5 p-2.5 bg-slate-900/90 border border-emerald-500/40 rounded-2xl flex items-center gap-3 shadow-lg shadow-emerald-950/20 backdrop-blur-md animate-in fade-in slide-in-from-bottom-2">
                <div className="relative group/prev shrink-0">
                  <img
                    src={pendingImage.dataUrl}
                    alt="Attachment preview"
                    className="w-16 h-16 object-cover rounded-xl border border-emerald-500/30 shadow-md cursor-pointer hover:opacity-90 transition"
                    onClick={() =>
                      setViewerImage({
                        imageUrl: pendingImage.dataUrl,
                        senderName: 'You',
                        caption: 'Attachment preview',
                      })
                    }
                  />
                  <div className="absolute inset-0 bg-slate-950/40 rounded-xl opacity-0 group-hover/prev:opacity-100 flex items-center justify-center transition pointer-events-none">
                    <Maximize2 className="w-4 h-4 text-white" />
                  </div>
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400 mb-0.5">
                    <ImageIcon className="w-3.5 h-3.5 shrink-0" />
                    <span className="truncate">{pendingImage.name}</span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    {(pendingImage.size / 1024).toFixed(1)} KB • Image ready to send
                  </p>
                  <p className="text-[10px] text-slate-500 mt-0.5">
                    Click thumbnail to zoom. Type an optional message below as caption.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setPendingImage(null)}
                  className="p-1.5 rounded-xl bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition cursor-pointer self-start"
                  title="Remove image"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}

            {isRecording ? (
              /* Live Voice Recording Bar - Responsive, no overflow */
              <div className="w-full max-w-4xl mx-auto flex items-center justify-between gap-2 sm:gap-3 bg-slate-900 border border-rose-500/40 p-2 sm:p-2.5 rounded-2xl sm:rounded-3xl shadow-xl animate-in fade-in box-border">
                <div className="flex items-center gap-2 sm:gap-3 min-w-0 pl-1">
                  <span className="relative flex h-3 w-3 shrink-0">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-500" />
                  </span>
                  <span className="text-xs font-semibold text-rose-300 truncate">
                    {language === 'bn' ? 'ভয়েস রেকর্ড হচ্ছে' : 'Recording'}
                  </span>
                  <span className="text-xs font-mono font-bold text-white bg-slate-950 px-2 py-0.5 rounded-md border border-slate-800 tabular-nums shrink-0">
                    {formatRecordTime(recordingSeconds)}
                  </span>
                  <div className="hidden xs:flex items-center gap-0.5 h-4 px-1">
                    {[12, 24, 16, 28, 10, 26, 18, 22].map((height, i) => (
                      <span
                        key={i}
                        style={{ height: `${height}px` }}
                        className="w-1 bg-rose-500 rounded-full animate-pulse"
                      />
                    ))}
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={cancelRecording}
                    className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition cursor-pointer"
                  >
                    {language === 'bn' ? 'বাতিল' : 'Cancel'}
                  </button>
                  <button
                    type="button"
                    onClick={stopAndSendRecording}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md shadow-emerald-950/40 transition active:scale-95 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{language === 'bn' ? 'পাঠান' : 'Send'}</span>
                  </button>
                </div>
              </div>
            ) : (
              /* Normal Message Input Composer - Send Button Completely Inside the Container */
              <div className="w-full max-w-4xl mx-auto box-border">
                <form onSubmit={handleSend} className="w-full relative box-border">
                  {/* Hidden image file input */}
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept="image/*"
                    onChange={handleFileChange}
                    className="hidden"
                  />

                  {/* All-In-One Unified Input Container: The Send button is 100% inside */}
                  <div className="w-full bg-slate-900/95 border border-slate-800 focus-within:border-emerald-500/70 focus-within:ring-2 focus-within:ring-emerald-500/20 rounded-2xl sm:rounded-3xl p-1.5 sm:p-2 flex items-end gap-1 sm:gap-1.5 shadow-lg box-border transition-all">
                    
                    {/* Attachment / Image Trigger */}
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      title={language === 'bn' ? 'ছবি যুক্ত করুন' : 'Attach image'}
                      className={`p-2 sm:p-2.5 rounded-full transition-colors shrink-0 cursor-pointer ${
                        pendingImage
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : 'text-slate-400 hover:text-emerald-400 hover:bg-slate-800/70'
                      }`}
                    >
                      <Paperclip className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>

                    {/* Emoji Trigger */}
                    <button
                      type="button"
                      onClick={() => {
                        setShowEmojiPicker(!showEmojiPicker);
                        setShowScheduleModal(false);
                      }}
                      title={language === 'bn' ? 'ইমোজি' : 'Emoji picker'}
                      className={`p-2 sm:p-2.5 rounded-full transition-colors shrink-0 cursor-pointer ${
                        showEmojiPicker
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : 'text-slate-400 hover:text-emerald-400 hover:bg-slate-800/70'
                      }`}
                    >
                      <Smile className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>

                    {/* Auto-expanding Textarea with explicit min-w-0 */}
                    <div className="flex-1 min-w-0 relative py-1 px-1 box-border">
                      <textarea
                        ref={textareaRef}
                        rows={1}
                        value={inputText}
                        onChange={handleInputChange}
                        onKeyDown={handleKeyDown}
                        onPaste={handlePaste}
                        placeholder={
                          pendingImage
                            ? (language === 'bn' ? 'ক্যাপশন লিখুন...' : 'Add an optional caption...')
                            : scheduledDateTime
                            ? (language === 'bn' ? 'শিডিউল মেসেজ লিখুন...' : 'Type message to schedule...')
                            : (language === 'bn' ? 'মেসেজ লিখুন...' : t.type_message)
                        }
                        className="w-full bg-transparent text-slate-100 placeholder:text-slate-500 text-sm sm:text-base leading-relaxed resize-none focus:outline-hidden max-h-32 min-h-[24px] box-border overflow-y-auto block select-text"
                      />
                    </div>

                    {/* Schedule Message Trigger */}
                    <button
                      type="button"
                      onClick={() => {
                        setShowScheduleModal(!showScheduleModal);
                        setShowEmojiPicker(false);
                      }}
                      title={language === 'bn' ? 'শিডিউল মেসেজ' : 'Schedule message'}
                      className={`p-2 sm:p-2.5 rounded-full transition-colors shrink-0 cursor-pointer relative ${
                        scheduledDateTime || showScheduleModal
                          ? 'bg-amber-500/20 text-amber-400'
                          : 'text-slate-400 hover:text-amber-400 hover:bg-slate-800/70'
                      }`}
                    >
                      <CalendarClock className="w-4 h-4 sm:w-5 sm:h-5" />
                      {scheduledDateTime && (
                        <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                      )}
                    </button>

                    {/* Send / Mic Button - COMPLETELY INSIDE the input container with shrink-0 */}
                    <div className="shrink-0 flex items-center justify-center pl-0.5">
                      {inputText.trim() || editingMsg || scheduledDateTime || pendingImage ? (
                        <button
                          type="submit"
                          disabled={(!inputText.trim() && !pendingImage) || isSending}
                          title={scheduledDateTime ? (language === 'bn' ? 'শিডিউল করুন' : 'Schedule message') : (language === 'bn' ? 'পাঠান' : t.send)}
                          className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center transition-all shadow-md active:scale-95 cursor-pointer shrink-0 ${
                            isSending
                              ? 'bg-emerald-700 text-white cursor-wait opacity-80'
                              : (inputText.trim() || pendingImage)
                              ? scheduledDateTime
                                ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold shadow-amber-950/40 hover:scale-105'
                                : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-950/40 hover:scale-105'
                              : 'bg-slate-800 text-slate-600 cursor-not-allowed opacity-50'
                          }`}
                        >
                          {isSending ? (
                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                          ) : scheduledDateTime ? (
                            <CalendarClock className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
                          ) : (
                            <Send className="w-4 h-4 sm:w-4.5 sm:h-4.5 ml-0.5" />
                          )}
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={startRecording}
                          title={language === 'bn' ? 'ভয়েস মেসেজ রেকর্ড করুন' : 'Hold or click to record voice message'}
                          className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-slate-800/80 hover:bg-emerald-600/20 text-slate-300 hover:text-emerald-400 border border-slate-700/80 transition-all active:scale-95 cursor-pointer flex items-center justify-center shrink-0 hover:scale-105"
                        >
                          <Mic className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
                        </button>
                      )}
                    </div>
                  </div>
                </form>
              </div>
            )}
          </footer>
        </div>

        {/* Thread Sidebar View */}
        {activeThreadParent && (
          <aside className="w-full sm:w-96 md:w-[400px] border-l border-slate-800 bg-slate-900/98 flex flex-col h-full shadow-2xl z-30 animate-in slide-in-from-right duration-200 absolute sm:relative inset-0 sm:inset-auto">
            {/* Thread Header */}
            <div className="h-14 border-b border-slate-800 px-4 flex items-center justify-between shrink-0 bg-slate-950/70">
              <div className="flex items-center gap-2 min-w-0">
                <MessageSquare className="w-4 h-4 text-teal-400 shrink-0" />
                <div className="min-w-0">
                  <h3 className="text-sm font-bold text-white truncate">Thread</h3>
                  <p className="text-[10px] text-slate-400 truncate">
                    with {activeThreadParent.sender?.display_name || 'User'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveThreadParent(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
                title="Close thread"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Thread Content Scroll */}
            <div className="flex-1 overflow-y-auto p-3 space-y-3">
              {/* Pinned Parent Message Card */}
              <div className="p-3.5 rounded-2xl bg-slate-950/90 border border-slate-800 shadow-md">
                <div className="flex items-center gap-2 mb-2">
                  <img
                    src={activeThreadParent.sender?.avatar_url || '/avatars/panda-emerald.svg'}
                    alt={activeThreadParent.sender?.display_name}
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      e.currentTarget.src = '/avatars/panda-emerald.svg';
                    }}
                    className="w-7 h-7 rounded-full object-cover bg-slate-800 border border-slate-700"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-emerald-400 truncate">
                        {activeThreadParent.sender_id === user?.id ? 'You' : activeThreadParent.sender?.display_name}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono tabular-nums">
                        {formatMessageTime(activeThreadParent.created_at)}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono">@{activeThreadParent.sender?.username}</span>
                  </div>
                </div>

                {activeThreadParent.image_url && (
                  <div
                    className="relative group/thp cursor-pointer mb-2 rounded-xl overflow-hidden border border-slate-800 max-w-sm"
                    onClick={() =>
                      setViewerImage({
                        imageUrl: activeThreadParent.image_url!,
                        senderName: activeThreadParent.sender?.display_name,
                        timestamp: activeThreadParent.created_at,
                        caption: activeThreadParent.text !== '📷 Photo' ? activeThreadParent.text : undefined,
                      })
                    }
                  >
                    <img
                      src={activeThreadParent.image_url}
                      alt="Attachment"
                      className="w-full max-h-56 object-cover group-hover/thp:scale-102 transition duration-200"
                    />
                    <div className="absolute inset-0 bg-slate-950/30 opacity-0 group-hover/thp:opacity-100 flex items-center justify-center transition">
                      <span className="px-2 py-1 rounded-md bg-slate-950/80 text-white text-[11px] font-medium flex items-center gap-1 shadow-sm">
                        <Maximize2 className="w-3 h-3" /> Zoom
                      </span>
                    </div>
                  </div>
                )}

                {activeThreadParent.audio_url ? (
                  <AudioMessagePlayer
                    audioUrl={activeThreadParent.audio_url}
                    duration={activeThreadParent.audio_duration}
                    isSender={activeThreadParent.sender_id === user?.id}
                  />
                ) : (
                  (activeThreadParent.text !== '📷 Photo' || !activeThreadParent.image_url) && (
                    <p className="text-xs text-slate-200 leading-relaxed break-words">{activeThreadParent.text}</p>
                  )
                )}
              </div>

              {/* Replies separator */}
              <div className="flex items-center gap-2 py-1">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  Replies ({messages.filter((m) => (m.parent_message_id === activeThreadParent.id || m.reply_to_id === activeThreadParent.id) && m.id !== activeThreadParent.id).length})
                </span>
                <div className="h-px bg-slate-800 flex-1" />
              </div>

              {/* Thread Replies List */}
              {(() => {
                const replies = messages.filter(
                  (m) => (m.parent_message_id === activeThreadParent.id || m.reply_to_id === activeThreadParent.id) && m.id !== activeThreadParent.id
                );

                if (replies.length === 0) {
                  return (
                    <div className="py-8 text-center text-slate-500 text-xs">
                      <MessageSquare className="w-8 h-8 text-slate-700 mx-auto mb-2 opacity-60" />
                      <p className="font-semibold text-slate-400">No replies yet</p>
                      <p className="text-[11px] mt-0.5">Send the first reply to this thread below!</p>
                    </div>
                  );
                }

                return replies.map((reply) => {
                  const isReplyMe = reply.sender_id === user?.id;
                  return (
                    <div key={reply.id} className="flex gap-2.5 p-2 rounded-xl bg-slate-950/40 border border-slate-800/60">
                      <img
                        src={reply.sender?.avatar_url || '/avatars/panda-emerald.svg'}
                        alt={reply.sender?.display_name}
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          e.currentTarget.src = '/avatars/panda-emerald.svg';
                        }}
                        className="w-6 h-6 rounded-full object-cover bg-slate-800 border border-slate-700 shrink-0 mt-0.5"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between mb-0.5">
                          <span className={`text-[11px] font-semibold ${isReplyMe ? 'text-teal-400' : 'text-slate-300'}`}>
                            {isReplyMe ? 'You' : reply.sender?.display_name}
                          </span>
                          <div className="flex items-center gap-1">
                            <span className="text-[10px] text-slate-500 font-mono tabular-nums">
                              {formatMessageTime(reply.created_at)}
                            </span>
                            {isReplyMe && (
                              <span className="inline-flex items-center">
                                {reply.status === 'pending' && <Clock className="w-2.5 h-2.5 animate-spin opacity-80" />}
                                {reply.status === 'sent' && <Check className="w-2.5 h-2.5 text-slate-400" />}
                                {reply.status === 'delivered' && <CheckCheck className="w-2.5 h-2.5 text-slate-400" />}
                                {reply.status === 'read' && <CheckCheck className="w-3 h-3 text-sky-400 font-bold" />}
                              </span>
                            )}
                          </div>
                        </div>

                        {reply.image_url && (
                          <div
                            className="relative group/threply cursor-pointer mb-1.5 rounded-xl overflow-hidden border border-slate-800 max-w-xs"
                            onClick={() =>
                              setViewerImage({
                                imageUrl: reply.image_url!,
                                senderName: reply.sender?.display_name,
                                timestamp: reply.created_at,
                                caption: reply.text !== '📷 Photo' ? reply.text : undefined,
                              })
                            }
                          >
                            <img
                              src={reply.image_url}
                              alt="Attachment"
                              className="w-full max-h-48 object-cover group-hover/threply:scale-102 transition duration-200"
                            />
                            <div className="absolute inset-0 bg-slate-950/30 opacity-0 group-hover/threply:opacity-100 flex items-center justify-center transition">
                              <span className="px-2 py-1 rounded-md bg-slate-950/80 text-white text-[10px] font-medium flex items-center gap-1 shadow-sm">
                                <Maximize2 className="w-3 h-3" /> Zoom
                              </span>
                            </div>
                          </div>
                        )}

                        {reply.audio_url ? (
                          <AudioMessagePlayer
                            audioUrl={reply.audio_url}
                            duration={reply.audio_duration}
                            isSender={isReplyMe}
                          />
                        ) : (
                          (reply.text !== '📷 Photo' || !reply.image_url) && (
                            <p className="text-xs text-slate-200 leading-relaxed break-words">{reply.text}</p>
                          )
                        )}
                      </div>
                    </div>
                  );
                });
              })()}
              <div ref={threadEndRef} />
            </div>

            {/* Thread Emoji Picker */}
            {showThreadEmojiPicker && (
              <div className="absolute bottom-16 left-3 z-50">
                <EmojiPicker
                  onSelectEmoji={(emoji) => {
                    setThreadInputText((prev) => prev + emoji);
                  }}
                  onClose={() => setShowThreadEmojiPicker(false)}
                />
              </div>
            )}

            {/* Thread Reply Composer Footer */}
            <div className="p-2 sm:p-2.5 border-t border-slate-800/90 bg-slate-950/95 shrink-0 box-border w-full">
              <form onSubmit={handleSendThreadReply} className="flex items-center gap-1.5 w-full min-w-0 bg-slate-900 border border-slate-800 rounded-2xl px-2 py-1 focus-within:border-teal-500/80 transition-colors">
                <button
                  type="button"
                  onClick={() => setShowThreadEmojiPicker(!showThreadEmojiPicker)}
                  className="p-1.5 text-slate-400 hover:text-emerald-400 hover:bg-slate-800/80 rounded-xl transition cursor-pointer shrink-0"
                  title="Add emoji"
                >
                  <Smile className="w-4 h-4" />
                </button>
                <input
                  type="text"
                  value={threadInputText}
                  onChange={(e) => setThreadInputText(e.target.value)}
                  placeholder="Reply in thread..."
                  className="flex-1 min-w-0 bg-transparent text-slate-100 text-xs sm:text-sm px-1.5 py-1.5 focus:outline-hidden placeholder:text-slate-500"
                />
                <button
                  type="submit"
                  disabled={!threadInputText.trim() || isThreadSending}
                  className={`p-2 rounded-xl text-white transition active:scale-95 shrink-0 flex items-center justify-center ${
                    threadInputText.trim() && !isThreadSending
                      ? 'bg-teal-600 hover:bg-teal-500 shadow-md cursor-pointer'
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed opacity-60'
                  }`}
                  title="Send reply"
                >
                  {isThreadSending ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-white" />
                  ) : (
                    <Send className="w-3.5 h-3.5" />
                  )}
                </button>
              </form>
            </div>
          </aside>
        )}
      </div>

      {/* Full-Featured Image Lightbox Viewer Modal */}
      <ImageViewerModal
        isOpen={Boolean(viewerImage)}
        image={viewerImage}
        onClose={() => setViewerImage(null)}
      />
    </main>
  );
};
