import React, { useState, useEffect } from 'react';
import { Search, X, MessageSquare, Check, User } from 'lucide-react';
import { useAuth } from '../context/AuthContext.js';
import { useChat } from '../context/ChatContext.js';
import { useLanguage } from '../context/LanguageContext.js';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const UserSearchModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { token, user } = useAuth();
  const { createDirectChat } = useChat();
  const { t, language } = useLanguage();

  const [searchQuery, setSearchQuery] = useState('');
  const [users, setUsers] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isCreating, setIsCreating] = useState(false);

  useEffect(() => {
    if (!isOpen || !token) return;

    const timer = setTimeout(async () => {
      setIsSearching(true);
      try {
        const res = await fetch(`/api/users/search/?q=${encodeURIComponent(searchQuery)}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          setUsers(data.users || []);
        }
      } catch (err) {
        console.warn('Network issue searching users:', err);
      } finally {
        setIsSearching(false);
      }
    }, 250);

    return () => clearTimeout(timer);
  }, [searchQuery, isOpen, token]);

  const handleStartChat = async (targetUserId: string) => {
    setIsCreating(true);
    await createDirectChat(targetUserId);
    setIsCreating(false);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
      <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl p-6 text-slate-100 animate-in fade-in zoom-in-95 flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Search className="w-5 h-5 text-emerald-400" />
            {t.search_users}
          </h2>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Input */}
        <div className="mt-4 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.search_by_username}
            autoFocus
            className="w-full bg-slate-800/90 text-slate-100 text-sm rounded-xl pl-10 pr-4 py-2.5 border border-slate-700 focus:outline-hidden focus:border-emerald-500 transition"
          />
        </div>

        {/* User Results List */}
        <div className="mt-4 flex-1 overflow-y-auto divide-y divide-slate-800/60 pr-1">
          {isSearching ? (
            <div className="py-8 text-center text-slate-400 text-xs">
              <div className="w-5 h-5 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
              Searching users...
            </div>
          ) : users.length === 0 ? (
            <div className="py-8 text-center text-slate-400 text-xs">
              No users found matching &quot;{searchQuery}&quot;
            </div>
          ) : (
            users.map((u) => (
              <div key={u.id} className="py-3 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <img
                      src={u.avatar_url || '/avatars/panda-emerald.svg'}
                      alt={u.display_name}
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        e.currentTarget.src = '/avatars/panda-emerald.svg';
                      }}
                      className="w-10 h-10 rounded-full object-cover bg-slate-800 border border-slate-700"
                    />
                    <span
                      className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border border-slate-900 ${
                        u.is_online ? 'bg-emerald-500' : 'bg-slate-500'
                      }`}
                    />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-white">{u.display_name}</h3>
                    <p className="text-xs text-slate-400">@{u.username}</p>
                  </div>
                </div>

                <button
                  onClick={() => handleStartChat(u.id)}
                  disabled={isCreating}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow transition active:scale-95"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>{t.start_conversation}</span>
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
