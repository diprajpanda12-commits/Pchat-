import React, { useState } from 'react';
import { Download, Smartphone, X, CheckCircle2 } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall.js';

interface Props {
  className?: string;
  lang?: 'en' | 'bn';
}

export const PWAInstallButton: React.FC<Props> = ({ className = '', lang = 'en' }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [showAndroidGuide, setShowAndroidGuide] = useState(false);

  if (isInstalled) {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 rounded-full">
        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
        {lang === 'bn' ? 'ইনস্টল করা আছে' : 'PWA Installed'}
      </span>
    );
  }

  return (
    <>
      {isInstallable ? (
        <button
          onClick={install}
          title={lang === 'bn' ? 'অ্যান্ড্রয়েড/পিসিতে অ্যাপ ইনস্টল করুন' : 'Install PChat App on Android / Desktop'}
          className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow transition-all active:scale-95 ${className}`}
        >
          <Download className="w-3.5 h-3.5" />
          <span>{lang === 'bn' ? 'অ্যাপ ইনস্টল করুন' : 'Install App'}</span>
        </button>
      ) : isIOS ? (
        <button
          onClick={() => setShowIOSGuide(true)}
          title="Install on iOS"
          className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition ${className}`}
        >
          <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
          <span>{lang === 'bn' ? 'আইওএস-এ ইনস্টল' : 'Install on iOS'}</span>
        </button>
      ) : (
        <button
          onClick={() => setShowAndroidGuide(true)}
          title="PWA Install Info"
          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 border border-slate-700/60 text-xs font-medium transition ${className}`}
        >
          <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
          <span>{lang === 'bn' ? 'মোবাইল PWA' : 'PWA Info'}</span>
        </button>
      )}

      {/* iOS Install Modal */}
      {showIOSGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-700 p-6 shadow-2xl text-slate-100 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold flex items-center gap-2 text-emerald-400">
                <Smartphone className="w-5 h-5" />
                {lang === 'bn' ? 'আইফোনে ইনস্টল নির্দেশিকা' : 'Install on iPhone / iPad'}
              </h3>
              <button onClick={() => setShowIOSGuide(false)} className="text-slate-400 hover:text-white p-1">
                <X className="w-4 h-4" />
              </button>
            </div>
            <ol className="mt-4 space-y-3 text-xs leading-relaxed text-slate-300">
              <li className="flex gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-900 text-emerald-300 flex items-center justify-center shrink-0 font-bold">1</span>
                <span>{lang === 'bn' ? 'সাফারি ব্রাউজারে শেয়ার (Share) বাটনে চাপ দিন।' : 'Tap the Share button in Safari toolbar.'}</span>
              </li>
              <li className="flex gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-900 text-emerald-300 flex items-center justify-center shrink-0 font-bold">2</span>
                <span>{lang === 'bn' ? 'নিচে স্ক্রোল করে "Add to Home Screen" অপশন বেছে নিন।' : 'Scroll down and tap "Add to Home Screen".'}</span>
              </li>
              <li className="flex gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-900 text-emerald-300 flex items-center justify-center shrink-0 font-bold">3</span>
                <span>{lang === 'bn' ? 'উপরের ডান কোণে "Add" চাপুন। হোম স্ক্রিনে PChat আইকন যুক্ত হবে।' : 'Tap "Add" in the top right. PChat is now on your home screen!'}</span>
              </li>
            </ol>
            <button
              onClick={() => setShowIOSGuide(false)}
              className="mt-6 w-full rounded-xl bg-emerald-600 hover:bg-emerald-500 py-2.5 text-xs font-semibold text-white shadow"
            >
              {lang === 'bn' ? 'বুঝেছি' : 'Got it'}
            </button>
          </div>
        </div>
      )}

      {/* Android / General PWA Modal */}
      {showAndroidGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-700 p-6 shadow-2xl text-slate-100 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold flex items-center gap-2 text-emerald-400">
                <Smartphone className="w-5 h-5" />
                {lang === 'bn' ? 'অ্যান্ড্রয়েড PWA ইনস্টলেশন' : 'Android PWA Installation'}
              </h3>
              <button onClick={() => setShowAndroidGuide(false)} className="text-slate-400 hover:text-white p-1">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="mt-4 space-y-3 text-xs leading-relaxed text-slate-300">
              <p>
                {lang === 'bn'
                  ? 'PChat একটি সম্পূর্ণ প্রগ্রেসিভ ওয়েব অ্যাপ (PWA)। ক্রোম বা যেকোনো ব্রাউজারে ৩-ডট মেনু চাপুন এবং "Install App" বা "Add to Home screen" নির্বাচন করুন।'
                  : 'PChat is a full Progressive Web App (PWA). In Chrome or your Android browser, tap the 3-dot menu and select "Install App" or "Add to Home Screen" to install it natively!'}
              </p>
              <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700 text-slate-300">
                <p className="font-semibold text-emerald-400 mb-1">
                  {lang === 'bn' ? 'বৈশিষ্ট্যসমূহ:' : 'PWA Features:'}
                </p>
                <ul className="list-disc pl-4 space-y-1">
                  <li>{lang === 'bn' ? 'ফুল-স্ক্রিন অ্যাপ মোড (কোনো ব্রাউজার বার নেই)' : 'Full-screen standalone app mode'}</li>
                  <li>{lang === 'bn' ? 'অফলাইন ও ব্যাকগ্রাউন্ড ক্যাশিং' : 'Offline service worker caching'}</li>
                  <li>{lang === 'bn' ? 'কম্প্যাক্ট মেমোরি ও কম ডাটা খরচ' : 'Low memory & battery efficient'}</li>
                </ul>
              </div>
            </div>
            <button
              onClick={() => setShowAndroidGuide(false)}
              className="mt-5 w-full rounded-xl bg-emerald-600 hover:bg-emerald-500 py-2.5 text-xs font-semibold text-white shadow"
            >
              {lang === 'bn' ? 'ঠিক আছে' : 'OK'}
            </button>
          </div>
        </div>
      )}
    </>
  );
};
