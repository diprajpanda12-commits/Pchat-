import React from 'react';
import { ShieldCheck, X, FileCode, Terminal, Smartphone } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext.js';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const DjangoDocsModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { language } = useLanguage();
  const isBn = language === 'bn';

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
      <div className="w-full max-w-3xl rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl p-6 text-slate-100 animate-in fade-in zoom-in-95 flex flex-col max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-emerald-400" />
            <h2 className="text-base md:text-lg font-bold text-white">
              {isBn ? 'PChat জ্যাঙ্গো ও রেপ্লিট আর্কিটেকচার নির্দেশিকা' : 'PChat Django & Replit Architecture Guide'}
            </h2>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-4 space-y-5 text-xs md:text-sm text-slate-300 leading-relaxed">
          {/* Quick Overview */}
          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800">
            <h3 className="font-bold text-emerald-400 mb-2 flex items-center gap-1.5">
              <FileCode className="w-4 h-4" />
              {isBn ? '১. সিস্টেম পরিচিতি' : '1. System Overview'}
            </h3>
            <p>
              {isBn
                ? 'PChat হলো একটি পূর্ণাঙ্গ রিয়েল-টাইম মেসেজিং প্ল্যাটফর্ম যা টেলিগ্রাম ও মেসেঞ্জারের সেরা ফিচারগুলোকে একত্রিত করে নির্মিত। এটি ব্যাকএন্ডে পাইথন জ্যাঙ্গো (Django REST Framework + Django Channels + WebSockets) এবং ফ্রন্টএন্ডে রিয়েল-টাইম রিঅ্যাক্ট PWA সমর্থন করে।'
                : 'PChat (Panda Chat) is a full-stack real-time messaging system built with modern WebSocket architectures, Django REST Framework, Django Channels, SQLite persistence, and installable Android PWA support.'}
            </p>
          </div>

          {/* WebSocket Routing */}
          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800">
            <h3 className="font-bold text-teal-400 mb-2 flex items-center gap-1.5">
              <Terminal className="w-4 h-4" />
              {isBn ? '২. ওয়েবসকেট চ্যানেল রাউটিং' : '2. Real-Time WebSocket Channel Routing'}
            </h3>
            <div className="font-mono text-xs bg-slate-900 p-3 rounded-lg border border-slate-800 text-emerald-300">
              ws://host/ws/chat/&lt;conversation_id&gt;/?token=&lt;authToken&gt;<br />
              ws://host/ws/general/?token=&lt;authToken&gt;
            </div>
            <ul className="list-disc pl-5 mt-2 space-y-1 text-slate-400">
              <li><strong>Session Authentication</strong>: Never trusts JavaScript sender_id; determines identity strictly from authenticated token.</li>
              <li><strong>Membership Guard</strong>: Rejects unauthorized connection attempts with 403 Forbidden.</li>
              <li><strong>Delivery Receipts</strong>: Pending ➔ Sent ➔ Delivered ➔ Read.</li>
            </ul>
          </div>

          {/* Android PWA */}
          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800">
            <h3 className="font-bold text-sky-400 mb-2 flex items-center gap-1.5">
              <Smartphone className="w-4 h-4" />
              {isBn ? '৩. অ্যান্ড্রয়েড PWA সাপোর্ট' : '3. Android PWA Support'}
            </h3>
            <p>
              {isBn
                ? 'PChat-এ সম্পূর্ণ সার্ভিস ওয়ার্কার (Service Worker) এবং Web App Manifest কনফিগার করা আছে। ক্রোম অথবা যেকোনো অ্যান্ড্রয়েড ব্রাউজার থেকে "Install PChat" চাপলে কোনো APK ডাউনলোড ছাড়াই এটি সরাসরি নেটিভ অ্যাপ হিসেবে ইনস্টল হয়ে যায়।'
                : 'PChat includes full W3C Web App Manifest (standalone display, theme-color #059669, maskable 192x192 & 512x512 icons, iOS splash support) and Workbox precaching.'}
            </p>
          </div>

          {/* Replit & Environment Variables */}
          <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800">
            <h3 className="font-bold text-amber-400 mb-2">
              {isBn ? '৪. পরিবেশ ভেরিয়েবল (.env)' : '4. Environment Variables (.env)'}
            </h3>
            <div className="font-mono text-xs bg-slate-900 p-3 rounded-lg border border-slate-800 text-slate-300 space-y-1">
              <div>DEBUG=True</div>
              <div>SECRET_KEY=pchat-super-secret-key-32-chars-minimum</div>
              <div>ALLOWED_HOSTS=*</div>
              <div>CORS_ALLOWED_ORIGINS=http://localhost:3000</div>
              <div>REDIS_URL=redis://localhost:6379/0 (Optional: fallback to in-memory)</div>
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="mt-5 w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs transition"
        >
          {isBn ? 'বন্ধ করুন' : 'Close'}
        </button>
      </div>
    </div>
  );
};
