import React from 'react';
import { useChat } from '../context/ChatContext';
import { MessageSquare, X } from 'lucide-react';

export const InAppNotificationToast: React.FC = () => {
  const { inAppToast, dismissInAppToast, selectConversation } = useChat();

  if (!inAppToast) return null;

  const handleOpenChat = () => {
    selectConversation(inAppToast.conversation_id);
    dismissInAppToast();
  };

  return (
    <aside
      aria-label="New message notification"
      className="fixed top-4 right-4 z-50 max-w-sm w-full mx-auto p-3.5 bg-neutral-900/95 backdrop-blur-md border border-emerald-500/40 text-neutral-100 rounded-xl shadow-2xl shadow-emerald-950/40 flex items-start space-x-3 animate-in fade-in slide-in-from-top-3 duration-200"
    >
      <div className="flex-shrink-0 mt-0.5">
        {inAppToast.avatar_url ? (
          <img
            src={inAppToast.avatar_url}
            alt={inAppToast.sender_name || 'Sender'}
            className="w-10 h-10 rounded-full object-cover border border-emerald-500/50"
          />
        ) : (
          <div className="w-10 h-10 rounded-full bg-emerald-700/80 text-white flex items-center justify-center font-semibold text-sm">
            {inAppToast.sender_name ? inAppToast.sender_name.slice(0, 2).toUpperCase() : <MessageSquare className="w-5 h-5 text-emerald-300" />}
          </div>
        )}
      </div>

      <div className="flex-1 min-w-0 pr-1">
        <div className="flex items-center justify-between">
          <h4 className="text-sm font-semibold text-white truncate">
            {inAppToast.title || inAppToast.sender_name || 'New Message'}
          </h4>
        </div>
        <p className="text-xs text-neutral-300 line-clamp-2 mt-0.5 break-words">
          {inAppToast.body}
        </p>
        <div className="mt-2 flex items-center space-x-2">
          <button
            type="button"
            onClick={handleOpenChat}
            className="text-xs bg-emerald-600 hover:bg-emerald-500 text-white px-2.5 py-1 rounded-md font-medium transition-colors shadow-sm"
          >
            Open Chat
          </button>
          <button
            type="button"
            onClick={dismissInAppToast}
            className="text-xs text-neutral-400 hover:text-white px-2 py-1 rounded transition-colors"
          >
            Dismiss
          </button>
        </div>
      </div>

      <button
        type="button"
        onClick={dismissInAppToast}
        aria-label="Close notification"
        className="flex-shrink-0 text-neutral-400 hover:text-neutral-100 p-1 rounded-lg hover:bg-neutral-800 transition-colors"
      >
        <X className="w-4 h-4" />
      </button>
    </aside>
  );
};
