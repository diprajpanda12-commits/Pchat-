import React, { useState, useMemo } from 'react';
import { Search, X, Smile, Heart, Coffee, Sparkles, Activity, Clock } from 'lucide-react';

interface Props {
  onSelectEmoji: (emoji: string) => void;
  onClose?: () => void;
  className?: string;
}

interface EmojiCategory {
  id: string;
  name: string;
  icon: React.ReactNode;
  emojis: string[];
}

const EMOJI_CATEGORIES: EmojiCategory[] = [
  {
    id: 'pchat',
    name: 'PChat Specials',
    icon: <span className="text-sm">🐼</span>,
    emojis: ['🐼', '🎋', '🐾', '🌿', '🌱', '🍜', '🍵', '☕', '🌟', '✨', '🔥', '💖', '❤️', '💯', '🚀'],
  },
  {
    id: 'smileys',
    name: 'Smileys & Emotion',
    icon: <Smile className="w-4 h-4" />,
    emojis: [
      '😀', '😃', '😄', '😁', '😆', '😅', '🤣', '😂', '🙂', '😉',
      '😊', '😇', '🥰', '😍', '🤩', '😘', '😋', '😜', '🤪', '😎',
      '🥳', '😏', '🧐', '🤓', '🥺', '😢', '😭', '😤', '😡', '🤯',
      '😱', '🥱', '😴', '😷', '🤒', '🤕', '🤢', '🤮', '👻', '🤖',
    ],
  },
  {
    id: 'gestures',
    name: 'Gestures & People',
    icon: <span className="text-sm">👍</span>,
    emojis: [
      '👍', '👎', '👏', '🙌', '👐', '🤲', '🤝', '🙏', '✌️', '🤞',
      '🤟', '🤘', '🤙', '👈', '👉', '👆', '👇', '☝️', '👋', '🤚',
      '👊', '✊', '🤛', '🤜', '💪', '💅', '🤳', '💃', '🕺', '🧘',
    ],
  },
  {
    id: 'animals',
    name: 'Animals & Nature',
    icon: <span className="text-sm">🐾</span>,
    emojis: [
      '🐼', '🎋', '🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐨',
      '🐯', '🦁', '🐮', '🐷', '🐸', '🐵', '🐔', '🐧', '🐦', '🦆',
      '🦅', '🦉', '🦇', '🐺', '🐗', '🐴', '🦄', '🐝', '🐛', '🦋',
      '🐌', '🐞', '🐢', '🐍', '🐙', '🐬', '🐳', '🌸', '🌹', '🌻',
    ],
  },
  {
    id: 'food',
    name: 'Food & Drink',
    icon: <Coffee className="w-4 h-4" />,
    emojis: [
      '☕', '🍵', '🧃', '🥤', '🍕', '🍔', '🍟', '🌭', '🥪', '🌮',
      '🌯', '🍣', '🍱', '🍜', '🍲', '🍝', '🥟', '🍰', '🧁', '🍦',
      '🍩', '🍪', '🍫', '🍿', '🍎', '🍓', '🍌', '🍉', '🥑', '🥦',
    ],
  },
  {
    id: 'activities',
    name: 'Objects & Fun',
    icon: <Sparkles className="w-4 h-4" />,
    emojis: [
      '🎉', '🎊', '🎈', '🎁', '🏆', '🥇', '🥈', '⚽', '🏀', '🏈',
      '🎾', '🎮', '🕹️', '🎸', '🎨', '🎬', '🎤', '🎧', '📱', '💻',
      '💡', '💬', '📢', '⏰', '📅', '📌', '🚀', '✈️', '🌈', '⚡',
    ],
  },
];

// Flat search index
const EMOJI_KEYWORDS: Record<string, string[]> = {
  '🐼': ['panda', 'bear', 'cute', 'bamboo', 'pchat', 'animal'],
  '🎋': ['bamboo', 'tanabata', 'plant', 'tree', 'pchat', 'green'],
  '🐾': ['paw', 'prints', 'dog', 'cat', 'animal', 'panda', 'feet'],
  '❤️': ['heart', 'love', 'red', 'like'],
  '💖': ['sparkling heart', 'love', 'glitter', 'pink'],
  '👍': ['thumbs up', 'like', 'approve', 'yes', 'ok'],
  '👎': ['thumbs down', 'dislike', 'no', 'bad'],
  '🔥': ['fire', 'flame', 'lit', 'hot'],
  '😂': ['joy', 'laugh', 'cry laughing', 'funny', 'haha', 'lol'],
  '🤣': ['rofl', 'rolling on the floor laughing', 'haha'],
  '😍': ['heart eyes', 'love', 'crush', 'cute'],
  '🎉': ['party', 'celebration', 'tada', 'congrats'],
  '✨': ['sparkles', 'stars', 'magic', 'clean'],
  '🚀': ['rocket', 'launch', 'fast', 'moon', 'space'],
  '☕': ['coffee', 'tea', 'cafe', 'morning', 'drink'],
  '🍕': ['pizza', 'food', 'cheese'],
  '🍔': ['burger', 'hamburger', 'food'],
  '💯': ['100', 'hundred', 'perfect', 'score'],
  '👏': ['clap', 'applause', 'bravo', 'congrats'],
  '🙏': ['pray', 'please', 'thanks', 'namaste'],
  '😊': ['smile', 'happy', 'warm', 'blush'],
  '😎': ['cool', 'sunglasses', 'awesome'],
  '🥺': ['pleading', 'puppy eyes', 'beg', 'cute'],
  '😭': ['sob', 'crying', 'sad', 'tears'],
  '🤔': ['thinking', 'hmm', 'ponder', 'wonder'],
};

export const EmojiPicker: React.FC<Props> = ({ onSelectEmoji, onClose, className = '' }) => {
  const [activeCategory, setActiveCategory] = useState<string>('pchat');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Store recent emojis in localStorage
  const [recentEmojis, setRecentEmojis] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('pchat_recent_emojis');
      return stored ? JSON.parse(stored) : ['🐼', '🎋', '❤️', '👍', '🔥', '😂', '🎉', '✨'];
    } catch {
      return ['🐼', '🎋', '❤️', '👍', '🔥', '😂', '🎉', '✨'];
    }
  });

  const handleEmojiClick = (emoji: string) => {
    onSelectEmoji(emoji);
    // Update recent emojis
    try {
      const updated = [emoji, ...recentEmojis.filter((e) => e !== emoji)].slice(0, 16);
      setRecentEmojis(updated);
      localStorage.setItem('pchat_recent_emojis', JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  // Search filtered emojis
  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return null;
    const query = searchQuery.trim().toLowerCase();
    const results = new Set<string>();

    // Check keywords
    Object.entries(EMOJI_KEYWORDS).forEach(([emoji, keywords]) => {
      if (keywords.some((kw) => kw.includes(query))) {
        results.add(emoji);
      }
    });

    // Check all category emojis directly
    EMOJI_CATEGORIES.forEach((cat) => {
      cat.emojis.forEach((em) => {
        if (em.includes(query)) results.add(em);
      });
    });

    return Array.from(results);
  }, [searchQuery]);

  return (
    <div
      className={`w-72 sm:w-80 bg-slate-900/95 border border-slate-700/80 rounded-2xl shadow-2xl backdrop-blur-xl p-3 z-50 text-slate-100 flex flex-col select-none animate-in fade-in zoom-in-95 duration-150 ${className}`}
      onClick={(e) => e.stopPropagation()}
    >
      {/* Search Header */}
      <div className="flex items-center gap-2 mb-2 pb-2 border-b border-slate-800">
        <div className="relative flex-1">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search emoji (panda, love, clap...)"
            autoFocus
            className="w-full bg-slate-800/90 text-xs text-white placeholder-slate-400 pl-8 pr-7 py-1.5 rounded-xl border border-slate-700/70 focus:outline-hidden focus:border-emerald-500 transition"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-2 top-2 p-0.5 text-slate-400 hover:text-white"
            >
              <X className="w-3 h-3" />
            </button>
          )}
        </div>

        {onClose && (
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            title="Close"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Category Tabs (if not searching) */}
      {!searchQuery && (
        <div className="flex items-center justify-between gap-1 mb-2 px-1 py-1 bg-slate-950/60 rounded-xl border border-slate-800/70 shrink-0">
          {EMOJI_CATEGORIES.map((cat) => {
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setActiveCategory(cat.id)}
                title={cat.name}
                className={`p-1.5 rounded-lg transition flex items-center justify-center cursor-pointer ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-xs scale-105'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {cat.icon}
              </button>
            );
          })}
        </div>
      )}

      {/* Emoji Grid Scroll View */}
      <div className="max-h-56 overflow-y-auto pr-1 space-y-3 custom-scrollbar">
        {searchResults !== null ? (
          <div>
            <div className="text-[11px] font-semibold text-slate-400 mb-1.5 px-1">
              Search Results ({searchResults.length})
            </div>
            {searchResults.length === 0 ? (
              <div className="text-center py-6 text-xs text-slate-400">
                <span className="text-2xl block mb-1">🐼</span>
                No emoji found for "{searchQuery}"
              </div>
            ) : (
              <div className="grid grid-cols-7 sm:grid-cols-8 gap-1">
                {searchResults.map((emoji, idx) => (
                  <button
                    key={`${emoji}-${idx}`}
                    type="button"
                    onClick={() => handleEmojiClick(emoji)}
                    className="w-8 h-8 flex items-center justify-center text-lg hover:bg-slate-800 rounded-xl transition hover:scale-125 active:scale-95 cursor-pointer"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            )}
          </div>
        ) : (
          <>
            {/* Recent Emojis */}
            {recentEmojis.length > 0 && (
              <div>
                <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400 mb-1 px-1 flex items-center gap-1">
                  <Clock className="w-3 h-3 text-emerald-400" />
                  <span>Recent</span>
                </div>
                <div className="grid grid-cols-7 sm:grid-cols-8 gap-1">
                  {recentEmojis.map((emoji, idx) => (
                    <button
                      key={`recent-${emoji}-${idx}`}
                      type="button"
                      onClick={() => handleEmojiClick(emoji)}
                      className="w-8 h-8 flex items-center justify-center text-lg hover:bg-slate-800 rounded-xl transition hover:scale-125 active:scale-95 cursor-pointer"
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Active Category Emojis */}
            {EMOJI_CATEGORIES.filter((c) => c.id === activeCategory).map((cat) => (
              <div key={cat.id}>
                <div className="text-[10px] uppercase font-bold tracking-wider text-slate-400 mb-1 px-1">
                  {cat.name}
                </div>
                <div className="grid grid-cols-7 sm:grid-cols-8 gap-1">
                  {cat.emojis.map((emoji, idx) => (
                    <button
                      key={`${cat.id}-${emoji}-${idx}`}
                      type="button"
                      onClick={() => handleEmojiClick(emoji)}
                      className="w-8 h-8 flex items-center justify-center text-lg hover:bg-slate-800 rounded-xl transition hover:scale-125 active:scale-95 cursor-pointer"
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </>
        )}
      </div>

      {/* Bottom Panda Quick Tag */}
      <div className="mt-2 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400 px-1">
        <span className="flex items-center gap-1 text-emerald-400/90 font-medium">
          <span>🐼 PChat Reactions & Emojis</span>
        </span>
        <button
          type="button"
          onClick={() => handleEmojiClick('🐼')}
          className="hover:scale-125 transition cursor-pointer text-sm"
          title="Instant Panda"
        >
          🐼
        </button>
      </div>
    </div>
  );
};
