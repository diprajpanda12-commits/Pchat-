import React, { useState } from 'react';
import { User, X, Lock, Check, Key, LogOut, Trash2, AlertTriangle } from 'lucide-react';
import { useAuth } from '../context/AuthContext.js';
import { useLanguage } from '../context/LanguageContext.js';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

import { AVATAR_CATALOG, AvatarOption } from '../utils/avatars.js';

export const ProfileModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { user, updateProfile, logout, deleteAccount } = useAuth();
  const { t } = useLanguage();

  const [displayName, setDisplayName] = useState(user?.display_name || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [avatarUrl, setAvatarUrl] = useState(user?.avatar_url || AVATAR_CATALOG[0].url);
  const [avatarCategory, setAvatarCategory] = useState<'All' | 'Popular' | 'Heroes' | 'Vibe' | 'Special'>('All');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  if (!isOpen || !user) return null;

  const filteredAvatars = avatarCategory === 'All'
    ? AVATAR_CATALOG
    : AVATAR_CATALOG.filter(a => a.category === avatarCategory);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setMessage(null);

    const payload: any = {
      display_name: displayName,
      bio,
      avatar_url: avatarUrl,
    };

    if (newPassword) {
      payload.current_password = currentPassword;
      payload.new_password = newPassword;
    }

    const res = await updateProfile(payload);
    setIsSaving(false);

    if (res.success) {
      setMessage({ text: 'Profile updated successfully!', type: 'success' });
      setCurrentPassword('');
      setNewPassword('');
    } else {
      setMessage({ text: res.error || 'Failed to update profile.', type: 'error' });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
      <div className="w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 text-slate-100 animate-in fade-in zoom-in-95 flex flex-col max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <User className="w-5 h-5 text-emerald-400" />
            {t.user_profile}
          </h2>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {message && (
          <div
            className={`mt-3 p-2.5 rounded-xl text-xs font-semibold ${
              message.type === 'success'
                ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/80'
                : 'bg-rose-950/80 text-rose-300 border border-rose-800/80'
            }`}
          >
            {message.text}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          {/* Active Avatar Preview & Multi-Avatar Picker */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
            <div className="flex items-center gap-4 mb-3">
              <div className="relative shrink-0">
                <img
                  src={avatarUrl}
                  alt={displayName}
                  onError={(e) => {
                    e.currentTarget.src = '/avatars/panda-emerald.svg';
                  }}
                  className="w-16 h-16 rounded-2xl object-cover ring-2 ring-emerald-500 shadow-lg bg-slate-900"
                />
                <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-slate-900 flex items-center justify-center shadow-xs">
                  <Check className="w-2.5 h-2.5 text-white" />
                </span>
              </div>
              <div className="min-w-0">
                <h3 className="text-xs font-bold text-white uppercase tracking-wider text-emerald-400">
                  Select Your Panda Avatar ({AVATAR_CATALOG.length} Available)
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Pick a distinctive persona to represent you across all PChat chats and threads.
                </p>
              </div>
            </div>

            {/* Category tabs */}
            <div className="flex items-center gap-1.5 mb-2.5 overflow-x-auto pb-1 text-[11px] scrollbar-none">
              {(['All', 'Popular', 'Heroes', 'Vibe', 'Special'] as const).map((cat) => (
                <button
                  type="button"
                  key={cat}
                  onClick={() => setAvatarCategory(cat)}
                  className={`px-2.5 py-1 rounded-lg font-semibold transition cursor-pointer shrink-0 ${
                    avatarCategory === cat
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Avatar Grid */}
            <div className="grid grid-cols-4 sm:grid-cols-6 gap-2 max-h-48 overflow-y-auto p-1 pr-1.5">
              {filteredAvatars.map((av) => {
                const isSelected = avatarUrl === av.url;
                return (
                  <button
                    type="button"
                    key={av.id}
                    onClick={() => setAvatarUrl(av.url)}
                    title={`${av.name}: ${av.description}`}
                    className={`flex flex-col items-center p-1.5 rounded-xl border transition-all cursor-pointer group relative ${
                      isSelected
                        ? 'border-emerald-400 bg-emerald-950/50 ring-2 ring-emerald-400/50 scale-102 shadow-md shadow-emerald-950/40'
                        : 'border-slate-800 bg-slate-900/90 hover:bg-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <img
                      src={av.url}
                      alt={av.name}
                      className="w-10 h-10 rounded-lg object-cover transition-transform group-hover:scale-105"
                    />
                    <span className="text-[9px] font-medium text-slate-300 truncate w-full text-center mt-1">
                      {av.name.split(' ')[0]}
                    </span>
                    {isSelected && (
                      <div className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-500 rounded-full flex items-center justify-center">
                        <Check className="w-2.5 h-2.5 text-white" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">{t.username}</label>
            <input
              type="text"
              disabled
              value={`@${user.username}`}
              className="w-full bg-slate-800/50 text-slate-400 text-xs rounded-xl px-3.5 py-2.5 border border-slate-700/50 cursor-not-allowed"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">{t.email}</label>
            <input
              type="email"
              disabled
              value={user.email}
              className="w-full bg-slate-800/50 text-slate-400 text-xs rounded-xl px-3.5 py-2.5 border border-slate-700/50 cursor-not-allowed"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">{t.display_name}</label>
            <input
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              className="w-full bg-slate-800 text-slate-100 text-xs rounded-xl px-3.5 py-2.5 border border-slate-700 focus:outline-hidden focus:border-emerald-500 transition"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">{t.bio}</label>
            <textarea
              rows={2}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="w-full bg-slate-800 text-slate-100 text-xs rounded-xl px-3.5 py-2.5 border border-slate-700 focus:outline-hidden focus:border-emerald-500 transition resize-none"
            />
          </div>

          {/* Change Password Block */}
          <div className="pt-2 border-t border-slate-800">
            <h4 className="text-xs font-bold text-slate-300 mb-2 flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-emerald-400" />
              {t.change_password}
            </h4>
            <div className="space-y-2">
              <input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder={t.current_password}
                className="w-full bg-slate-800 text-slate-100 text-xs rounded-xl px-3.5 py-2 border border-slate-700 focus:outline-hidden focus:border-emerald-500"
              />
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder={t.new_password}
                className="w-full bg-slate-800 text-slate-100 text-xs rounded-xl px-3.5 py-2 border border-slate-700 focus:outline-hidden focus:border-emerald-500"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isSaving}
            className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow transition active:scale-95 cursor-pointer"
          >
            {isSaving ? 'Saving...' : t.save_profile}
          </button>
        </form>

        {/* Account Session & Logout Section */}
        <div className="mt-5 pt-4 border-t border-slate-800">
          <h4 className="text-xs font-bold text-slate-300 mb-1 flex items-center gap-1.5">
            <LogOut className="w-3.5 h-3.5 text-rose-400" />
            <span>Account Session</span>
          </h4>
          <p className="text-[11px] text-slate-400 mb-3">
            Sign out of PChat on this device. Your messages and media will remain securely saved.
          </p>
          <button
            type="button"
            onClick={() => {
              onClose();
              logout();
            }}
            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-rose-950/70 border border-slate-700/80 hover:border-rose-800/80 text-rose-300 hover:text-rose-200 font-bold text-xs transition active:scale-95 flex items-center justify-center gap-2 cursor-pointer shadow-xs"
          >
            <LogOut className="w-4 h-4 text-rose-400" />
            <span>{t.logout || 'Log Out of PChat'}</span>
          </button>
        </div>

        {/* Danger Zone: Remove / Delete Account */}
        <div className="mt-4 pt-4 border-t border-rose-950/60 bg-rose-950/20 -mx-6 -mb-6 p-6 rounded-b-3xl">
          <h4 className="text-xs font-bold text-rose-400 mb-1 flex items-center gap-1.5">
            <Trash2 className="w-3.5 h-3.5 text-rose-400" />
            <span>Remove Unnecessary Account</span>
          </h4>
          <p className="text-[11px] text-slate-400 mb-3">
            Permanently delete this account (@{user.username}) and its data from the PChat database.
          </p>

          {!showDeleteConfirm ? (
            <button
              type="button"
              onClick={() => setShowDeleteConfirm(true)}
              className="w-full py-2 px-3 rounded-xl bg-rose-950/60 hover:bg-rose-900/60 border border-rose-800/60 text-rose-300 hover:text-rose-100 font-semibold text-xs transition active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5 text-rose-400" />
              <span>Delete This Account</span>
            </button>
          ) : (
            <div className="p-3 bg-rose-950/90 border border-rose-700 rounded-2xl animate-in fade-in space-y-2.5">
              <div className="flex items-start gap-2 text-rose-200 text-xs">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>
                  Are you sure you want to permanently delete <strong>@{user.username}</strong>? This action cannot be undone.
                </span>
              </div>
              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowDeleteConfirm(false)}
                  disabled={isDeleting}
                  className="flex-1 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={isDeleting}
                  onClick={async () => {
                    setIsDeleting(true);
                    const res = await deleteAccount();
                    setIsDeleting(false);
                    if (res.success) {
                      onClose();
                    } else {
                      setMessage({ text: res.error || 'Failed to delete account.', type: 'error' });
                      setShowDeleteConfirm(false);
                    }
                  }}
                  className="flex-1 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-md shadow-rose-950/50 transition active:scale-95 cursor-pointer flex items-center justify-center gap-1.5"
                >
                  {isDeleting ? (
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Confirm Delete</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
