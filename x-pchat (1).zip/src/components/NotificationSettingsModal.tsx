import React, { useState, useEffect } from 'react';
import {
  Bell,
  BellOff,
  Volume2,
  VolumeX,
  Vibrate,
  Eye,
  EyeOff,
  Smartphone,
  Laptop,
  Trash2,
  Send,
  CheckCircle2,
  AlertCircle,
  X,
  RefreshCw,
  ShieldCheck,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.js';
import { useChat } from '../context/ChatContext.js';

interface NotificationSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface NotificationSettings {
  push_enabled: boolean;
  sound_enabled: boolean;
  vibration_enabled: boolean;
  show_preview: boolean;
}

interface DeviceRecord {
  id: string;
  device_token: string;
  device_type: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export const NotificationSettingsModal: React.FC<NotificationSettingsModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { token } = useAuth();
  const { soundEnabled, toggleSound } = useChat();

  const [settings, setSettings] = useState<NotificationSettings>({
    push_enabled: true,
    sound_enabled: true,
    vibration_enabled: true,
    show_preview: true,
  });
  const [devices, setDevices] = useState<DeviceRecord[]>([]);
  const [permissionStatus, setPermissionStatus] = useState<NotificationPermission>('default');
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [testStatus, setTestStatus] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setPermissionStatus(Notification.permission);
    }
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen || !token) return;

    const fetchSettingsAndDevices = async () => {
      setIsLoading(true);
      setErrorMessage(null);
      try {
        const [settingsRes, devicesRes] = await Promise.all([
          fetch('/api/notifications/settings/', {
            headers: { Authorization: `Bearer ${token}` },
          }),
          fetch('/api/notifications/devices/', {
            headers: { Authorization: `Bearer ${token}` },
          }),
        ]);

        if (settingsRes.ok) {
          const data = await settingsRes.json();
          if (data.settings) {
            setSettings({
              push_enabled: Boolean(data.settings.push_enabled),
              sound_enabled: Boolean(data.settings.sound_enabled),
              vibration_enabled: Boolean(data.settings.vibration_enabled),
              show_preview: Boolean(data.settings.show_preview),
            });
          }
        }

        if (devicesRes.ok) {
          const dData = await devicesRes.json();
          setDevices(dData.devices || []);
        }
      } catch (err: any) {
        console.error('Failed to load notification settings:', err);
        setErrorMessage('Unable to load settings from server.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchSettingsAndDevices();
  }, [isOpen, token]);

  if (!isOpen) return null;

  const updateSettingsOnServer = async (newSettings: Partial<NotificationSettings>) => {
    const updated = { ...settings, ...newSettings };
    setSettings(updated);
    setIsSaving(true);
    setErrorMessage(null);

    try {
      const res = await fetch('/api/notifications/settings/', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(newSettings),
      });

      if (!res.ok) {
        throw new Error('Failed to save settings');
      }
    } catch (err: any) {
      console.error('Settings update error:', err);
      setErrorMessage('Could not update notification settings on server.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleRequestPermission = async () => {
    if (!('Notification' in window)) {
      setErrorMessage('This browser does not support Web Push notifications.');
      return;
    }

    try {
      const permission = await Notification.requestPermission();
      setPermissionStatus(permission);

      if (permission === 'granted') {
        // Register ServiceWorker and subscribe to Web Push / FCM
        if ('serviceWorker' in navigator) {
          const registration = await navigator.serviceWorker.register('/firebase-messaging-sw.js', {
            scope: '/',
          });
          await navigator.serviceWorker.ready;

          // Fetch VAPID key
          const vapidRes = await fetch('/api/push/vapid-key/', {
            headers: { Authorization: `Bearer ${token}` },
          });
          if (vapidRes.ok) {
            const { publicKey } = await vapidRes.json();
            if (publicKey) {
              const convertedVapidKey = urlBase64ToUint8Array(publicKey);
              const subscription = await registration.pushManager.subscribe({
                userVisibleOnly: true,
                applicationServerKey: convertedVapidKey,
              });

              // Send subscription to backend
              await fetch('/api/push/subscribe/', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({ subscription }),
              });

              // Also register device token record
              const rawToken = btoa(subscription.endpoint).slice(0, 48);
              const isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
              await fetch('/api/notifications/devices/', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({
                  device_token: rawToken,
                  device_type: isMobile ? 'android' : 'web',
                }),
              });

              // Refresh devices list
              const devicesRes = await fetch('/api/notifications/devices/', {
                headers: { Authorization: `Bearer ${token}` },
              });
              if (devicesRes.ok) {
                const dData = await devicesRes.json();
                setDevices(dData.devices || []);
              }
            }
          }
        }
        await updateSettingsOnServer({ push_enabled: true });
      }
    } catch (err: any) {
      console.error('Error requesting notification permission:', err);
      setErrorMessage(err.message || 'Error subscribing to notifications');
    }
  };

  const handleUnregisterDevice = async (deviceToken: string) => {
    try {
      const res = await fetch(`/api/notifications/devices/${encodeURIComponent(deviceToken)}/`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        setDevices((prev) => prev.filter((d) => d.device_token !== deviceToken));
      }
    } catch (err) {
      console.error('Failed to unregister device:', err);
    }
  };

  const handleSendTestNotification = async () => {
    setTestStatus('Dispatching test alert...');
    setErrorMessage(null);
    try {
      const res = await fetch('/api/notifications/test/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      });

      if (res.ok) {
        setTestStatus('✅ Test alert sent! Check your notification tray & chime.');
        setTimeout(() => setTestStatus(null), 4000);
      } else {
        throw new Error('Test notification failed');
      }
    } catch (err: any) {
      setErrorMessage('Failed to send test push notification.');
      setTestStatus(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in fade-in zoom-in-95">
        {/* Modal Header */}
        <div className="px-6 py-5 border-b border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">Notification Settings</h2>
              <p className="text-xs text-slate-400">Manage push notifications, chimes, and privacy</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm">
          {/* Permission Status Banner */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div
                className={`p-2 rounded-xl ${
                  permissionStatus === 'granted'
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                    : permissionStatus === 'denied'
                    ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                    : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                }`}
              >
                {permissionStatus === 'granted' ? (
                  <CheckCircle2 className="w-4 h-4" />
                ) : (
                  <AlertCircle className="w-4 h-4" />
                )}
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-200">
                  Browser Permission:{' '}
                  <span
                    className={`uppercase font-mono text-[11px] font-bold ${
                      permissionStatus === 'granted'
                        ? 'text-emerald-400'
                        : permissionStatus === 'denied'
                        ? 'text-rose-400'
                        : 'text-amber-400'
                    }`}
                  >
                    {permissionStatus}
                  </span>
                </p>
                <p className="text-[11px] text-slate-400">
                  {permissionStatus === 'granted'
                    ? 'Push alerts are allowed on this device'
                    : permissionStatus === 'denied'
                    ? 'Notifications are blocked in your browser settings'
                    : 'Permission requested on first toggle'}
                </p>
              </div>
            </div>

            {permissionStatus !== 'granted' && (
              <button
                type="button"
                onClick={handleRequestPermission}
                className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition shrink-0"
              >
                Grant Access
              </button>
            )}
          </div>

          {/* Preferences Toggles */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Preferences</h3>

            {/* Push Notifications Toggle */}
            <div className="p-3.5 rounded-2xl bg-slate-950/40 border border-slate-800/80 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-slate-800 text-emerald-400">
                  {settings.push_enabled ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
                </div>
                <div>
                  <p className="text-xs font-semibold text-white">Push Notifications</p>
                  <p className="text-[11px] text-slate-400">Receive alerts when the app is in the background</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.push_enabled}
                  onChange={(e) => {
                    const checked = e.target.checked;
                    if (checked && permissionStatus !== 'granted') {
                      handleRequestPermission();
                    } else {
                      updateSettingsOnServer({ push_enabled: checked });
                    }
                  }}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-800 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
              </label>
            </div>

            {/* Notification Sound Toggle */}
            <div className="p-3.5 rounded-2xl bg-slate-950/40 border border-slate-800/80 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-slate-800 text-cyan-400">
                  {settings.sound_enabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                </div>
                <div>
                  <p className="text-xs font-semibold text-white">Notification Sound</p>
                  <p className="text-[11px] text-slate-400">Play an audio chime on incoming messages</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.sound_enabled}
                  onChange={(e) => {
                    const checked = e.target.checked;
                    updateSettingsOnServer({ sound_enabled: checked });
                    if (checked !== soundEnabled) toggleSound();
                  }}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-800 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
              </label>
            </div>

            {/* Vibration Toggle */}
            <div className="p-3.5 rounded-2xl bg-slate-950/40 border border-slate-800/80 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-slate-800 text-purple-400">
                  <Vibrate className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-white">Vibration Haptics</p>
                  <p className="text-[11px] text-slate-400">Vibrate on mobile devices for new messages</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.vibration_enabled}
                  onChange={(e) => updateSettingsOnServer({ vibration_enabled: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-800 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
              </label>
            </div>

            {/* Message Preview Privacy Toggle */}
            <div className="p-3.5 rounded-2xl bg-slate-950/40 border border-slate-800/80 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-slate-800 text-amber-400">
                  {settings.show_preview ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                </div>
                <div>
                  <p className="text-xs font-semibold text-white">Message Preview</p>
                  <p className="text-[11px] text-slate-400">
                    {settings.show_preview
                      ? 'Show sender name and message text on lock screen'
                      : 'Hide message contents for privacy ("New message received")'}
                  </p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.show_preview}
                  onChange={(e) => updateSettingsOnServer({ show_preview: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-800 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
              </label>
            </div>
          </div>

          {/* Registered Devices List */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Registered Devices</h3>
              <span className="text-[11px] font-mono text-slate-500">{devices.length} active</span>
            </div>

            {devices.length === 0 ? (
              <div className="p-4 rounded-2xl bg-slate-950/40 border border-slate-800/80 text-center">
                <p className="text-xs text-slate-400">No external devices registered yet.</p>
                <p className="text-[11px] text-slate-500 mt-1">
                  Turn on push notifications above to link this browser or phone.
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {devices.map((device) => (
                  <div
                    key={device.id}
                    className="p-3 rounded-2xl bg-slate-950/50 border border-slate-800/80 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-xl bg-slate-800 text-slate-300">
                        {device.device_type === 'android' ? (
                          <Smartphone className="w-4 h-4 text-emerald-400" />
                        ) : (
                          <Laptop className="w-4 h-4 text-cyan-400" />
                        )}
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-white capitalize">
                          {device.device_type} Device
                        </p>
                        <p className="text-[10px] font-mono text-slate-500 truncate max-w-[200px]">
                          Token: {device.device_token.slice(0, 16)}...
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleUnregisterDevice(device.device_token)}
                      title="Unregister device"
                      className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-950/30 transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Test Push Notification */}
          <div className="pt-2 border-t border-slate-800/80 flex flex-col gap-2">
            <button
              type="button"
              onClick={handleSendTestNotification}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs transition border border-slate-700/60"
            >
              <Send className="w-3.5 h-3.5 text-emerald-400" />
              <span>Send Test Push Notification</span>
            </button>

            {testStatus && (
              <p className="text-xs text-center text-emerald-400 font-medium animate-in fade-in">
                {testStatus}
              </p>
            )}
            {errorMessage && (
              <p className="text-xs text-center text-rose-400 font-medium animate-in fade-in">
                {errorMessage}
              </p>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-slate-800/80 bg-slate-950/60 flex items-center justify-between">
          <div className="flex items-center gap-2 text-[11px] text-slate-400">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>SQLite WAL + FCM VAPID encrypted</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

// Helper for VAPID base64 conversion
function urlBase64ToUint8Array(base64String: string) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}
