import React, { useState, useEffect, useCallback } from 'react';
import {
  Activity,
  X,
  Wifi,
  WifiOff,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  ShieldAlert,
  Zap,
  Server,
  Terminal,
  Play,
  RotateCcw,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.js';
import { useChat } from '../context/ChatContext.js';
import { useLanguage } from '../context/LanguageContext.js';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onOpenTestRunner: () => void;
}

interface HandshakeStage {
  stage: string;
  passed: boolean;
  message: string;
  durationMs: number;
}

interface HandshakeTestResult {
  success: boolean;
  message?: string;
  error?: string;
  details?: string;
  rejectionCode?: number;
  totalLatencyMs?: number;
  stages?: HandshakeStage[];
  user?: any;
}

export const ConnectionMonitorModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onOpenTestRunner,
}) => {
  const { user, token } = useAuth();
  const { connectionStatus, currentPingMs, sendPing, activeConversation } = useChat();
  const { language } = useLanguage();
  const isBn = language === 'bn';

  // Tabs: 'handshake' | 'logs'
  const [activeTab, setActiveTab] = useState<'handshake' | 'logs'>('handshake');

  // Live Ping state
  const [livePing, setLivePing] = useState<number | null>(currentPingMs);
  const [isPinging, setIsPinging] = useState(false);

  // Handshake tester state
  const [testScenario, setTestScenario] = useState<'valid' | 'invalid_token' | 'missing_token' | 'unauthorized_conv'>('valid');
  const [isTestingHandshake, setIsTestingHandshake] = useState(false);
  const [handshakeResult, setHandshakeResult] = useState<HandshakeTestResult | null>(null);

  // Log parser state
  const [logFilter, setLogFilter] = useState<'all' | 'rejected' | 'accepted'>('all');
  const [diagnosticData, setDiagnosticData] = useState<any>(null);
  const [isLoadingLogs, setIsLoadingLogs] = useState(false);

  // Measure live ping
  const handleMeasurePing = useCallback(async () => {
    setIsPinging(true);
    const latency = await sendPing();
    if (latency >= 0) {
      setLivePing(latency);
    }
    setIsPinging(false);
  }, [sendPing]);

  // Auto-measure ping when modal opens
  useEffect(() => {
    if (!isOpen) return;
    handleMeasurePing();
    const interval = setInterval(handleMeasurePing, 4000);
    return () => clearInterval(interval);
  }, [isOpen, handleMeasurePing]);

  // Fetch diagnostic logs
  const fetchDiagnosticLogs = useCallback(async (filter = logFilter) => {
    setIsLoadingLogs(true);
    try {
      const res = await fetch(`/api/diagnostics/logs/?filter=${filter}&limit=60`);
      if (res.ok) {
        const data = await res.json();
        setDiagnosticData(data);
      }
    } catch (err) {
      console.error('Failed to load diagnostic logs:', err);
    } finally {
      setIsLoadingLogs(false);
    }
  }, [logFilter]);

  useEffect(() => {
    if (isOpen && activeTab === 'logs') {
      fetchDiagnosticLogs();
    }
  }, [isOpen, activeTab, fetchDiagnosticLogs]);

  // Run Handshake Test
  const runHandshakeTest = async () => {
    setIsTestingHandshake(true);
    setHandshakeResult(null);

    let testToken = token || '';
    let testConvId = activeConversation?.id || 'conv_alice_bob';

    if (testScenario === 'invalid_token') {
      testToken = 'revoked_expired_fake_token_9999999999';
    } else if (testScenario === 'missing_token') {
      testToken = '';
    } else if (testScenario === 'unauthorized_conv') {
      testConvId = 'conv_private_restricted_999';
    }

    try {
      const res = await fetch('/api/diagnostics/test-handshake/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: testToken,
          conversation_id: testConvId,
        }),
      });

      const data = await res.json();
      setHandshakeResult(data);
      // Refresh logs if available
      fetchDiagnosticLogs();
    } catch (err: any) {
      setHandshakeResult({
        success: false,
        error: 'Network error connecting to diagnostic endpoint',
        details: err.message,
      });
    } finally {
      setIsTestingHandshake(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-3 md:p-4 animate-in fade-in">
      <div className="w-full max-w-3xl rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-5 md:p-6 text-slate-100 flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <Activity className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base md:text-lg font-bold text-white">
                  {isBn ? 'ওয়েবসকেট কানেকশন মনিটর' : 'WebSocket Connection Monitor'}
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  Live Diagnostics
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {isBn
                  ? 'হ্যান্ডশেক লেটেন্সি পরীক্ষা করুন এবং প্রমাণীকরণ ত্রুটির বিশদ বিশ্লেষণ দেখুন'
                  : 'Inspect handshake latency, authentication token validations, and Channels error logs'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Real-Time Live Status Banner */}
        <div className="my-4 grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          {/* Connection State */}
          <div className="bg-slate-950/70 p-3.5 rounded-2xl border border-slate-800 flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                connectionStatus === 'connected'
                  ? 'bg-emerald-500/20 text-emerald-400'
                  : connectionStatus === 'connecting'
                  ? 'bg-amber-500/20 text-amber-400'
                  : 'bg-rose-500/20 text-rose-400'
              }`}
            >
              {connectionStatus === 'connected' ? (
                <Wifi className="w-5 h-5" />
              ) : (
                <WifiOff className="w-5 h-5" />
              )}
            </div>
            <div>
              <p className="text-[11px] font-medium text-slate-400">WebSocket State</p>
              <p
                className={`text-sm font-bold capitalize ${
                  connectionStatus === 'connected'
                    ? 'text-emerald-400'
                    : connectionStatus === 'connecting'
                    ? 'text-amber-400'
                    : 'text-rose-400'
                }`}
              >
                {connectionStatus === 'connected' ? 'Connected (Live)' : connectionStatus}
              </p>
            </div>
          </div>

          {/* Handshake / Ping Latency */}
          <div className="bg-slate-950/70 p-3.5 rounded-2xl border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center shrink-0">
                <Zap className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[11px] font-medium text-slate-400">Handshake Latency</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-base font-extrabold text-white">
                    {livePing !== null && livePing >= 0 ? `${livePing} ms` : '--'}
                  </span>
                  {livePing !== null && livePing >= 0 && (
                    <span
                      className={`text-[10px] font-semibold ${
                        livePing < 50
                          ? 'text-emerald-400'
                          : livePing < 150
                          ? 'text-teal-400'
                          : 'text-amber-400'
                      }`}
                    >
                      {livePing < 50 ? '• Optimal' : livePing < 150 ? '• Normal' : '• High'}
                    </span>
                  )}
                </div>
              </div>
            </div>
            <button
              onClick={handleMeasurePing}
              disabled={isPinging || connectionStatus !== 'connected'}
              title="Ping server now"
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-40 transition"
            >
              <RotateCcw className={`w-3.5 h-3.5 ${isPinging ? 'animate-spin' : ''}`} />
            </button>
          </div>

          {/* Authenticated Identity */}
          <div className="bg-slate-950/70 p-3.5 rounded-2xl border border-slate-800 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center shrink-0">
              <Server className="w-5 h-5" />
            </div>
            <div className="overflow-hidden">
              <p className="text-[11px] font-medium text-slate-400">Auth Token Identity</p>
              <p className="text-xs font-bold text-white truncate">
                {user ? `@${user.username}` : 'Unauthenticated'}
              </p>
              <p className="text-[10px] font-mono text-emerald-400 truncate">
                {token ? `Bearer ${token.substring(0, 10)}...` : 'None'}
              </p>
            </div>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('handshake')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'handshake'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-800/80 text-slate-400 hover:text-white'
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              <span>{isBn ? 'হ্যান্ডশেক ও টোকেন টেস্টার' : 'Handshake & Token Tester'}</span>
            </button>

            <button
              onClick={() => setActiveTab('logs')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'logs'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-800/80 text-slate-400 hover:text-white'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>{isBn ? 'লগ ও চ্যানেল পার্সার' : 'Channels & Handshake Log Parser'}</span>
            </button>
          </div>

          {/* Quick link to Two-User E2E Test Suite */}
          <button
            onClick={() => {
              onClose();
              onOpenTestRunner();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 text-xs font-semibold transition"
          >
            <Play className="w-3 h-3 fill-current" />
            <span className="hidden sm:inline">Run 2-User E2E Tests</span>
            <span className="sm:hidden">E2E Tests</span>
          </button>
        </div>

        {/* TAB 1: Handshake & Auth Tester */}
        {activeTab === 'handshake' && (
          <div className="flex-1 overflow-y-auto mt-4 space-y-4 pr-1">
            {/* Scenario Picker */}
            <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800 space-y-3">
              <label className="block text-xs font-bold text-slate-300">
                {isBn
                  ? 'হ্যান্ডশেক পরীক্ষার জন্য পরিস্থিতি নির্বাচন করুন:'
                  : 'Select Handshake Test Scenario to Evaluate Server Behavior:'}
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setTestScenario('valid')}
                  className={`p-3 rounded-xl border text-left transition ${
                    testScenario === 'valid'
                      ? 'bg-emerald-950/60 border-emerald-500 text-emerald-200'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  <p className="font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Valid Active Token</span>
                  </p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Normal connection using the authenticated user session.
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => setTestScenario('invalid_token')}
                  className={`p-3 rounded-xl border text-left transition ${
                    testScenario === 'invalid_token'
                      ? 'bg-rose-950/60 border-rose-500 text-rose-200'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  <p className="font-bold flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                    <span>Intentionally Invalid Token</span>
                  </p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Tests server rejection behavior with 401 Unauthorized.
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => setTestScenario('missing_token')}
                  className={`p-3 rounded-xl border text-left transition ${
                    testScenario === 'missing_token'
                      ? 'bg-amber-950/60 border-amber-500 text-amber-200'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  <p className="font-bold flex items-center gap-1.5">
                    <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                    <span>Missing Token Parameter</span>
                  </p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Simulates connection attempts without ?token query parameter.
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => setTestScenario('unauthorized_conv')}
                  className={`p-3 rounded-xl border text-left transition ${
                    testScenario === 'unauthorized_conv'
                      ? 'bg-purple-950/60 border-purple-500 text-purple-200'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  <p className="font-bold flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-purple-400" />
                    <span>Unauthorized Conversation</span>
                  </p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Tests conversation membership validation (403 Forbidden).
                  </p>
                </button>
              </div>

              <button
                onClick={runHandshakeTest}
                disabled={isTestingHandshake}
                className="w-full mt-2 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-2 active:scale-98"
              >
                {isTestingHandshake ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Executing Handshake Validation...</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4" />
                    <span>
                      {isBn ? 'হ্যান্ডশেক লেটেন্সি ও প্রমাণীকরণ পরীক্ষা চালান' : 'Execute Handshake & Token Diagnostic Test'}
                    </span>
                  </>
                )}
              </button>
            </div>

            {/* Handshake Result View */}
            {handshakeResult && (
              <div
                className={`p-4 rounded-2xl border animate-in fade-in ${
                  handshakeResult.success
                    ? 'bg-emerald-950/50 border-emerald-500/50 text-emerald-100'
                    : 'bg-rose-950/60 border-rose-500/60 text-rose-100'
                }`}
              >
                {/* Result Title */}
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-2">
                    {handshakeResult.success ? (
                      <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
                    ) : (
                      <XCircle className="w-6 h-6 text-rose-400 shrink-0" />
                    )}
                    <div>
                      <h4 className="font-bold text-sm text-white">
                        {handshakeResult.success
                          ? 'HTTP 101 Switching Protocols — Handshake Accepted!'
                          : `${handshakeResult.error || 'Handshake Upgrade Rejected by Server'}`}
                      </h4>
                      <p className="text-xs opacity-85 mt-0.5">
                        {handshakeResult.details || handshakeResult.message}
                      </p>
                    </div>
                  </div>

                  {handshakeResult.totalLatencyMs !== undefined && (
                    <span className="font-mono text-xs font-bold px-2 py-1 rounded-lg bg-black/40 text-emerald-300 border border-emerald-500/30 shrink-0">
                      ⏱ {handshakeResult.totalLatencyMs} ms
                    </span>
                  )}
                </div>

                {/* Detailed rejection banner if rejected */}
                {!handshakeResult.success && (
                  <div className="mt-3 p-3 rounded-xl bg-black/40 border border-rose-500/30 text-xs text-rose-200 space-y-1.5">
                    <p className="font-bold text-rose-400 flex items-center gap-1.5">
                      <ShieldAlert className="w-4 h-4" />
                      Detailed Server Authentication Failure Notice:
                    </p>
                    <p className="text-[11px] leading-relaxed opacity-90">
                      {handshakeResult.rejectionCode === 401 && (
                        <span>
                          The PChat server inspected the WebSocket upgrade headers and rejected the handshake with <strong>HTTP 401 Unauthorized</strong>.
                          The authentication token was either missing from the query string, malformed, or has expired.
                          Clients must provide a valid session token obtained from <code className="bg-black/50 px-1 py-0.5 rounded text-amber-300">/api/auth/login/</code>.
                        </span>
                      )}
                      {handshakeResult.rejectionCode === 403 && (
                        <span>
                          The user is authenticated, but was rejected with <strong>HTTP 403 Forbidden</strong>.
                          The server validated the conversation membership against the database and blocked unauthorized access to the room.
                        </span>
                      )}
                    </p>
                  </div>
                )}

                {/* Handshake Stages Breakdown */}
                {handshakeResult.stages && (
                  <div className="mt-3 pt-3 border-t border-slate-700/60 space-y-2">
                    <p className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                      Handshake Execution Stages:
                    </p>
                    <div className="divide-y divide-slate-800/80 bg-slate-950/60 rounded-xl p-2.5 border border-slate-800 text-xs">
                      {handshakeResult.stages.map((stg, i) => (
                        <div key={i} className="py-2 flex items-center justify-between gap-3">
                          <div className="flex items-center gap-2">
                            {stg.passed ? (
                              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                            ) : (
                              <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                            )}
                            <div>
                              <p className="font-semibold text-slate-200">{stg.stage}</p>
                              <p className="text-[11px] text-slate-400">{stg.message}</p>
                            </div>
                          </div>
                          <span className="font-mono text-[10px] text-slate-400 shrink-0">
                            {stg.durationMs}ms
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* TAB 2: Channels & Handshake Log Parser */}
        {activeTab === 'logs' && (
          <div className="flex-1 overflow-y-auto mt-4 space-y-4 pr-1">
            {/* Filter & Refresh bar */}
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 bg-slate-950/80 p-1 rounded-xl text-xs font-semibold">
                <button
                  onClick={() => {
                    setLogFilter('all');
                    fetchDiagnosticLogs('all');
                  }}
                  className={`px-2.5 py-1 rounded-lg transition ${
                    logFilter === 'all' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  All Logs
                </button>
                <button
                  onClick={() => {
                    setLogFilter('rejected');
                    fetchDiagnosticLogs('rejected');
                  }}
                  className={`px-2.5 py-1 rounded-lg transition ${
                    logFilter === 'rejected' ? 'bg-rose-700 text-white' : 'text-slate-400 hover:text-rose-300'
                  }`}
                >
                  Rejections Only
                </button>
                <button
                  onClick={() => {
                    setLogFilter('accepted');
                    fetchDiagnosticLogs('accepted');
                  }}
                  className={`px-2.5 py-1 rounded-lg transition ${
                    logFilter === 'accepted' ? 'bg-emerald-700 text-white' : 'text-slate-400 hover:text-emerald-300'
                  }`}
                >
                  Accepted
                </button>
              </div>

              <button
                onClick={() => fetchDiagnosticLogs()}
                disabled={isLoadingLogs}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoadingLogs ? 'animate-spin' : ''}`} />
                <span>Refresh Logs</span>
              </button>
            </div>

            {/* Automated Parser Findings */}
            {diagnosticData && (
              <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-300 flex items-center gap-1.5">
                    <Server className="w-4 h-4 text-emerald-400" />
                    Automated Diagnostic Log Analysis:
                  </span>
                  <span
                    className={`font-bold px-2 py-0.5 rounded-full text-[10px] ${
                      diagnosticData.status === 'HEALTHY'
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                    }`}
                  >
                    System Status: {diagnosticData.status}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                  <div className="bg-slate-900 p-2 rounded-xl border border-slate-800 text-center">
                    <p className="text-[10px] text-slate-400">Total Analyzed</p>
                    <p className="text-sm font-bold text-white">{diagnosticData.summary.totalAnalyzed}</p>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-xl border border-slate-800 text-center">
                    <p className="text-[10px] text-slate-400">Accepted</p>
                    <p className="text-sm font-bold text-emerald-400">{diagnosticData.summary.acceptedCount}</p>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-xl border border-slate-800 text-center">
                    <p className="text-[10px] text-slate-400">Auth Rejections</p>
                    <p className="text-sm font-bold text-rose-400">{diagnosticData.summary.rejectedCount}</p>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-xl border border-slate-800 text-center">
                    <p className="text-[10px] text-slate-400">Avg Handshake</p>
                    <p className="text-sm font-bold text-teal-400">{diagnosticData.summary.avgHandshakeLatencyMs}ms</p>
                  </div>
                </div>

                {/* Recommendations */}
                <div className="mt-2 pt-2 border-t border-slate-800/80 text-[11px] text-slate-300">
                  <span className="font-semibold text-emerald-400">Findings: </span>
                  {diagnosticData.recommendations.join(' ')}
                </div>
              </div>
            )}

            {/* Log Entries List */}
            <div className="space-y-2">
              {isLoadingLogs ? (
                <div className="py-8 text-center text-slate-400 text-xs">
                  <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-emerald-400" />
                  Parsing recent WebSocket logs...
                </div>
              ) : !diagnosticData || !diagnosticData.logs || diagnosticData.logs.length === 0 ? (
                <div className="py-8 text-center text-slate-400 text-xs">
                  No connection log entries found for this filter.
                </div>
              ) : (
                diagnosticData.logs.map((log: any) => (
                  <div
                    key={log.id}
                    className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs space-y-1 hover:border-slate-700 transition"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span
                          className={`font-mono text-[10px] font-bold px-1.5 py-0.5 rounded-sm ${
                            log.status === 'accepted'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : 'bg-rose-950 text-rose-300 border border-rose-800'
                          }`}
                        >
                          {log.code} {log.status.toUpperCase()}
                        </span>
                        <span className="font-mono text-slate-300 font-semibold">{log.endpoint}</span>
                        {log.username && (
                          <span className="text-slate-400">(@{log.username})</span>
                        )}
                      </div>
                      <span className="text-[10px] font-mono text-slate-400">{log.latencyMs}ms</span>
                    </div>

                    <p className="text-[11px] text-slate-400 pl-1">{log.reason}</p>

                    <div className="flex items-center justify-between text-[10px] text-slate-400 pl-1 pt-0.5">
                      <span>IP: {log.clientIp || '127.0.0.1'}</span>
                      <span>{new Date(log.timestamp).toLocaleTimeString()}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
