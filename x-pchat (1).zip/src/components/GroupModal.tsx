import React, { useState, useEffect } from 'react';
import { Users, X, UserPlus, Shield, Trash2, LogOut, Check } from 'lucide-react';
import { useAuth } from '../context/AuthContext.js';
import { useChat } from '../context/ChatContext.js';
import { useLanguage } from '../context/LanguageContext.js';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  mode: 'create' | 'manage';
}

export const GroupModal: React.FC<Props> = ({ isOpen, onClose, mode }) => {
  const { user, token } = useAuth();
  const { activeConversation, createGroupChat, addMemberToGroup, removeMemberFromGroup } = useChat();
  const { t, language } = useLanguage();

  const [groupTitle, setGroupTitle] = useState('');
  const [groupAvatar, setGroupAvatar] = useState('');
  const [selectedMembers, setSelectedMembers] = useState<string[]>([]);
  const [availableUsers, setAvailableUsers] = useState<any[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [addUserId, setAddUserId] = useState('');

  // Fetch users for member selection
  useEffect(() => {
    if (!isOpen || !token) return;

    fetch('/api/users/search/?q=', {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((res) => res.json())
      .then((data) => {
        setAvailableUsers(data.users || []);
      })
      .catch((err) => console.warn('Could not fetch available users:', err));
  }, [isOpen, token]);

  const handleToggleMember = (uid: string) => {
    setSelectedMembers((prev) =>
      prev.includes(uid) ? prev.filter((id) => id !== uid) : [...prev, uid]
    );
  };

  const handleCreateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupTitle.trim()) return;

    setIsSubmitting(true);
    const newId = await createGroupChat(groupTitle.trim(), groupAvatar.trim() || '/pchat-logo.png', selectedMembers);
    setIsSubmitting(false);

    if (newId) {
      setGroupTitle('');
      setGroupAvatar('');
      setSelectedMembers([]);
      onClose();
    }
  };

  const handleAddMember = async () => {
    if (!addUserId || !activeConversation) return;
    await addMemberToGroup(activeConversation.id, addUserId);
    setAddUserId('');
  };

  const handleRemoveMember = async (memberId: string) => {
    if (!activeConversation) return;
    await removeMemberFromGroup(activeConversation.id, memberId);
  };

  const handleLeaveGroup = async () => {
    if (!activeConversation || !user) return;
    await removeMemberFromGroup(activeConversation.id, user.id);
    onClose();
  };

  if (!isOpen) return null;

  const isCurrentAdmin =
    activeConversation &&
    activeConversation.members.some((m) => m.id === user?.id && m.role === 'admin');

  // Candidate users to add to existing group
  const nonMemberUsers = availableUsers.filter(
    (u) => activeConversation && !activeConversation.members.some((m) => m.id === u.id)
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
      <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl p-6 text-slate-100 animate-in fade-in zoom-in-95 flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-emerald-400" />
            {mode === 'create' ? t.new_group : activeConversation?.title}
          </h2>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {mode === 'create' ? (
          /* CREATE GROUP FORM */
          <form onSubmit={handleCreateGroup} className="mt-4 space-y-4 flex-1 flex flex-col overflow-hidden">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {t.group_name} *
              </label>
              <input
                type="text"
                required
                value={groupTitle}
                onChange={(e) => setGroupTitle(e.target.value)}
                placeholder="e.g. Bamboo Devs 🎋"
                className="w-full bg-slate-800 text-slate-100 text-sm rounded-xl px-3.5 py-2.5 border border-slate-700 focus:outline-hidden focus:border-emerald-500 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {t.group_avatar_url}
              </label>
              <input
                type="text"
                value={groupAvatar}
                onChange={(e) => setGroupAvatar(e.target.value)}
                placeholder="/avatars/panda-zen.svg or image URL"
                className="w-full bg-slate-800 text-slate-100 text-sm rounded-xl px-3.5 py-2.5 border border-slate-700 focus:outline-hidden focus:border-emerald-500 transition text-xs"
              />
            </div>

            <div className="flex-1 flex flex-col overflow-hidden">
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {language === 'bn' ? 'সদস্য নির্বাচন করুন:' : 'Select Members:'}
              </label>
              <div className="flex-1 overflow-y-auto divide-y divide-slate-800/60 border border-slate-800 rounded-xl p-2 bg-slate-950/50">
                {availableUsers.map((u) => {
                  const isChecked = selectedMembers.includes(u.id);
                  return (
                    <button
                      type="button"
                      key={u.id}
                      onClick={() => handleToggleMember(u.id)}
                      className="w-full py-2 px-2 flex items-center justify-between text-left hover:bg-slate-800/60 rounded-lg transition"
                    >
                      <div className="flex items-center gap-2.5">
                        <img
                          src={u.avatar_url || '/pchat-logo.png'}
                          alt={u.display_name}
                          onError={(e) => {
                            e.currentTarget.src = '/pchat-logo.png';
                          }}
                          className="w-8 h-8 rounded-full object-cover bg-slate-800 border border-slate-700"
                        />
                        <div>
                          <p className="text-xs font-semibold text-white">{u.display_name}</p>
                          <p className="text-[10px] text-slate-400">@{u.username}</p>
                        </div>
                      </div>
                      <div
                        className={`w-5 h-5 rounded-md flex items-center justify-center border transition ${
                          isChecked
                            ? 'bg-emerald-600 border-emerald-500 text-white'
                            : 'border-slate-700 bg-slate-800'
                        }`}
                      >
                        {isChecked && <Check className="w-3.5 h-3.5" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting || !groupTitle.trim()}
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 text-white font-semibold text-xs shadow transition active:scale-95"
            >
              {isSubmitting ? 'Creating...' : t.create_group_button}
            </button>
          </form>
        ) : (
          /* MANAGE EXISTING GROUP */
          <div className="mt-4 space-y-4 flex-1 flex flex-col overflow-hidden">
            {/* Add member (Admin only) */}
            {isCurrentAdmin && nonMemberUsers.length > 0 && (
              <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/60 flex items-center gap-2">
                <select
                  value={addUserId}
                  onChange={(e) => setAddUserId(e.target.value)}
                  className="flex-1 bg-slate-900 text-xs text-slate-200 rounded-lg px-2.5 py-1.5 border border-slate-700 focus:outline-hidden focus:border-emerald-500"
                >
                  <option value="">{language === 'bn' ? 'সদস্য যোগ করতে নির্বাচন করুন' : 'Select user to add'}</option>
                  {nonMemberUsers.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.display_name} (@{u.username})
                    </option>
                  ))}
                </select>
                <button
                  onClick={handleAddMember}
                  disabled={!addUserId}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-700 text-white text-xs font-semibold transition"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Member list */}
            <div className="flex-1 overflow-y-auto divide-y divide-slate-800/60 pr-1">
              {activeConversation?.members.map((m) => {
                const isAdmin = m.role === 'admin';
                const isMe = m.id === user?.id;

                return (
                  <div key={m.id} className="py-2.5 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="relative">
                        <img
                          src={m.avatar_url || '/pchat-logo.png'}
                          alt={m.display_name}
                          onError={(e) => {
                            e.currentTarget.src = '/pchat-logo.png';
                          }}
                          className="w-8 h-8 rounded-full object-cover bg-slate-800 border border-slate-700"
                        />
                        <span
                          className={`absolute bottom-0 right-0 w-2 h-2 rounded-full border border-slate-900 ${
                            m.is_online ? 'bg-emerald-500' : 'bg-slate-500'
                          }`}
                        />
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <p className="text-xs font-semibold text-white">
                            {m.display_name} {isMe && '(You)'}
                          </p>
                          {isAdmin && (
                            <span className="flex items-center gap-0.5 text-[9px] font-bold px-1.5 py-0.2 rounded-sm bg-amber-500/20 text-amber-300 border border-amber-500/30">
                              <Shield className="w-2.5 h-2.5" />
                              {t.admin_badge}
                            </span>
                          )}
                        </div>
                        <p className="text-[10px] text-slate-400">@{m.username}</p>
                      </div>
                    </div>

                    {/* Actions */}
                    <div>
                      {isCurrentAdmin && !isMe && (
                        <button
                          onClick={() => handleRemoveMember(m.id)}
                          title={t.remove_member}
                          className="p-1 text-slate-400 hover:text-rose-400 transition"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Leave group button */}
            <div className="pt-2 border-t border-slate-800">
              <button
                onClick={handleLeaveGroup}
                className="w-full flex items-center justify-center gap-1.5 py-2 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 text-xs font-semibold transition border border-rose-500/30"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>{t.leave_group}</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
