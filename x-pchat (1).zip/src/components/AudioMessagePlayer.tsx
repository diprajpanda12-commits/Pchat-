import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Download, Volume2 } from 'lucide-react';

interface Props {
  audioUrl: string;
  duration?: number | null;
  isSender: boolean;
}

export const AudioMessagePlayer: React.FC<Props> = ({ audioUrl, duration: initialDuration, isSender }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(initialDuration || 0);
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleLoadedMetadata = () => {
      if (audio.duration && !isNaN(audio.duration) && isFinite(audio.duration)) {
        setDuration(Math.round(audio.duration));
      }
    };

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
    };

    const handleEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
    };

    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('ended', handleEnded);
    };
  }, [audioUrl]);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.playbackRate = playbackRate;
      audio.play().then(() => {
        setIsPlaying(true);
      }).catch((err) => {
        console.error('Audio playback error:', err);
      });
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = parseFloat(e.target.value);
    const audio = audioRef.current;
    if (audio) {
      audio.currentTime = newTime;
      setCurrentTime(newTime);
    }
  };

  const cycleSpeed = () => {
    const nextRate = playbackRate === 1 ? 1.5 : playbackRate === 1.5 ? 2 : 1;
    setPlaybackRate(nextRate);
    if (audioRef.current) {
      audioRef.current.playbackRate = nextRate;
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  // Fixed bars visual representation for a modern voice note waveform
  const waveformHeights = [
    25, 45, 70, 30, 85, 60, 40, 95, 80, 50, 65, 35, 90, 75, 45, 80, 55, 30, 90, 65,
    40, 85, 70, 50, 35, 60, 80, 45, 65, 30,
  ];

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className={`flex flex-col gap-1.5 p-2.5 rounded-2xl select-none ${
      isSender ? 'bg-emerald-700/60 text-white' : 'bg-slate-900/90 text-slate-200 border border-slate-800'
    }`}>
      <audio ref={audioRef} src={audioUrl} preload="metadata" />

      <div className="flex items-center gap-2.5">
        {/* Play/Pause Button */}
        <button
          type="button"
          onClick={togglePlay}
          className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 shadow-md transition-all active:scale-95 cursor-pointer ${
            isSender
              ? 'bg-white text-emerald-800 hover:bg-emerald-50'
              : 'bg-emerald-600 text-white hover:bg-emerald-500 shadow-emerald-950/40'
          }`}
          title={isPlaying ? 'Pause' : 'Play voice message'}
        >
          {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
        </button>

        {/* Waveform & Progress slider */}
        <div className="flex-1 flex flex-col justify-center min-w-[130px] sm:min-w-[170px]">
          <div className="relative h-6 flex items-center gap-0.5 px-0.5 overflow-hidden">
            {waveformHeights.map((h, i) => {
              const barPercent = (i / waveformHeights.length) * 100;
              const isPast = barPercent <= progressPercent;
              return (
                <div
                  key={i}
                  style={{ height: `${h}%` }}
                  className={`w-1 rounded-full transition-colors ${
                    isPast
                      ? isSender ? 'bg-white' : 'bg-emerald-400'
                      : isSender ? 'bg-emerald-300/40' : 'bg-slate-700'
                  }`}
                />
              );
            })}

            {/* Transparent scrubber input overlay */}
            <input
              type="range"
              min="0"
              max={duration || 1}
              step="0.1"
              value={currentTime}
              onChange={handleSeek}
              className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
              title="Seek voice message"
            />
          </div>

          <div className="flex items-center justify-between text-[10px] opacity-80 font-mono mt-0.5 tabular-nums">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* Speed toggle button */}
        <button
          type="button"
          onClick={cycleSpeed}
          title={`Playback speed: ${playbackRate}x (click to change)`}
          className={`px-1.5 py-0.5 rounded-md text-[10px] font-bold font-mono transition cursor-pointer tabular-nums ${
            isSender
              ? 'bg-emerald-800/80 hover:bg-emerald-800 text-emerald-100'
              : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
          }`}
        >
          {playbackRate}x
        </button>

        {/* Download button */}
        <a
          href={audioUrl}
          download={`voice_message_${Date.now()}.webm`}
          title="Download audio"
          className={`p-1 rounded-md opacity-75 hover:opacity-100 transition ${
            isSender ? 'hover:text-white' : 'hover:text-emerald-400'
          }`}
        >
          <Download className="w-3.5 h-3.5" />
        </a>
      </div>
    </div>
  );
};
