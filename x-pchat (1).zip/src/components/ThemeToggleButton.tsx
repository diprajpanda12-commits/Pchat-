import React from 'react';
import { Moon, Sun } from 'lucide-react';
import { useTheme } from '../context/ThemeContext.js';

interface Props {
  showLabel?: boolean;
  className?: string;
}

export const ThemeToggleButton: React.FC<Props> = ({ showLabel = true, className = '' }) => {
  const { isDark, toggleTheme } = useTheme();

  return (
    <button
      type="button"
      onClick={toggleTheme}
      title={isDark ? 'Switch to Light Theme (Turn Dark Theme OFF)' : 'Switch to Dark Theme (Turn Dark Theme ON)'}
      aria-label="Toggle dark theme"
      className={`group relative inline-flex items-center gap-2 px-2.5 py-1.5 rounded-xl transition-all duration-200 cursor-pointer border select-none ${
        isDark
          ? 'bg-slate-900/90 hover:bg-slate-800 text-slate-200 border-slate-800 hover:border-emerald-500/40 shadow-xs'
          : 'bg-white hover:bg-slate-100 text-slate-800 border-slate-300 hover:border-amber-500/50 shadow-xs'
      } ${className}`}
    >
      {/* Icon with glowing ambient accent */}
      <div
        className={`w-6 h-6 rounded-lg flex items-center justify-center transition-all duration-200 ${
          isDark
            ? 'bg-emerald-950/70 text-emerald-400 group-hover:scale-110'
            : 'bg-amber-100 text-amber-600 group-hover:scale-110'
        }`}
      >
        {isDark ? <Moon className="w-3.5 h-3.5" /> : <Sun className="w-3.5 h-3.5" />}
      </div>

      {/* Pill Toggle Switch indicator */}
      {showLabel && (
        <div className="flex items-center gap-1.5 text-xs font-semibold">
          <span className="hidden sm:inline">Dark:</span>
          <span
            className={`px-1.5 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider transition-colors ${
              isDark
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                : 'bg-slate-200 text-slate-700 border border-slate-300'
            }`}
          >
            {isDark ? 'ON' : 'OFF'}
          </span>
        </div>
      )}

      {/* Visual toggle slider circle on larger screens */}
      <div
        className={`hidden md:flex w-8 h-4 rounded-full p-0.5 items-center transition-colors ${
          isDark ? 'bg-emerald-600 justify-end' : 'bg-slate-300 justify-start'
        }`}
      >
        <div className="w-3 h-3 rounded-full bg-white shadow-xs transition-transform" />
      </div>
    </button>
  );
};
