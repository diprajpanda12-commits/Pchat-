// PChat Service Worker v2 - Network-first for fresh bundles, offline-capable
const CACHE_NAME = 'pchat-v2';
const STATIC_ASSETS = [
  '/',
  '/manifest.json',
  '/pchat-logo.png',
  '/icon.svg',
  '/apple-touch-icon.png',
  '/pwa-192x192.png',
  '/pwa-512x512.png',
  '/avatars/panda-emerald.svg',
  '/avatars/panda-cyber.svg',
  '/avatars/panda-astro.svg',
  '/avatars/panda-ninja.svg',
  '/avatars/panda-royal.svg',
  '/avatars/panda-zen.svg',
  '/avatars/panda-classic.svg'
];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(STATIC_ASSETS).catch((err) => {
        console.warn('Pre-cache notice:', err);
      });
    })
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            console.log('[SW] Deleting stale cache:', key);
            return caches.delete(key);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Bypass API and WebSocket routes completely
  if (url.pathname.startsWith('/api') || url.pathname.startsWith('/ws')) {
    return;
  }

  // Navigation requests (HTML document loads) - ALWAYS Network-First
  if (event.request.mode === 'navigate' || event.request.destination === 'document') {
    event.respondWith(
      fetch(event.request)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const responseClone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, responseClone));
          }
          return networkResponse;
        })
        .catch(async () => {
          // Offline fallback
          const cached = await caches.match(event.request);
          if (cached) return cached;
          const fallback = await caches.match('/');
          return fallback || new Response('Offline', { status: 503, headers: { 'Content-Type': 'text/plain' } });
        })
    );
    return;
  }

  // Static assets (CSS, JS chunks, images) - Network-first with cache fallback
  event.respondWith(
    fetch(event.request)
      .then((networkResponse) => {
        if (networkResponse && networkResponse.status === 200) {
          const responseClone = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, responseClone));
        }
        return networkResponse;
      })
      .catch(() => {
        return caches.match(event.request);
      })
  );
});

// -----------------------------------------------------------------------------
// Web Push Notifications Handler (Android Notification Bar, Lock Screen & Background)
// -----------------------------------------------------------------------------

self.addEventListener('push', (event) => {
  let data = {
    title: 'PChat (Panda Chat) 🐼',
    body: 'You have a new message!',
    icon: '/pchat-logo.png',
    badge: '/icon.svg',
    url: '/',
    data: {},
  };

  if (event.data) {
    try {
      const parsed = event.data.json();
      data = { ...data, ...parsed };
    } catch (_e) {
      data.body = event.data.text() || data.body;
    }
  }

  const convId = data.data?.conversation_id || '';
  const options = {
    body: data.body,
    icon: data.icon || '/pchat-logo.png',
    badge: data.badge || '/icon.svg',
    vibrate: [200, 100, 200],
    data: {
      url: data.url || (convId ? `/?conv=${convId}` : '/'),
      conversation_id: convId,
      message_id: data.data?.message_id,
    },
    tag: convId ? `pchat-conv-${convId}` : 'pchat-general',
    renotify: true,
    actions: [
      { action: 'open', title: 'Open Chat 💬' },
    ],
  };

  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const convId = event.notification.data?.conversation_id;
  const targetUrl = event.notification.data?.url || (convId ? `/?conv=${convId}` : '/');

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((windowClients) => {
      // Focus existing PChat tab if open
      for (const client of windowClients) {
        if ('focus' in client) {
          client.focus();
          client.postMessage({
            type: 'NAVIGATE_CONVERSATION',
            conversation_id: convId,
          });
          return;
        }
      }
      // If no tab is open, open fresh window to the target conversation
      if (clients.openWindow) {
        return clients.openWindow(targetUrl);
      }
    })
  );
});

