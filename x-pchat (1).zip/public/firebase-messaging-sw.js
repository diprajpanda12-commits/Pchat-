// PChat - Firebase Cloud Messaging (FCM) & Web Push Service Worker
// Scope: '/'

// Fallback static branding
const DEFAULT_ICON = '/pchat-logo.png';
const DEFAULT_BADGE = '/icon.svg';

self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

// Background Push message listener (handles both FCM payloads and W3C WebPush payloads)
self.addEventListener('push', (event) => {
  let payload = {
    title: 'PChat (Panda Chat) 🐼',
    body: 'New message received',
    icon: DEFAULT_ICON,
    badge: DEFAULT_BADGE,
    url: '/',
    data: {},
  };

  if (event.data) {
    try {
      const parsed = event.data.json();
      // Support both standard Web Push and FCM format (notification + data objects)
      if (parsed.notification) {
        payload.title = parsed.notification.title || payload.title;
        payload.body = parsed.notification.body || payload.body;
        payload.icon = parsed.notification.icon || DEFAULT_ICON;
      } else {
        payload.title = parsed.title || payload.title;
        payload.body = parsed.body || payload.body;
        payload.icon = parsed.icon || DEFAULT_ICON;
        payload.badge = parsed.badge || DEFAULT_BADGE;
      }
      if (parsed.data) {
        payload.data = parsed.data;
        if (parsed.data.url) payload.url = parsed.data.url;
      }
    } catch (_err) {
      payload.body = event.data.text() || payload.body;
    }
  }

  const convId = payload.data?.conversation_id || '';
  const notifTag = convId ? `pchat-conv-${convId}` : `pchat-notif-${Date.now()}`;

  const options = {
    body: payload.body,
    icon: payload.icon || DEFAULT_ICON,
    badge: payload.badge || DEFAULT_BADGE,
    vibrate: [200, 100, 200],
    data: {
      url: payload.url || (convId ? `/?conv=${convId}` : '/'),
      conversation_id: convId,
      message_id: payload.data?.message_id,
    },
    tag: notifTag,
    renotify: true,
    requireInteraction: false,
    actions: [
      { action: 'open', title: 'Open Chat 💬' },
      { action: 'dismiss', title: 'Dismiss' },
    ],
  };

  event.waitUntil(
    self.registration.showNotification(payload.title, options)
  );
});

// Notification click handling: focus open window or open target conversation
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  if (event.action === 'dismiss') {
    return;
  }

  const convId = event.notification.data?.conversation_id;
  const targetUrl = event.notification.data?.url || (convId ? `/?conv=${convId}` : '/');

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((windowClients) => {
      // 1. Focus matching open PChat tab if available
      for (const client of windowClients) {
        if ('focus' in client) {
          client.focus();
          client.postMessage({
            type: 'NAVIGATE_CONVERSATION',
            conversation_id: convId,
          });
          return;
        }
      }
      // 2. Otherwise open new window at target conversation
      if (clients.openWindow) {
        return clients.openWindow(targetUrl);
      }
    })
  );
});
