import { WebSocketServer, WebSocket } from 'ws';
import { IncomingMessage, Server } from 'http';
import url from 'url';
import crypto from 'crypto';
import { db, User, Message } from './db.js';
import { authenticateUser, parseCookies } from './auth.js';
import { sendPushForNewMessage } from './push.js';

interface ExtendedWebSocket extends WebSocket {
  isAlive: boolean;
  user?: User;
  conversationId?: string;
  isGeneral?: boolean;
}

// Conversation groups: conversationId -> Set of WebSockets
const conversationRooms = new Map<string, Set<ExtendedWebSocket>>();

// User sockets: userId -> Set of WebSockets (for multi-device / general notifications)
const userSockets = new Map<string, Set<ExtendedWebSocket>>();

// Presence debounce timers to prevent status flickering when navigating between rooms
const offlineGraceTimers = new Map<string, any>();

export function broadcastToConversation(conversationId: string, payload: any, senderWs?: WebSocket) {
  const room = conversationRooms.get(conversationId);
  const data = JSON.stringify(payload);

  if (room) {
    room.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(data);
      }
    });
  }

  // Also broadcast to any user sockets for conversation members (in case they are not in the room yet, but in dashboard)
  const members = db.getConversationMembers(conversationId);
  members.forEach(m => {
    const sockets = userSockets.get(m.id);
    if (sockets) {
      sockets.forEach(ws => {
        // Only send if it's not already in the conversation room to avoid duplicates
        if (ws.readyState === WebSocket.OPEN && ws.conversationId !== conversationId) {
          ws.send(JSON.stringify({
            type: 'conversation:update',
            conversation_id: conversationId,
            latest_payload: payload,
          }));
        }
      });
    }
  });
}

export function broadcastToUser(userId: string, payload: any) {
  const sockets = userSockets.get(userId);
  if (sockets) {
    const data = JSON.stringify(payload);
    sockets.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(data);
      }
    });
  }
}

export interface HandshakeLogEntry {
  id: string;
  timestamp: string;
  status: 'accepted' | 'rejected';
  code: number;
  reason: string;
  endpoint: string;
  userId?: string;
  username?: string;
  tokenSnippet?: string;
  latencyMs: number;
  clientIp?: string;
}

// In-memory diagnostic ring buffer for connection attempts
const handshakeLogs: HandshakeLogEntry[] = [];

export function recordHandshakeLog(entry: Omit<HandshakeLogEntry, 'id' | 'timestamp'>): HandshakeLogEntry {
  const log: HandshakeLogEntry = {
    id: `hs_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    timestamp: new Date().toISOString(),
    ...entry,
  };
  handshakeLogs.unshift(log);
  if (handshakeLogs.length > 200) {
    handshakeLogs.pop();
  }
  return log;
}

export function getHandshakeLogs(limit = 50, filter?: 'all' | 'rejected' | 'accepted') {
  if (filter === 'rejected') {
    return handshakeLogs.filter(l => l.status === 'rejected').slice(0, limit);
  }
  if (filter === 'accepted') {
    return handshakeLogs.filter(l => l.status === 'accepted').slice(0, limit);
  }
  return handshakeLogs.slice(0, limit);
}

export function getWebSocketMetrics() {
  let totalConnections = 0;
  userSockets.forEach(set => totalConnections += set.size);

  const acceptedCount = handshakeLogs.filter(l => l.status === 'accepted').length;
  const rejectedCount = handshakeLogs.filter(l => l.status === 'rejected').length;
  const avgLatency = handshakeLogs.length > 0 
    ? Math.round(handshakeLogs.reduce((acc, l) => acc + l.latencyMs, 0) / handshakeLogs.length) 
    : 0;

  return {
    totalConnections,
    activeUsersCount: userSockets.size,
    activeRoomsCount: conversationRooms.size,
    totalHandshakesRecorded: handshakeLogs.length,
    acceptedHandshakes: acceptedCount,
    rejectedHandshakes: rejectedCount,
    avgHandshakeLatencyMs: avgLatency,
    uptimeSeconds: Math.floor(process.uptime()),
    timestamp: new Date().toISOString(),
  };
}

export function initWebSocketServer(server: Server) {
  const wss = new WebSocketServer({ noServer: true });

  // Handle HTTP upgrade to WebSocket
  server.on('upgrade', (request: IncomingMessage, socket, head) => {
    const handshakeStart = Date.now();
    const parsedUrl = url.parse(request.url || '', true);
    const pathname = parsedUrl.pathname || '';

    // Check if path is /ws/chat/:convId or /ws/general
    const chatMatch = pathname.match(/^\/ws\/chat\/([a-zA-Z0-9_-]+)\/?$/);
    const isGeneral = pathname === '/ws/general' || pathname === '/ws/general/';

    if (!chatMatch && !isGeneral) {
      // Not a PChat WebSocket endpoint (e.g. Vite HMR or other path)
      return;
    }

    let token = (parsedUrl.query.token as string) || '';
    if (!token && request.headers.cookie) {
      const cookies = parseCookies(request.headers.cookie);
      token = cookies.pchat_token || cookies.pchat_session || '';
    }
    const tokenSnippet = token ? `${token.substring(0, 6)}...` : undefined;
    const clientIp = (request.headers['x-forwarded-for'] as string) || request.socket.remoteAddress || '127.0.0.1';

    if (!token) {
      const latencyMs = Date.now() - handshakeStart;
      recordHandshakeLog({
        status: 'rejected',
        code: 401,
        reason: 'Missing authentication token in query parameter (?token=...)',
        endpoint: pathname,
        tokenSnippet: undefined,
        latencyMs,
        clientIp,
      });
      socket.write(
        'HTTP/1.1 401 Unauthorized\r\n' +
        'Content-Type: text/plain\r\n' +
        'X-PChat-Auth-Failure: Token missing\r\n' +
        '\r\n' +
        'Authentication token required to establish PChat WebSocket connection.'
      );
      socket.destroy();
      return;
    }

    const user = authenticateUser(token);

    if (!user) {
      const latencyMs = Date.now() - handshakeStart;
      recordHandshakeLog({
        status: 'rejected',
        code: 401,
        reason: 'Authentication token rejected: Invalid, expired, or revoked session token',
        endpoint: pathname,
        tokenSnippet,
        latencyMs,
        clientIp,
      });
      socket.write(
        'HTTP/1.1 401 Unauthorized\r\n' +
        'Content-Type: text/plain\r\n' +
        'X-PChat-Auth-Failure: Invalid token\r\n' +
        '\r\n' +
        'The provided authentication token was rejected by PChat server. Please re-authenticate.'
      );
      socket.destroy();
      return;
    }

    let conversationId: string | undefined;
    if (chatMatch) {
      conversationId = chatMatch[1];
      // Validate conversation membership
      if (!db.isUserInConversation(conversationId, user.id)) {
        const latencyMs = Date.now() - handshakeStart;
        recordHandshakeLog({
          status: 'rejected',
          code: 403,
          reason: `Membership authorization failed: User @${user.username} is not an authorized participant in conversation ${conversationId}`,
          endpoint: pathname,
          userId: user.id,
          username: user.username,
          tokenSnippet,
          latencyMs,
          clientIp,
        });
        socket.write(
          'HTTP/1.1 403 Forbidden\r\n' +
          'Content-Type: text/plain\r\n' +
          'X-PChat-Auth-Failure: Conversation membership forbidden\r\n' +
          '\r\n' +
          'Forbidden: You are not an authorized member of this conversation.'
        );
        socket.destroy();
        return;
      }
    }

    const latencyMs = Date.now() - handshakeStart;
    recordHandshakeLog({
      status: 'accepted',
      code: 101,
      reason: 'Authentication and conversation membership verified successfully',
      endpoint: pathname,
      userId: user.id,
      username: user.username,
      tokenSnippet,
      latencyMs,
      clientIp,
    });

    wss.handleUpgrade(request, socket, head, ws => {
      const extWs = ws as ExtendedWebSocket;
      extWs.isAlive = true;
      extWs.user = user;
      extWs.conversationId = conversationId;
      extWs.isGeneral = isGeneral;
      wss.emit('connection', extWs, request);
    });
  });

  wss.on('connection', (ws: ExtendedWebSocket) => {
    const user = ws.user!;
    const userId = user.id;

    // Clear any pending offline timer if user is reconnecting
    if (offlineGraceTimers.has(userId)) {
      clearTimeout(offlineGraceTimers.get(userId));
      offlineGraceTimers.delete(userId);
    }

    // Track user socket
    if (!userSockets.has(userId)) {
      userSockets.set(userId, new Set());
    }
    userSockets.get(userId)!.add(ws);

    // Update user online status
    db.setUserOnlineStatus(userId, true);
    broadcastOnlineStatus(userId, true);

    // If joined specific conversation room
    if (ws.conversationId) {
      const convId = ws.conversationId;
      if (!conversationRooms.has(convId)) {
        conversationRooms.set(convId, new Set());
      }
      conversationRooms.get(convId)!.add(ws);
    }

    // Automatically deliver any sent messages for this user (both room and general sockets)
    const deliveredMsgIds = db.markMessagesDeliveredForUser(userId);
    deliveredMsgIds.forEach(msgId => {
      const msg = db.findMessageById(msgId);
      if (msg) {
        broadcastToConversation(msg.conversation_id, {
          type: 'message:delivered',
          message_id: msg.id,
          conversation_id: msg.conversation_id,
          recipient_id: userId,
        });
      }
    });

    // Keepalive ping pong
    ws.on('pong', () => {
      ws.isAlive = true;
    });

    // Message handler
    ws.on('message', (rawData: string) => {
      try {
        const data = JSON.parse(rawData.toString());
        handleClientMessage(ws, data);
      } catch (err) {
        console.error('WebSocket parse error:', err);
        ws.send(JSON.stringify({ type: 'error', message: 'Malformed JSON payload.' }));
      }
    });

    // Disconnect handler with presence grace period
    ws.on('close', () => {
      if (ws.conversationId && conversationRooms.has(ws.conversationId)) {
        conversationRooms.get(ws.conversationId)!.delete(ws);
        if (conversationRooms.get(ws.conversationId)!.size === 0) {
          conversationRooms.delete(ws.conversationId);
        }
      }

      if (userSockets.has(userId)) {
        userSockets.get(userId)!.delete(ws);
        if (userSockets.get(userId)!.size === 0) {
          userSockets.delete(userId);
          
          // Debounce marking offline so switching rooms or rapid reconnect doesn't cause presence flicker
          const timer = setTimeout(() => {
            if (!userSockets.has(userId) || userSockets.get(userId)!.size === 0) {
              db.setUserOnlineStatus(userId, false);
              broadcastOnlineStatus(userId, false);
            }
            offlineGraceTimers.delete(userId);
          }, 2500);
          offlineGraceTimers.set(userId, timer);
        }
      }
    });

    // Send welcome confirmation with user info
    ws.send(JSON.stringify({
      type: 'connection:established',
      user: {
        id: user.id,
        username: user.username,
        display_name: user.display_name,
      },
      conversation_id: ws.conversationId || null,
      server_time: new Date().toISOString(),
    }));
  });

  // Heartbeat interval to check alive connections every 30s
  const interval = setInterval(() => {
    wss.clients.forEach((client: any) => {
      const extWs = client as ExtendedWebSocket;
      if (!extWs.isAlive) {
        return extWs.terminate();
      }
      extWs.isAlive = false;
      extWs.ping();
    });
  }, 30000);

  wss.on('close', () => {
    clearInterval(interval);
  });

  return wss;
}

function handleClientMessage(ws: ExtendedWebSocket, data: any) {
  const user = ws.user;
  if (!user) return;

  switch (data.type) {
    case 'message:send': {
      const convId = data.conversation_id || ws.conversationId;
      const rawText = data.text;
      const parentId = data.parent_message_id || data.reply_to_id || null;
      const audioUrl = data.audio_url || null;
      const audioDuration = typeof data.audio_duration === 'number' ? data.audio_duration : null;
      const imageUrl = data.image_url || null;

      const text = rawText && typeof rawText === 'string' && rawText.trim()
        ? rawText.trim()
        : (imageUrl ? '📷 Photo' : (audioUrl ? '🎤 Voice message' : ''));

      if (!convId || !text) {
        ws.send(JSON.stringify({ type: 'error', message: 'Conversation ID and non-empty text, image, or audio required.' }));
        return;
      }

      if (!db.isUserInConversation(convId, user.id)) {
        ws.send(JSON.stringify({ type: 'error', message: 'Unauthorized: not a conversation member.' }));
        return;
      }

      // Check text limit
      if (text.length > 4000) {
        ws.send(JSON.stringify({ type: 'error', message: 'Message exceeds maximum length.' }));
        return;
      }

      const now = new Date().toISOString();
      // Server determines sender from authenticated user (NEVER trusts client user_id)
      const newMsg = db.createMessage({
        id: `msg_${crypto.randomBytes(8).toString('hex')}`,
        conversation_id: convId,
        sender_id: user.id,
        text,
        reply_to_id: parentId,
        parent_message_id: parentId,
        status: 'sent',
        is_edited: false,
        is_deleted: false,
        created_at: now,
        updated_at: now,
        audio_url: audioUrl,
        audio_duration: audioDuration,
        image_url: imageUrl,
        reactions: {},
        client_temp_id: data.client_temp_id || null,
      });

      const parentMsg = parentId ? db.findMessageById(parentId) : null;

      const fullMsg = {
        ...newMsg,
        image_url: newMsg.image_url,
        parent_message_id: parentId,
        parent_message: parentMsg,
        sender: {
          id: user.id,
          username: user.username,
          display_name: user.display_name,
          avatar_url: user.avatar_url,
        },
        reply_to: parentMsg,
        client_temp_id: newMsg.client_temp_id || data.client_temp_id || null, // for optimistic sender reconciliation
      };

      // Broadcast to room
      broadcastToConversation(convId, {
        type: 'message:new',
        message: fullMsg,
        conversation_id: convId,
      });

      // Send Web Push notification to offline/background devices
      sendPushForNewMessage(convId, user.id, newMsg, user.display_name).catch((err) => {
        console.warn('WS web push notification note:', err);
      });

      break;
    }

    case 'message:reaction': {
      const msgId = data.message_id;
      const emoji = data.emoji;
      if (!msgId || !emoji || typeof emoji !== 'string') return;
      const msg = db.findMessageById(msgId);
      if (!msg) return;
      if (!db.isUserInConversation(msg.conversation_id, user.id)) return;

      const cleanEmoji = emoji.trim();
      const result = db.toggleMessageReaction(msgId, user.id, cleanEmoji);
      if (result) {
        broadcastToConversation(msg.conversation_id, {
          type: 'message:reaction',
          message_id: msgId,
          conversation_id: msg.conversation_id,
          reactions: result.reactions,
          user_id: user.id,
          emoji: cleanEmoji,
        });
      }
      break;
    }

    case 'message:delivered': {
      const msgId = data.message_id;
      if (!msgId) return;
      const msg = db.findMessageById(msgId);
      if (msg && msg.sender_id !== user.id && msg.status === 'sent') {
        db.updateMessage(msgId, { status: 'delivered' });
        broadcastToConversation(msg.conversation_id, {
          type: 'message:delivered',
          message_id: msgId,
          conversation_id: msg.conversation_id,
          recipient_id: user.id,
        });
      }
      break;
    }

    case 'message:read': {
      const msgId = data.message_id;
      const convId = data.conversation_id || ws.conversationId;
      if (!msgId || !convId) return;

      db.recordReadReceipt(msgId, user.id);
      db.updateLastReadMessage(convId, user.id, msgId);

      broadcastToConversation(convId, {
        type: 'message:read',
        message_id: msgId,
        conversation_id: convId,
        reader_id: user.id,
      });
      break;
    }

    case 'typing:start': {
      const convId = data.conversation_id || ws.conversationId;
      if (!convId) return;
      broadcastToConversation(convId, {
        type: 'typing:status',
        conversation_id: convId,
        user_id: user.id,
        username: user.username,
        display_name: user.display_name,
        is_typing: true,
      });
      break;
    }

    case 'typing:stop': {
      const convId = data.conversation_id || ws.conversationId;
      if (!convId) return;
      broadcastToConversation(convId, {
        type: 'typing:status',
        conversation_id: convId,
        user_id: user.id,
        username: user.username,
        display_name: user.display_name,
        is_typing: false,
      });
      break;
    }

    case 'ping': {
      ws.send(JSON.stringify({
        type: 'pong',
        echoTimestamp: data.timestamp,
        serverTimestamp: Date.now(),
      }));
      break;
    }

    default:
      break;
  }
}

function broadcastOnlineStatus(userId: string, isOnline: boolean) {
  const payload = JSON.stringify({
    type: 'presence:status',
    user_id: userId,
    is_online: isOnline,
    last_seen: new Date().toISOString(),
  });

  userSockets.forEach(sockets => {
    sockets.forEach(ws => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(payload);
      }
    });
  });
}
