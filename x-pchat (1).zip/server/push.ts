import webpush from 'web-push';
import { db } from './db.js';

let pushInitialized = false;

export function ensurePushService() {
  if (pushInitialized) return;
  try {
    const keys = db.getOrGenerateVapidKeys();
    webpush.setVapidDetails(
      'mailto:notifications@pchat.app',
      keys.publicKey,
      keys.privateKey
    );
    pushInitialized = true;
  } catch (err) {
    console.warn('Push service init note:', err);
  }
}

export function getPublicVapidKey(): string {
  ensurePushService();
  const keys = db.getOrGenerateVapidKeys();
  return keys.publicKey;
}

export interface PushNotificationPayload {
  title: string;
  body: string;
  icon?: string;
  badge?: string;
  url?: string;
  tag?: string;
  data?: any;
}

export async function sendWebPushToUser(userId: string, payload: PushNotificationPayload) {
  ensurePushService();

  // Check user's notification preferences
  const settings = db.getUserNotificationSettings(userId);
  if (!settings.push_enabled) {
    return;
  }

  const subscriptions = db.getUserPushSubscriptions(userId);
  const deviceTokens = db.getUserDeviceTokens(userId);

  if ((!subscriptions || subscriptions.length === 0) && (!deviceTokens || deviceTokens.length === 0)) {
    return;
  }

  // Adjust preview based on user privacy setting
  let effectiveBody = payload.body;
  if (!settings.show_preview && effectiveBody && effectiveBody !== 'New message') {
    effectiveBody = 'New message received';
  }

  const payloadString = JSON.stringify({
    title: payload.title,
    body: effectiveBody,
    icon: payload.icon || '/pchat-logo.png',
    badge: payload.badge || '/icon.svg',
    url: payload.url || `/?conv=${payload.data?.conversation_id || ''}`,
    tag: payload.tag || (payload.data?.conversation_id ? `conv-${payload.data.conversation_id}` : 'general'),
    data: {
      ...(payload.data || {}),
      sound_enabled: settings.sound_enabled,
      vibration_enabled: settings.vibration_enabled,
    },
  });

  const deadEndpoints: string[] = [];

  // 1. Dispatch to W3C Web Push Subscriptions
  if (subscriptions && subscriptions.length > 0) {
    await Promise.all(
      subscriptions.map(async (sub) => {
        try {
          await webpush.sendNotification(
            {
              endpoint: sub.endpoint,
              keys: {
                p256dh: sub.keys.p256dh,
                auth: sub.keys.auth,
              },
            },
            payloadString,
            {
              TTL: 60 * 60 * 24, // 24 hours persistence
              urgency: 'high',
            }
          );
        } catch (err: any) {
          if (err.statusCode === 404 || err.statusCode === 410) {
            deadEndpoints.push(sub.endpoint);
          } else {
            console.warn('Web push delivery note:', err?.message || err);
          }
        }
      })
    );
  }

  // 2. Dispatch to Registered Device Tokens (FCM & Native Web Push)
  if (deviceTokens && deviceTokens.length > 0) {
    const fcmServerKey = process.env.FIREBASE_SERVER_KEY || process.env.FCM_SERVER_KEY;
    await Promise.all(
      deviceTokens.map(async (dt) => {
        try {
          if (fcmServerKey) {
            // Direct FCM Legacy / v1 HTTP request when server key configured
            const fcmRes = await fetch('https://fcm.googleapis.com/fcm/send', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                Authorization: `key=${fcmServerKey}`,
              },
              body: JSON.stringify({
                to: dt.device_token,
                notification: {
                  title: payload.title,
                  body: effectiveBody,
                  icon: payload.icon || '/pchat-logo.png',
                },
                data: {
                  url: payload.url || `/?conv=${payload.data?.conversation_id || ''}`,
                  conversation_id: payload.data?.conversation_id || '',
                  message_id: payload.data?.message_id || '',
                },
                priority: 'high',
              }),
            });

            if (fcmRes.status === 400 || fcmRes.status === 404) {
              db.unregisterDeviceToken(dt.device_token);
            }
          }
        } catch (err: any) {
          console.warn('FCM delivery note:', err?.message || err);
        }
      })
    );
  }

  for (const ep of deadEndpoints) {
    db.deletePushSubscription(ep);
  }
}

export async function sendPushForNewMessage(
  conversationId: string,
  senderId: string,
  message: { id: string; text: string; audio_url?: string | null; image_url?: string | null },
  senderName: string
) {
  try {
    const members = db.getConversationMembers(conversationId);
    const conv = db.findConversationById(conversationId);

    const bodyText = message.image_url
      ? '📷 Photo'
      : (message.audio_url
          ? '🎤 Voice message'
          : (message.text ? (message.text.length > 100 ? `${message.text.substring(0, 100)}...` : message.text) : 'New message'));

    const notifTitle = conv?.type === 'group'
      ? `${conv.title || '🎋 Bamboo Grove'} · ${senderName}`
      : `${senderName} 🐼`;

    for (const member of members) {
      if (member.id === senderId) continue;

      // Skip push if user muted this conversation
      if (db.isConversationMutedForUser(conversationId, member.id)) {
        continue;
      }

      // Check recipient's push notification settings
      const settings = db.getUserNotificationSettings(member.id);
      if (!settings.push_enabled) {
        continue;
      }

      const displayBody = settings.show_preview ? bodyText : 'New message received';

      // 1. Authoritative in-database Notification record
      db.createNotification({
        recipient_id: member.id,
        sender_id: senderId,
        conversation_id: conversationId,
        message_id: message.id,
        notification_type: conv?.type === 'group' ? 'group' : 'message',
        title: notifTitle,
        body: displayBody,
      });

      // 2. Dispatch Push Notification
      await sendWebPushToUser(member.id, {
        title: notifTitle,
        body: displayBody,
        icon: '/pchat-logo.png',
        badge: '/icon.svg',
        data: {
          conversation_id: conversationId,
          message_id: message.id,
        },
      });
    }
  } catch (err) {
    console.warn('sendPushForNewMessage error:', err);
  }
}

export async function sendTestNotificationToUser(userId: string) {
  const notif = db.createNotification({
    recipient_id: userId,
    notification_type: 'system',
    title: '🐼 PChat Push Notifications Operational!',
    body: 'Background notifications, lock screen alerts, and audio chimes are fully active on this device.',
  });

  await sendWebPushToUser(userId, {
    title: notif.title,
    body: notif.body,
    icon: '/pchat-logo.png',
    badge: '/icon.svg',
    data: {
      notification_id: notif.notification_id,
      conversation_id: 'conv_panda_hangout',
    },
  });

  return notif;
}
