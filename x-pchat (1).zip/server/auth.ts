import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { Request, Response, NextFunction } from 'express';
import { db, User } from './db.js';

export interface AuthenticatedRequest extends Request {
  user?: User;
}

const SECRET_KEY = process.env.SECRET_KEY || 'pchat-super-secret-django-key-32-chars-minimum-2026';

export interface JwtTokenPayload {
  userId: string;
  username: string;
  displayName?: string;
  iat: number;
  exp: number;
}

export function parseCookies(cookieHeader?: string): Record<string, string> {
  const cookies: Record<string, string> = {};
  if (!cookieHeader) return cookies;
  const parts = cookieHeader.split(';');
  for (const part of parts) {
    const trimmed = part.trim();
    const eqIdx = trimmed.indexOf('=');
    if (eqIdx !== -1) {
      const key = trimmed.substring(0, eqIdx).trim();
      const val = trimmed.substring(eqIdx + 1).trim();
      try {
        cookies[key] = decodeURIComponent(val);
      } catch {
        cookies[key] = val;
      }
    }
  }
  return cookies;
}

function base64UrlEncode(str: string): string {
  return Buffer.from(str)
    .toString('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
}

function base64UrlDecode(str: string): string {
  let base64 = str.replace(/-/g, '+').replace(/_/g, '/');
  while (base64.length % 4) {
    base64 += '=';
  }
  return Buffer.from(base64, 'base64').toString('utf-8');
}

export function signJwt(
  payload: { userId: string; username: string; displayName?: string },
  expiresInSeconds: number = 30 * 24 * 3600 // 30 days
): string {
  const now = Math.floor(Date.now() / 1000);
  const fullPayload: JwtTokenPayload = {
    ...payload,
    iat: now,
    exp: now + expiresInSeconds,
  };
  const header = { alg: 'HS256', typ: 'JWT' };
  const encodedHeader = base64UrlEncode(JSON.stringify(header));
  const encodedPayload = base64UrlEncode(JSON.stringify(fullPayload));
  const data = `${encodedHeader}.${encodedPayload}`;
  const signature = crypto
    .createHmac('sha256', SECRET_KEY)
    .update(data)
    .digest('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');

  return `${data}.${signature}`;
}

export function verifyJwt(token: string): JwtTokenPayload | null {
  if (!token || typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;

  const [encodedHeader, encodedPayload, signature] = parts;
  const data = `${encodedHeader}.${encodedPayload}`;
  const expectedSig = crypto
    .createHmac('sha256', SECRET_KEY)
    .update(data)
    .digest('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');

  if (signature.length !== expectedSig.length) return null;
  if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSig))) {
    return null;
  }

  try {
    const payloadStr = base64UrlDecode(encodedPayload);
    const payload: JwtTokenPayload = JSON.parse(payloadStr);
    const now = Math.floor(Date.now() / 1000);
    if (payload.exp && payload.exp < now) {
      return null; // Expired
    }
    return payload;
  } catch {
    return null;
  }
}

export function hashPassword(plainText: string): Promise<string> {
  return bcrypt.hash(plainText, 10);
}

export function comparePassword(plainText: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plainText, hash);
}

export function generateToken(user?: { id: string; username: string; display_name?: string }): string {
  if (user) {
    return signJwt({
      userId: user.id,
      username: user.username,
      displayName: user.display_name,
    });
  }
  // Fallback random token
  return crypto.randomBytes(32).toString('hex');
}

export function isValidUsername(username: string): boolean {
  return typeof username === 'string' && username.trim().length >= 1;
}

export function isValidEmail(email: string): boolean {
  return typeof email === 'string' && email.trim().length >= 3 && email.includes('@');
}

export function authenticateUser(token: string): User | null {
  if (!token) return null;

  // 1. First, check if token is a cryptographic JWT
  const jwtPayload = verifyJwt(token);
  if (jwtPayload) {
    let user = db.findUserById(jwtPayload.userId);
    if (!user) {
      user = db.findUserByUsername(jwtPayload.username);
    }
    // Auto-heal: If user is verified by cryptographic JWT signature but not in DB (e.g. container scale/recycle),
    // restore the user record immediately so session and data access continue seamlessly
    if (!user && jwtPayload.userId && jwtPayload.username) {
      try {
        user = db.createUser({
          id: jwtPayload.userId,
          username: jwtPayload.username,
          email: `${jwtPayload.username.toLowerCase().replace(/\s+/g, '_')}@pchat.app`,
          password_hash: '', // Pre-authenticated via cryptographic JWT signature
          display_name: jwtPayload.displayName || jwtPayload.username,
          bio: 'PChat Member 🐼',
          avatar_url: '/avatars/panda-zen.svg',
          is_online: true,
          last_seen: new Date().toISOString(),
          created_at: new Date(jwtPayload.iat * 1000).toISOString(),
        });
        db.ensureUserInHangout(user.id);
      } catch {
        user = db.findUserByUsername(jwtPayload.username) || db.findUserById(jwtPayload.userId);
      }
    }
    if (user) {
      return user;
    }
  }

  // 2. Fallback: check session table in database
  const session = db.findSession(token);
  if (session) {
    const user = db.findUserById(session.user_id);
    if (user) return user;
  }

  return null;
}

export function authMiddleware(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  let token: string | undefined;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.substring(7).trim();
  }

  if (!token && req.headers.cookie) {
    const cookies = parseCookies(req.headers.cookie);
    token = cookies.pchat_token || cookies.pchat_session;
  }

  if (!token && typeof req.query.token === 'string') {
    token = req.query.token;
  }

  if (!token) {
    res.status(401).json({
      error: 'Authentication required. Please log in.',
      code: 'AUTH_REQUIRED',
    });
    return;
  }

  const user = authenticateUser(token);
  if (!user) {
    res.status(401).json({
      error: 'Invalid or expired session. Please log in again.',
      code: 'INVALID_TOKEN',
    });
    return;
  }

  req.user = user;
  next();
}
