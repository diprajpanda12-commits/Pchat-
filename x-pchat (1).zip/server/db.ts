import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import webpush from 'web-push';
import Database from 'better-sqlite3';
import { fileURLToPath } from 'url';

export interface User {
  id: string;
  username: string;
  email: string;
  password_hash: string;
  display_name: string;
  bio: string;
  avatar_url: string;
  is_online: boolean;
  last_seen: string;
  created_at: string;
}

export interface Conversation {
  id: string;
  type: 'direct' | 'group';
  title: string;
  avatar_url: string;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface Membership {
  conversation_id: string;
  user_id: string;
  role: 'admin' | 'member';
  joined_at: string;
  last_read_message_id: string | null;
  is_muted?: boolean;
}

export interface PushSubscriptionRecord {
  id: string;
  user_id: string;
  endpoint: string;
  keys: {
    p256dh: string;
    auth: string;
  };
  created_at: string;
  user_agent?: string;
}

export interface VapidKeys {
  publicKey: string;
  privateKey: string;
}

export interface Message {
  id: string;
  conversation_id: string;
  sender_id: string;
  text: string;
  reply_to_id: string | null;
  parent_message_id?: string | null;
  status: 'pending' | 'sent' | 'delivered' | 'read';
  is_edited: boolean;
  is_deleted: boolean;
  created_at: string;
  updated_at: string;
  reactions?: Record<string, string[]>;
  audio_url?: string | null;
  audio_duration?: number | null;
  image_url?: string | null;
  client_temp_id?: string | null;
}

export interface ReadReceipt {
  message_id: string;
  user_id: string;
  read_at: string;
}

export interface Session {
  token: string;
  user_id: string;
  created_at: string;
  expires_at: string;
}

export interface ScheduledMessage {
  id: string;
  conversation_id: string;
  sender_id: string;
  text: string;
  reply_to_id: string | null;
  parent_message_id?: string | null;
  scheduled_for: string; // ISO 8601 string
  created_at: string;
  status: 'pending' | 'sent' | 'cancelled';
}

export interface DeviceTokenRecord {
  id: string;
  user_id: string;
  device_token: string;
  device_type: 'web' | 'android' | 'ios' | 'desktop';
  created_at: string;
  updated_at: string;
  is_active: boolean;
}

export interface NotificationRecord {
  notification_id: string;
  recipient_id: string;
  sender_id?: string | null;
  conversation_id?: string | null;
  message_id?: string | null;
  notification_type: 'message' | 'missed' | 'group' | 'mention' | 'system';
  title: string;
  body: string;
  is_read: boolean;
  created_at: string;
}

export interface UserNotificationSettings {
  user_id: string;
  push_enabled: boolean;
  sound_enabled: boolean;
  vibration_enabled: boolean;
  show_preview: boolean;
  updated_at: string;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = process.env.DATA_DIR || path.resolve(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'pchat.db');
const BACKUP_FILE = path.join(DATA_DIR, 'pchat_db_backup.sqlite');
const LEGACY_JSON_FILE = path.join(DATA_DIR, 'pchat_db.json');
const MIGRATED_JSON_FILE = path.join(DATA_DIR, 'pchat_db.json.migrated');

class SQLiteDatabase {
  private sqlite: Database.Database;

  constructor() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }

    this.sqlite = new Database(DB_FILE);

    // Configure robust WAL mode, timeout and pragmas
    this.sqlite.pragma('journal_mode = WAL');
    this.sqlite.pragma('busy_timeout = 5000');
    this.sqlite.pragma('synchronous = NORMAL');
    this.sqlite.pragma('foreign_keys = ON');

    this.initTables();
    this.migrateFromLegacyJSON();
    this.seedDefaultData();
  }

  private initTables() {
    this.sqlite.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        username TEXT NOT NULL UNIQUE COLLATE NOCASE,
        email TEXT NOT NULL UNIQUE COLLATE NOCASE,
        password_hash TEXT NOT NULL,
        display_name TEXT NOT NULL,
        bio TEXT NOT NULL DEFAULT '',
        avatar_url TEXT NOT NULL DEFAULT '',
        is_online INTEGER NOT NULL DEFAULT 0,
        last_seen TEXT NOT NULL,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS conversations (
        id TEXT PRIMARY KEY,
        type TEXT NOT NULL,
        title TEXT NOT NULL,
        avatar_url TEXT NOT NULL DEFAULT '',
        created_by TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS memberships (
        conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
        user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        role TEXT NOT NULL DEFAULT 'member',
        joined_at TEXT NOT NULL,
        last_read_message_id TEXT,
        is_muted INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (conversation_id, user_id)
      );
      CREATE INDEX IF NOT EXISTS idx_memberships_user ON memberships(user_id);

      CREATE TABLE IF NOT EXISTS messages (
        id TEXT PRIMARY KEY,
        conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
        sender_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        text TEXT NOT NULL,
        reply_to_id TEXT,
        parent_message_id TEXT,
        status TEXT NOT NULL DEFAULT 'sent',
        is_edited INTEGER NOT NULL DEFAULT 0,
        is_deleted INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        reactions TEXT NOT NULL DEFAULT '{}',
        audio_url TEXT,
        audio_duration REAL,
        image_url TEXT,
        client_temp_id TEXT
      );
      CREATE INDEX IF NOT EXISTS idx_messages_conv_created ON messages(conversation_id, created_at);
      CREATE INDEX IF NOT EXISTS idx_messages_sender ON messages(sender_id);
      CREATE INDEX IF NOT EXISTS idx_messages_client_temp ON messages(client_temp_id);

      CREATE TABLE IF NOT EXISTS read_receipts (
        message_id TEXT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
        user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        read_at TEXT NOT NULL,
        PRIMARY KEY (message_id, user_id)
      );

      CREATE TABLE IF NOT EXISTS sessions (
        token TEXT PRIMARY KEY,
        user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        created_at TEXT NOT NULL,
        expires_at TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

      CREATE TABLE IF NOT EXISTS scheduled_messages (
        id TEXT PRIMARY KEY,
        conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
        sender_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        text TEXT NOT NULL,
        reply_to_id TEXT,
        parent_message_id TEXT,
        scheduled_for TEXT NOT NULL,
        created_at TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending'
      );
      CREATE INDEX IF NOT EXISTS idx_scheduled_due ON scheduled_messages(status, scheduled_for);

      CREATE TABLE IF NOT EXISTS push_subscriptions (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        endpoint TEXT NOT NULL UNIQUE,
        p256dh TEXT NOT NULL,
        auth TEXT NOT NULL,
        created_at TEXT NOT NULL,
        user_agent TEXT
      );
      CREATE INDEX IF NOT EXISTS idx_push_subs_user ON push_subscriptions(user_id);

      CREATE TABLE IF NOT EXISTS vapid_keys (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        public_key TEXT NOT NULL,
        private_key TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS device_tokens (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        device_token TEXT NOT NULL UNIQUE,
        device_type TEXT NOT NULL DEFAULT 'web',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        is_active INTEGER NOT NULL DEFAULT 1
      );
      CREATE INDEX IF NOT EXISTS idx_device_tokens_user ON device_tokens(user_id);
      CREATE INDEX IF NOT EXISTS idx_device_tokens_active ON device_tokens(is_active);

      CREATE TABLE IF NOT EXISTS notifications (
        notification_id TEXT PRIMARY KEY,
        recipient_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        sender_id TEXT REFERENCES users(id) ON DELETE SET NULL,
        conversation_id TEXT REFERENCES conversations(id) ON DELETE CASCADE,
        message_id TEXT REFERENCES messages(id) ON DELETE CASCADE,
        notification_type TEXT NOT NULL DEFAULT 'message',
        title TEXT NOT NULL,
        body TEXT NOT NULL,
        is_read INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_notifications_recipient ON notifications(recipient_id, is_read);
      CREATE INDEX IF NOT EXISTS idx_notifications_created ON notifications(created_at);

      CREATE TABLE IF NOT EXISTS user_notification_settings (
        user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
        push_enabled INTEGER NOT NULL DEFAULT 1,
        sound_enabled INTEGER NOT NULL DEFAULT 1,
        vibration_enabled INTEGER NOT NULL DEFAULT 1,
        show_preview INTEGER NOT NULL DEFAULT 1,
        updated_at TEXT NOT NULL
      );
    `);

    // Safely add image_url column if migrating an existing SQLite database
    try {
      this.sqlite.exec(`ALTER TABLE messages ADD COLUMN image_url TEXT`);
    } catch {}
  }

  private migrateFromLegacyJSON() {
    if (!fs.existsSync(LEGACY_JSON_FILE)) {
      return;
    }

    try {
      const userCount = (this.sqlite.prepare('SELECT COUNT(*) as count FROM users').get() as any).count;
      if (userCount > 0) {
        // SQLite DB already contains records; archive legacy JSON safely without re-import
        fs.renameSync(LEGACY_JSON_FILE, MIGRATED_JSON_FILE);
        return;
      }

      const raw = fs.readFileSync(LEGACY_JSON_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      if (!parsed || !Array.isArray(parsed.users)) {
        return;
      }

      console.log('[*] PChat: Starting one-time migration from pchat_db.json into SQLite...');

      const insertUser = this.sqlite.prepare(`
        INSERT OR IGNORE INTO users (id, username, email, password_hash, display_name, bio, avatar_url, is_online, last_seen, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      const insertConv = this.sqlite.prepare(`
        INSERT OR IGNORE INTO conversations (id, type, title, avatar_url, created_by, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `);
      const insertMem = this.sqlite.prepare(`
        INSERT OR IGNORE INTO memberships (conversation_id, user_id, role, joined_at, last_read_message_id, is_muted)
        VALUES (?, ?, ?, ?, ?, ?)
      `);
      const insertMsg = this.sqlite.prepare(`
        INSERT OR IGNORE INTO messages (id, conversation_id, sender_id, text, reply_to_id, parent_message_id, status, is_edited, is_deleted, created_at, updated_at, reactions, audio_url, audio_duration, client_temp_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      const insertReceipt = this.sqlite.prepare(`
        INSERT OR IGNORE INTO read_receipts (message_id, user_id, read_at)
        VALUES (?, ?, ?)
      `);
      const insertSession = this.sqlite.prepare(`
        INSERT OR IGNORE INTO sessions (token, user_id, created_at, expires_at)
        VALUES (?, ?, ?, ?)
      `);
      const insertSched = this.sqlite.prepare(`
        INSERT OR IGNORE INTO scheduled_messages (id, conversation_id, sender_id, text, reply_to_id, parent_message_id, scheduled_for, created_at, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      const insertPush = this.sqlite.prepare(`
        INSERT OR IGNORE INTO push_subscriptions (id, user_id, endpoint, p256dh, auth, created_at, user_agent)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `);
      const insertVapid = this.sqlite.prepare(`
        INSERT OR REPLACE INTO vapid_keys (id, public_key, private_key)
        VALUES (1, ?, ?)
      `);

      const migrationTx = this.sqlite.transaction(() => {
        // Users
        for (const u of parsed.users || []) {
          insertUser.run(
            u.id,
            u.username,
            u.email,
            u.password_hash,
            u.display_name,
            u.bio || '',
            u.avatar_url || '',
            u.is_online ? 1 : 0,
            u.last_seen || new Date().toISOString(),
            u.created_at || new Date().toISOString()
          );
        }

        // Conversations
        for (const c of parsed.conversations || []) {
          insertConv.run(
            c.id,
            c.type,
            c.title,
            c.avatar_url || '',
            c.created_by,
            c.created_at || new Date().toISOString(),
            c.updated_at || new Date().toISOString()
          );
        }

        // Memberships
        for (const m of parsed.memberships || []) {
          insertMem.run(
            m.conversation_id,
            m.user_id,
            m.role || 'member',
            m.joined_at || new Date().toISOString(),
            m.last_read_message_id || null,
            m.is_muted ? 1 : 0
          );
        }

        // Messages
        for (const msg of parsed.messages || []) {
          insertMsg.run(
            msg.id,
            msg.conversation_id,
            msg.sender_id,
            msg.text || '',
            msg.reply_to_id || null,
            msg.parent_message_id || msg.reply_to_id || null,
            msg.status || 'sent',
            msg.is_edited ? 1 : 0,
            msg.is_deleted ? 1 : 0,
            msg.created_at || new Date().toISOString(),
            msg.updated_at || msg.created_at || new Date().toISOString(),
            typeof msg.reactions === 'string' ? msg.reactions : JSON.stringify(msg.reactions || {}),
            msg.audio_url || null,
            typeof msg.audio_duration === 'number' ? msg.audio_duration : null,
            msg.client_temp_id || null
          );
        }

        // Read Receipts
        for (const r of parsed.read_receipts || []) {
          insertReceipt.run(r.message_id, r.user_id, r.read_at || new Date().toISOString());
        }

        // Sessions
        for (const s of parsed.sessions || []) {
          insertSession.run(s.token, s.user_id, s.created_at || new Date().toISOString(), s.expires_at || new Date().toISOString());
        }

        // Scheduled Messages
        for (const sm of parsed.scheduled_messages || []) {
          insertSched.run(
            sm.id,
            sm.conversation_id,
            sm.sender_id,
            sm.text,
            sm.reply_to_id || null,
            sm.parent_message_id || sm.reply_to_id || null,
            sm.scheduled_for,
            sm.created_at || new Date().toISOString(),
            sm.status || 'pending'
          );
        }

        // Push Subscriptions
        for (const ps of parsed.push_subscriptions || []) {
          insertPush.run(
            ps.id,
            ps.user_id,
            ps.endpoint,
            ps.keys?.p256dh || '',
            ps.keys?.auth || '',
            ps.created_at || new Date().toISOString(),
            ps.user_agent || null
          );
        }

        // Vapid Keys
        if (parsed.vapid_keys?.publicKey && parsed.vapid_keys?.privateKey) {
          insertVapid.run(parsed.vapid_keys.publicKey, parsed.vapid_keys.privateKey);
        }
      });

      migrationTx();

      // Safely rename original JSON to prevent repeated migrations while retaining data
      fs.renameSync(LEGACY_JSON_FILE, MIGRATED_JSON_FILE);
      if (fs.existsSync(path.join(DATA_DIR, 'pchat_db.json.bak'))) {
        try {
          fs.renameSync(path.join(DATA_DIR, 'pchat_db.json.bak'), path.join(DATA_DIR, 'pchat_db.json.bak.migrated'));
        } catch {}
      }

      console.log('[✓] PChat: SQLite migration completed successfully.');
    } catch (err) {
      console.error('[!] PChat SQLite migration error:', err);
    }
  }

  private mapUser(row: any): User {
    return {
      id: row.id,
      username: row.username,
      email: row.email,
      password_hash: row.password_hash,
      display_name: row.display_name,
      bio: row.bio || '',
      avatar_url: row.avatar_url || '',
      is_online: Boolean(row.is_online),
      last_seen: row.last_seen,
      created_at: row.created_at,
    };
  }

  private mapConv(row: any): Conversation {
    return {
      id: row.id,
      type: row.type,
      title: row.title,
      avatar_url: row.avatar_url || '',
      created_by: row.created_by,
      created_at: row.created_at,
      updated_at: row.updated_at,
    };
  }

  private mapMessage(row: any): Message {
    let parsedReactions = {};
    if (row.reactions) {
      try {
        parsedReactions = JSON.parse(row.reactions);
      } catch {}
    }
    return {
      id: row.id,
      conversation_id: row.conversation_id,
      sender_id: row.sender_id,
      text: row.text,
      reply_to_id: row.reply_to_id || null,
      parent_message_id: row.parent_message_id || row.reply_to_id || null,
      status: row.status,
      is_edited: Boolean(row.is_edited),
      is_deleted: Boolean(row.is_deleted),
      created_at: row.created_at,
      updated_at: row.updated_at,
      reactions: parsedReactions,
      audio_url: row.audio_url || null,
      audio_duration: typeof row.audio_duration === 'number' ? row.audio_duration : null,
      image_url: row.image_url || null,
      client_temp_id: row.client_temp_id || null,
    };
  }

  private mapScheduledMsg(row: any): ScheduledMessage {
    return {
      id: row.id,
      conversation_id: row.conversation_id,
      sender_id: row.sender_id,
      text: row.text,
      reply_to_id: row.reply_to_id || null,
      parent_message_id: row.parent_message_id || row.reply_to_id || null,
      scheduled_for: row.scheduled_for,
      created_at: row.created_at,
      status: row.status,
    };
  }

  // Backup & Stats APIs
  public save(): void {
    // SQLite automatically commits transactions to disk and WAL.
    // Run a passive checkpoint to checkpoint pages if idle.
    try {
      this.sqlite.pragma('wal_checkpoint(PASSIVE)');
    } catch {}
  }

  public forceSave(): void {
    try {
      this.sqlite.pragma('wal_checkpoint(TRUNCATE)');
    } catch (err) {
      console.error('Failed to truncate WAL:', err);
    }
  }

  public createBackup(): string | null {
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupPath = path.join(DATA_DIR, `pchat_db_backup_${timestamp}.sqlite`);
      // SQLite online backup API
      this.sqlite.backup(backupPath);
      return backupPath;
    } catch (err) {
      console.error('Failed to create SQLite backup:', err);
      return null;
    }
  }

  public getStats() {
    const usersCount = (this.sqlite.prepare('SELECT COUNT(*) as count FROM users').get() as any).count;
    const conversationsCount = (this.sqlite.prepare('SELECT COUNT(*) as count FROM conversations').get() as any).count;
    const messagesCount = (this.sqlite.prepare('SELECT COUNT(*) as count FROM messages').get() as any).count;
    const activeSessionsCount = (this.sqlite.prepare("SELECT COUNT(*) as count FROM sessions WHERE expires_at > ?").get(new Date().toISOString()) as any).count;
    const membershipsCount = (this.sqlite.prepare('SELECT COUNT(*) as count FROM memberships').get() as any).count;

    return {
      usersCount,
      conversationsCount,
      messagesCount,
      activeSessionsCount,
      membershipsCount,
      storageFile: DB_FILE,
      backupFile: BACKUP_FILE,
    };
  }

  public seedDefaultData() {
    const defaultPasswordHash = bcrypt.hashSync('Panda@123', 10);
    const now = new Date().toISOString();

    const defaultUsers: User[] = [
      {
        id: 'u_alice',
        username: 'panda_alice',
        email: 'alice@pchat.app',
        password_hash: defaultPasswordHash,
        display_name: 'Alice Panda 🐼',
        bio: 'PChat Lead Tester & Panda enthusiast 🌿',
        avatar_url: '/avatars/panda-emerald.svg',
        is_online: true,
        last_seen: now,
        created_at: now,
      },
      {
        id: 'u_bob',
        username: 'panda_bob',
        email: 'bob@pchat.app',
        password_hash: defaultPasswordHash,
        display_name: 'Bob Panda 🎋',
        bio: 'Real-time WebSocket architect & coder ⚡',
        avatar_url: '/avatars/panda-cyber.svg',
        is_online: true,
        last_seen: now,
        created_at: now,
      },
      {
        id: 'u_charlie',
        username: 'panda_charlie',
        email: 'charlie@pchat.app',
        password_hash: defaultPasswordHash,
        display_name: 'Charlie Panda 🎯',
        bio: 'Security researcher & external tester 🛡️',
        avatar_url: '/avatars/panda-ninja.svg',
        is_online: false,
        last_seen: now,
        created_at: now,
      },
    ];

    const insertUser = this.sqlite.prepare(`
      INSERT INTO users (id, username, email, password_hash, display_name, bio, avatar_url, is_online, last_seen, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const u of defaultUsers) {
      const existing = this.findUserByUsername(u.username);
      if (!existing) {
        insertUser.run(
          u.id,
          u.username,
          u.email,
          u.password_hash,
          u.display_name,
          u.bio,
          u.avatar_url,
          u.is_online ? 1 : 0,
          u.last_seen,
          u.created_at
        );
      }
    }

    // Default Group Conversation: conv_panda_hangout
    const hangoutGroup = this.findConversationById('conv_panda_hangout');
    if (!hangoutGroup) {
      this.sqlite.prepare(`
        INSERT INTO conversations (id, type, title, avatar_url, created_by, created_at, updated_at)
        VALUES ('conv_panda_hangout', 'group', '🎋 Bamboo Grove Hangout', '/avatars/panda-royal.svg', 'u_alice', ?, ?)
      `).run(now, now);
    }

    // Ensure memberships for hangout group (clean core members)
    const requiredMembers = [
      { user_id: 'u_alice', role: 'admin' as const },
      { user_id: 'u_bob', role: 'member' as const },
    ];

    for (const rm of requiredMembers) {
      const hasMember = this.isUserInConversation('conv_panda_hangout', rm.user_id);
      if (!hasMember) {
        this.sqlite.prepare(`
          INSERT OR IGNORE INTO memberships (conversation_id, user_id, role, joined_at, last_read_message_id, is_muted)
          VALUES ('conv_panda_hangout', ?, ?, ?, NULL, 0)
        `).run(rm.user_id, rm.role, now);
      }
    }

    // Pre-seed initial welcoming messages if hangout conversation has none
    const msgCount = (this.sqlite.prepare(`
      SELECT COUNT(*) as count FROM messages WHERE conversation_id = 'conv_panda_hangout'
    `).get() as any).count;

    if (msgCount === 0) {
      const t1 = new Date(Date.now() - 3600000 * 2).toISOString();
      const t2 = new Date(Date.now() - 3600000 * 1.5).toISOString();

      const insertMsg = this.sqlite.prepare(`
        INSERT INTO messages (id, conversation_id, sender_id, text, reply_to_id, parent_message_id, status, is_edited, is_deleted, created_at, updated_at, reactions, audio_url, audio_duration, client_temp_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      insertMsg.run('msg_welcome_alice', 'conv_panda_hangout', 'u_alice', 'Welcome to PChat (Panda Chat)! 🐼 Real-time messaging, voice notes, and instant reactions are all active.', null, null, 'read', 0, 0, t1, t1, JSON.stringify({ '🐼': ['u_alice', 'u_bob'], '❤️': ['u_bob'] }), null, null, null);
      insertMsg.run('msg_welcome_bob', 'conv_panda_hangout', 'u_bob', 'All messages are synchronized via authenticated WebSockets with persistent storage and delivery status checks 🎋⚡', 'msg_welcome_alice', 'msg_welcome_alice', 'read', 0, 0, t2, t2, JSON.stringify({ '🔥': ['u_alice'] }), null, null, null);
    }
  }

  // User operations
  findUserById(id: string): User | undefined {
    const row = this.sqlite.prepare('SELECT * FROM users WHERE id = ?').get(id) as any;
    return row ? this.mapUser(row) : undefined;
  }

  findUserByIdentifier(identifier: string): User | undefined {
    if (!identifier || typeof identifier !== 'string') return undefined;
    const raw = identifier.trim().toLowerCase();
    const normalized = raw.replace(/\s+/g, '_');
    const withoutUnderscores = raw.replace(/_+/g, ' ');

    const row = this.sqlite.prepare(`
      SELECT * FROM users
      WHERE LOWER(username) IN (?, ?, ?)
         OR LOWER(email) = ?
         OR LOWER(display_name) IN (?, ?, ?)
      LIMIT 1
    `).get(raw, normalized, withoutUnderscores, raw, raw, normalized, withoutUnderscores) as any;

    return row ? this.mapUser(row) : undefined;
  }

  findUserByUsername(username: string): User | undefined {
    if (!username || typeof username !== 'string') return undefined;
    const q = username.trim().toLowerCase();
    const normalized = q.replace(/\s+/g, '_');
    const withoutUnderscores = q.replace(/_+/g, ' ');
    const row = this.sqlite.prepare(`
      SELECT * FROM users
      WHERE LOWER(username) IN (?, ?, ?)
      LIMIT 1
    `).get(q, normalized, withoutUnderscores) as any;
    return row ? this.mapUser(row) : undefined;
  }

  findUserByEmail(email: string): User | undefined {
    if (!email || typeof email !== 'string') return undefined;
    const q = email.trim().toLowerCase();
    const row = this.sqlite.prepare(`
      SELECT * FROM users WHERE LOWER(email) = ? LIMIT 1
    `).get(q) as any;
    return row ? this.mapUser(row) : undefined;
  }

  findUserByDisplayName(displayName: string): User | undefined {
    if (!displayName || typeof displayName !== 'string') return undefined;
    const q = displayName.trim().toLowerCase();
    const row = this.sqlite.prepare(`
      SELECT * FROM users WHERE LOWER(display_name) = ? LIMIT 1
    `).get(q) as any;
    return row ? this.mapUser(row) : undefined;
  }

  searchUsers(query: string, excludeUserId?: string): Omit<User, 'password_hash' | 'email'>[] {
    const q = query.trim().toLowerCase();
    const rows = this.sqlite.prepare(`
      SELECT id, username, display_name, bio, avatar_url, is_online, last_seen, created_at
      FROM users
      WHERE (? = '' OR id != ?)
        AND (LOWER(username) LIKE ? OR LOWER(display_name) LIKE ?)
      ORDER BY display_name ASC
    `).all(excludeUserId || '', excludeUserId || '', `%${q}%`, `%${q}%`) as any[];

    return rows.map(r => ({
      id: r.id,
      username: r.username,
      display_name: r.display_name,
      bio: r.bio || '',
      avatar_url: r.avatar_url || '',
      is_online: Boolean(r.is_online),
      last_seen: r.last_seen,
      created_at: r.created_at,
    }));
  }

  ensureUserInHangout(userId: string): void {
    const hasMember = this.isUserInConversation('conv_panda_hangout', userId);
    if (!hasMember) {
      this.sqlite.prepare(`
        INSERT OR IGNORE INTO memberships (conversation_id, user_id, role, joined_at, last_read_message_id, is_muted)
        VALUES ('conv_panda_hangout', ?, 'member', ?, NULL, 0)
      `).run(userId, new Date().toISOString());
    }
  }

  addMember(conversationId: string, userId: string, role: 'admin' | 'member' = 'member'): boolean {
    return this.addMemberToConversation(conversationId, userId, role);
  }

  createUser(user: User): User {
    const cleanUsername = user.username.trim().toLowerCase().replace(/\s+/g, '_');
    user.username = cleanUsername;
    const existingUser = this.findUserByUsername(cleanUsername);
    if (existingUser) {
      throw new Error(`Username '${user.username}' is already taken.`);
    }

    const cleanEmail = user.email.trim().toLowerCase();
    user.email = cleanEmail;
    const existingEmail = this.findUserByEmail(cleanEmail);
    if (existingEmail) {
      throw new Error(`Email '${user.email}' is already registered.`);
    }

    this.sqlite.prepare(`
      INSERT INTO users (id, username, email, password_hash, display_name, bio, avatar_url, is_online, last_seen, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      user.id,
      user.username,
      user.email,
      user.password_hash,
      user.display_name,
      user.bio || '',
      user.avatar_url || '',
      user.is_online ? 1 : 0,
      user.last_seen,
      user.created_at
    );
    return user;
  }

  updateUser(id: string, updates: Partial<User>): User | undefined {
    const user = this.findUserById(id);
    if (!user) return undefined;
    Object.assign(user, updates);

    this.sqlite.prepare(`
      UPDATE users
      SET username = ?, email = ?, password_hash = ?, display_name = ?, bio = ?, avatar_url = ?, is_online = ?, last_seen = ?
      WHERE id = ?
    `).run(
      user.username,
      user.email,
      user.password_hash,
      user.display_name,
      user.bio,
      user.avatar_url,
      user.is_online ? 1 : 0,
      user.last_seen,
      id
    );
    return user;
  }

  setUserOnlineStatus(id: string, isOnline: boolean): void {
    const now = new Date().toISOString();
    this.sqlite.prepare(`
      UPDATE users SET is_online = ?, last_seen = ? WHERE id = ?
    `).run(isOnline ? 1 : 0, now, id);
  }

  deleteUser(id: string): boolean {
    const user = this.findUserById(id);
    if (!user) return false;
    this.sqlite.transaction(() => {
      this.sqlite.prepare('DELETE FROM sessions WHERE user_id = ?').run(id);
      this.sqlite.prepare('DELETE FROM push_subscriptions WHERE user_id = ?').run(id);
      this.sqlite.prepare('DELETE FROM scheduled_messages WHERE sender_id = ?').run(id);
      this.sqlite.prepare('DELETE FROM read_receipts WHERE user_id = ?').run(id);
      this.sqlite.prepare('DELETE FROM memberships WHERE user_id = ?').run(id);
      this.sqlite.prepare('DELETE FROM messages WHERE sender_id = ?').run(id);
      this.sqlite.prepare('DELETE FROM users WHERE id = ?').run(id);
    })();
    return true;
  }

  // Session operations
  createSession(token: string, userId: string): Session {
    const now = new Date().toISOString();
    const expiresAt = new Date(Date.now() + 1000 * 60 * 60 * 24 * 30).toISOString();
    this.sqlite.prepare(`
      INSERT OR REPLACE INTO sessions (token, user_id, created_at, expires_at)
      VALUES (?, ?, ?, ?)
    `).run(token, userId, now, expiresAt);
    return { token, user_id: userId, created_at: now, expires_at: expiresAt };
  }

  findSession(token: string): Session | undefined {
    const row = this.sqlite.prepare(`
      SELECT * FROM sessions WHERE token = ? AND expires_at > ?
    `).get(token, new Date().toISOString()) as any;
    return row ? { token: row.token, user_id: row.user_id, created_at: row.created_at, expires_at: row.expires_at } : undefined;
  }

  deleteSession(token: string): void {
    this.sqlite.prepare(`DELETE FROM sessions WHERE token = ?`).run(token);
  }

  // Conversation operations
  findConversationById(id: string): Conversation | undefined {
    const row = this.sqlite.prepare(`SELECT * FROM conversations WHERE id = ?`).get(id) as any;
    return row ? this.mapConv(row) : undefined;
  }

  findDirectConversation(userAId: string, userBId: string): Conversation | undefined {
    const row = this.sqlite.prepare(`
      SELECT c.* FROM conversations c
      WHERE c.type = 'direct'
        AND (SELECT COUNT(*) FROM memberships m WHERE m.conversation_id = c.id) = 2
        AND EXISTS (SELECT 1 FROM memberships m WHERE m.conversation_id = c.id AND m.user_id = ?)
        AND EXISTS (SELECT 1 FROM memberships m WHERE m.conversation_id = c.id AND m.user_id = ?)
      LIMIT 1
    `).get(userAId, userBId) as any;
    return row ? this.mapConv(row) : undefined;
  }

  getUserConversations(userId: string) {
    const rows = this.sqlite.prepare(`
      SELECT c.* FROM conversations c
      JOIN memberships m ON c.id = m.conversation_id
      WHERE m.user_id = ?
    `).all(userId) as any[];

    return rows.map(conv => {
      const members = this.getConversationMembers(conv.id);
      const messages = this.getConversationMessages(conv.id);
      const lastMessage = messages.length > 0 ? messages[messages.length - 1] : null;

      const membershipRow = this.sqlite.prepare(`
        SELECT last_read_message_id, is_muted FROM memberships WHERE conversation_id = ? AND user_id = ?
      `).get(conv.id, userId) as any;

      let unreadCount = 0;
      if (membershipRow && messages.length > 0) {
        if (!membershipRow.last_read_message_id) {
          unreadCount = messages.filter(m => m.sender_id !== userId).length;
        } else {
          const lastReadIdx = messages.findIndex(m => m.id === membershipRow.last_read_message_id);
          if (lastReadIdx !== -1) {
            unreadCount = messages.slice(lastReadIdx + 1).filter(m => m.sender_id !== userId).length;
          }
        }
      }

      let directRecipient: Omit<User, 'password_hash'> | null = null;
      if (conv.type === 'direct') {
        const otherMember = members.find(m => m.id !== userId);
        if (otherMember) {
          const fullUser = this.findUserById(otherMember.id);
          if (fullUser) {
            const { password_hash, ...safe } = fullUser;
            directRecipient = safe;
          }
        }
      }

      return {
        ...this.mapConv(conv),
        members,
        last_message: lastMessage,
        unread_count: unreadCount,
        recipient: directRecipient,
        is_muted: Boolean(membershipRow?.is_muted),
      };
    }).sort((a, b) => {
      const timeA = a.last_message ? new Date(a.last_message.created_at).getTime() : new Date(a.created_at).getTime();
      const timeB = b.last_message ? new Date(b.last_message.created_at).getTime() : new Date(b.created_at).getTime();
      return timeB - timeA;
    });
  }

  createConversation(conv: Conversation, initialMembers: { user_id: string; role: 'admin' | 'member' }[]): Conversation {
    const now = new Date().toISOString();
    const tx = this.sqlite.transaction(() => {
      this.sqlite.prepare(`
        INSERT INTO conversations (id, type, title, avatar_url, created_by, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).run(conv.id, conv.type, conv.title, conv.avatar_url || '', conv.created_by, conv.created_at, conv.updated_at);

      const insertMem = this.sqlite.prepare(`
        INSERT OR REPLACE INTO memberships (conversation_id, user_id, role, joined_at, last_read_message_id, is_muted)
        VALUES (?, ?, ?, ?, NULL, 0)
      `);
      for (const m of initialMembers) {
        insertMem.run(conv.id, m.user_id, m.role, now);
      }
    });
    tx();
    return conv;
  }

  // Membership operations
  getConversationMembers(conversationId: string) {
    const rows = this.sqlite.prepare(`
      SELECT m.user_id as id, m.role, m.joined_at, u.username, u.display_name, u.avatar_url, u.is_online, u.last_seen
      FROM memberships m
      LEFT JOIN users u ON m.user_id = u.id
      WHERE m.conversation_id = ?
      ORDER BY m.joined_at ASC
    `).all(conversationId) as any[];

    return rows.map(r => ({
      id: r.id,
      role: r.role as 'admin' | 'member',
      joined_at: r.joined_at,
      username: r.username || 'unknown',
      display_name: r.display_name || 'Unknown',
      avatar_url: r.avatar_url || '',
      is_online: Boolean(r.is_online),
      last_seen: r.last_seen || '',
    }));
  }

  isUserInConversation(conversationId: string, userId: string): boolean {
    const row = this.sqlite.prepare(`
      SELECT 1 FROM memberships WHERE conversation_id = ? AND user_id = ? LIMIT 1
    `).get(conversationId, userId);
    return Boolean(row);
  }

  getUserRoleInConversation(conversationId: string, userId: string): 'admin' | 'member' | null {
    const row = this.sqlite.prepare(`
      SELECT role FROM memberships WHERE conversation_id = ? AND user_id = ? LIMIT 1
    `).get(conversationId, userId) as any;
    return row ? (row.role as 'admin' | 'member') : null;
  }

  addMemberToConversation(conversationId: string, userId: string, role: 'admin' | 'member' = 'member'): boolean {
    if (this.isUserInConversation(conversationId, userId)) return false;
    this.sqlite.prepare(`
      INSERT INTO memberships (conversation_id, user_id, role, joined_at, last_read_message_id, is_muted)
      VALUES (?, ?, ?, ?, NULL, 0)
    `).run(conversationId, userId, role, new Date().toISOString());
    return true;
  }

  removeMemberFromConversation(conversationId: string, userId: string): boolean {
    const info = this.sqlite.prepare(`
      DELETE FROM memberships WHERE conversation_id = ? AND user_id = ?
    `).run(conversationId, userId);
    return info.changes > 0;
  }

  updateLastReadMessage(conversationId: string, userId: string, messageId: string): void {
    this.sqlite.prepare(`
      UPDATE memberships SET last_read_message_id = ? WHERE conversation_id = ? AND user_id = ?
    `).run(messageId, conversationId, userId);
  }

  // Message operations
  getConversationMessages(
    conversationId: string,
    limitOrOptions: number | { limit?: number; before_id?: string; after_id?: string } = 100
  ): (Message & { sender: { id: string; username: string; display_name: string; avatar_url: string }; reply_to?: Message | null; parent_message?: Message | null; client_temp_id?: string | null })[] {
    const limit = typeof limitOrOptions === 'number'
      ? limitOrOptions
      : (limitOrOptions?.limit || 100);
    const beforeId = typeof limitOrOptions === 'object' ? limitOrOptions.before_id : undefined;
    const afterId = typeof limitOrOptions === 'object' ? limitOrOptions.after_id : undefined;

    let rows = this.sqlite.prepare(`
      SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC
    `).all(conversationId) as any[];

    if (beforeId) {
      const idx = rows.findIndex(m => m.id === beforeId);
      if (idx !== -1) {
        rows = rows.slice(0, idx);
      }
    } else if (afterId) {
      const idx = rows.findIndex(m => m.id === afterId);
      if (idx !== -1) {
        rows = rows.slice(idx + 1);
      }
    }

    const rawMessages = rows.slice(-limit);

    return rawMessages.map(msg => {
      const sender = this.findUserById(msg.sender_id);
      const parentId = msg.parent_message_id || msg.reply_to_id;
      let reply_to: Message | null = null;
      if (parentId) {
        reply_to = this.findMessageById(parentId) || null;
      }
      return {
        ...this.mapMessage(msg),
        parent_message_id: parentId,
        parent_message: reply_to,
        sender: {
          id: msg.sender_id,
          username: sender ? sender.username : 'unknown',
          display_name: sender ? sender.display_name : 'Unknown User',
          avatar_url: sender ? sender.avatar_url : '',
        },
        reply_to,
        client_temp_id: msg.client_temp_id || null,
      };
    });
  }

  getConversationMessageStats(conversationId: string): { total: number; oldestId: string | null; newestId: string | null } {
    const stats = this.sqlite.prepare(`
      SELECT 
        COUNT(*) as total,
        (SELECT id FROM messages WHERE conversation_id = ? ORDER BY created_at ASC LIMIT 1) as oldestId,
        (SELECT id FROM messages WHERE conversation_id = ? ORDER BY created_at DESC LIMIT 1) as newestId
      FROM messages WHERE conversation_id = ?
    `).get(conversationId, conversationId, conversationId) as any;

    return {
      total: stats?.total || 0,
      oldestId: stats?.oldestId || null,
      newestId: stats?.newestId || null,
    };
  }

  findMessageById(id: string): Message | undefined {
    const row = this.sqlite.prepare(`SELECT * FROM messages WHERE id = ?`).get(id) as any;
    return row ? this.mapMessage(row) : undefined;
  }

  createMessage(msg: Message): Message {
    const existing = this.findMessageById(msg.id);
    if (existing) {
      return existing;
    }

    // Deduplication Rule 1: Check if identical client_temp_id was already persisted by sender in this conversation
    if (msg.client_temp_id) {
      const existingByTemp = this.sqlite.prepare(`
        SELECT * FROM messages WHERE conversation_id = ? AND sender_id = ? AND client_temp_id = ? LIMIT 1
      `).get(msg.conversation_id, msg.sender_id, msg.client_temp_id) as any;
      if (existingByTemp) {
        return this.mapMessage(existingByTemp);
      }
    }

    // Deduplication Rule 2: Synchronous double-send prevention (exact same sender, conversation, text, and within 3000ms)
    const recent = this.sqlite.prepare(`
      SELECT * FROM messages
      WHERE conversation_id = ? AND sender_id = ? AND text = ?
      ORDER BY created_at DESC LIMIT 1
    `).get(msg.conversation_id, msg.sender_id, msg.text) as any;

    if (recent && Math.abs(new Date(msg.created_at).getTime() - new Date(recent.created_at).getTime()) < 3000) {
      return this.mapMessage(recent);
    }

    const tx = this.sqlite.transaction(() => {
      this.sqlite.prepare(`
        INSERT INTO messages (id, conversation_id, sender_id, text, reply_to_id, parent_message_id, status, is_edited, is_deleted, created_at, updated_at, reactions, audio_url, audio_duration, image_url, client_temp_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        msg.id,
        msg.conversation_id,
        msg.sender_id,
        msg.text,
        msg.reply_to_id || null,
        msg.parent_message_id || msg.reply_to_id || null,
        msg.status || 'sent',
        msg.is_edited ? 1 : 0,
        msg.is_deleted ? 1 : 0,
        msg.created_at,
        msg.updated_at || msg.created_at,
        typeof msg.reactions === 'string' ? msg.reactions : JSON.stringify(msg.reactions || {}),
        msg.audio_url || null,
        typeof msg.audio_duration === 'number' ? msg.audio_duration : null,
        msg.image_url || null,
        msg.client_temp_id || null
      );

      this.sqlite.prepare(`
        UPDATE conversations SET updated_at = ? WHERE id = ?
      `).run(msg.created_at, msg.conversation_id);
    });
    tx();

    return msg;
  }

  updateMessage(id: string, updates: Partial<Message>): Message | undefined {
    const msg = this.findMessageById(id);
    if (!msg) return undefined;
    Object.assign(msg, updates, { updated_at: new Date().toISOString() });

    this.sqlite.prepare(`
      UPDATE messages
      SET text = ?, status = ?, is_edited = ?, is_deleted = ?, updated_at = ?, reactions = ?, audio_url = ?, audio_duration = ?, image_url = ?, client_temp_id = ?
      WHERE id = ?
    `).run(
      msg.text,
      msg.status,
      msg.is_edited ? 1 : 0,
      msg.is_deleted ? 1 : 0,
      msg.updated_at,
      typeof msg.reactions === 'string' ? msg.reactions : JSON.stringify(msg.reactions || {}),
      msg.audio_url || null,
      typeof msg.audio_duration === 'number' ? msg.audio_duration : null,
      msg.image_url || null,
      msg.client_temp_id || null,
      id
    );
    return msg;
  }

  deleteMessage(id: string): boolean {
    const now = new Date().toISOString();
    const info = this.sqlite.prepare(`
      UPDATE messages SET is_deleted = 1, text = 'This message was deleted', updated_at = ? WHERE id = ?
    `).run(now, id);
    return info.changes > 0;
  }

  toggleMessageReaction(messageId: string, userId: string, emoji: string): { reactions: Record<string, string[]>; message?: Message } | null {
    const msg = this.findMessageById(messageId);
    if (!msg || msg.is_deleted) return null;
    if (!msg.reactions) {
      msg.reactions = {};
    }
    const currentUsers = msg.reactions[emoji] || [];
    const index = currentUsers.indexOf(userId);
    if (index > -1) {
      currentUsers.splice(index, 1);
      if (currentUsers.length === 0) {
        delete msg.reactions[emoji];
      } else {
        msg.reactions[emoji] = currentUsers;
      }
    } else {
      msg.reactions[emoji] = [...currentUsers, userId];
    }
    msg.updated_at = new Date().toISOString();

    this.sqlite.prepare(`
      UPDATE messages SET reactions = ?, updated_at = ? WHERE id = ?
    `).run(JSON.stringify(msg.reactions), msg.updated_at, messageId);

    return { reactions: msg.reactions, message: msg };
  }

  recordReadReceipt(messageId: string, userId: string): void {
    const now = new Date().toISOString();
    this.sqlite.prepare(`
      INSERT OR IGNORE INTO read_receipts (message_id, user_id, read_at) VALUES (?, ?, ?)
    `).run(messageId, userId, now);

    this.sqlite.prepare(`
      UPDATE messages SET status = 'read' WHERE id = ? AND status != 'read'
    `).run(messageId);
  }

  markMessagesDeliveredForUser(userId: string): string[] {
    const rows = this.sqlite.prepare(`
      SELECT m.id FROM messages m
      JOIN memberships mem ON m.conversation_id = mem.conversation_id
      WHERE mem.user_id = ? AND m.sender_id != ? AND m.status = 'sent'
    `).all(userId, userId) as any[];

    if (rows.length === 0) return [];
    const ids = rows.map(r => r.id);

    const updateStmt = this.sqlite.prepare(`UPDATE messages SET status = 'delivered' WHERE id = ?`);
    const tx = this.sqlite.transaction(() => {
      for (const id of ids) {
        updateStmt.run(id);
      }
    });
    tx();
    return ids;
  }

  // Scheduled Message operations
  createScheduledMessage(scheduledMsg: ScheduledMessage): ScheduledMessage {
    this.sqlite.prepare(`
      INSERT INTO scheduled_messages (id, conversation_id, sender_id, text, reply_to_id, parent_message_id, scheduled_for, created_at, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      scheduledMsg.id,
      scheduledMsg.conversation_id,
      scheduledMsg.sender_id,
      scheduledMsg.text,
      scheduledMsg.reply_to_id || null,
      scheduledMsg.parent_message_id || scheduledMsg.reply_to_id || null,
      scheduledMsg.scheduled_for,
      scheduledMsg.created_at,
      scheduledMsg.status || 'pending'
    );
    return scheduledMsg;
  }

  getScheduledMessages(conversationId: string, userId: string): ScheduledMessage[] {
    const rows = this.sqlite.prepare(`
      SELECT * FROM scheduled_messages
      WHERE conversation_id = ? AND sender_id = ? AND status = 'pending'
      ORDER BY scheduled_for ASC
    `).all(conversationId, userId) as any[];
    return rows.map(r => this.mapScheduledMsg(r));
  }

  deleteScheduledMessage(id: string, userId: string): boolean {
    const info = this.sqlite.prepare(`
      UPDATE scheduled_messages SET status = 'cancelled' WHERE id = ? AND sender_id = ?
    `).run(id, userId);
    return info.changes > 0;
  }

  getDueScheduledMessages(): ScheduledMessage[] {
    const now = new Date().toISOString();
    const rows = this.sqlite.prepare(`
      SELECT * FROM scheduled_messages WHERE status = 'pending' AND scheduled_for <= ?
    `).all(now) as any[];
    return rows.map(r => this.mapScheduledMsg(r));
  }

  markScheduledMessageSent(id: string): void {
    this.sqlite.prepare(`
      UPDATE scheduled_messages SET status = 'sent' WHERE id = ?
    `).run(id);
  }

  setConversationMuted(conversationId: string, userId: string, isMuted: boolean): boolean {
    const info = this.sqlite.prepare(`
      UPDATE memberships SET is_muted = ? WHERE conversation_id = ? AND user_id = ?
    `).run(isMuted ? 1 : 0, conversationId, userId);
    return info.changes > 0;
  }

  isConversationMutedForUser(conversationId: string, userId: string): boolean {
    const row = this.sqlite.prepare(`
      SELECT is_muted FROM memberships WHERE conversation_id = ? AND user_id = ?
    `).get(conversationId, userId) as any;
    return Boolean(row?.is_muted);
  }

  markConversationAsRead(conversationId: string, userId: string): void {
    const lastMsg = this.sqlite.prepare(`
      SELECT id FROM messages WHERE conversation_id = ? ORDER BY created_at DESC LIMIT 1
    `).get(conversationId) as any;
    if (lastMsg) {
      this.sqlite.prepare(`
        UPDATE memberships SET last_read_message_id = ? WHERE conversation_id = ? AND user_id = ?
      `).run(lastMsg.id, conversationId, userId);
    }
  }

  getOrGenerateVapidKeys(): VapidKeys {
    const row = this.sqlite.prepare(`SELECT * FROM vapid_keys WHERE id = 1`).get() as any;
    if (row) {
      return { publicKey: row.public_key, privateKey: row.private_key };
    }
    const generated = webpush.generateVAPIDKeys();
    this.sqlite.prepare(`
      INSERT OR REPLACE INTO vapid_keys (id, public_key, private_key) VALUES (1, ?, ?)
    `).run(generated.publicKey, generated.privateKey);
    return generated;
  }

  savePushSubscription(userId: string, subscription: any, userAgent?: string): PushSubscriptionRecord {
    this.deletePushSubscription(subscription.endpoint);
    const rec: PushSubscriptionRecord = {
      id: `sub_${crypto.randomBytes(6).toString('hex')}`,
      user_id: userId,
      endpoint: subscription.endpoint,
      keys: {
        p256dh: subscription.keys.p256dh,
        auth: subscription.keys.auth,
      },
      created_at: new Date().toISOString(),
      user_agent: userAgent,
    };
    this.sqlite.prepare(`
      INSERT INTO push_subscriptions (id, user_id, endpoint, p256dh, auth, created_at, user_agent)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(
      rec.id,
      rec.user_id,
      rec.endpoint,
      rec.keys.p256dh,
      rec.keys.auth,
      rec.created_at,
      rec.user_agent || null
    );
    return rec;
  }

  deletePushSubscription(endpoint: string): void {
    this.sqlite.prepare(`DELETE FROM push_subscriptions WHERE endpoint = ?`).run(endpoint);
  }

  getUserPushSubscriptions(userId: string): PushSubscriptionRecord[] {
    const rows = this.sqlite.prepare(`
      SELECT * FROM push_subscriptions WHERE user_id = ?
    `).all(userId) as any[];
    return rows.map(r => ({
      id: r.id,
      user_id: r.user_id,
      endpoint: r.endpoint,
      keys: {
        p256dh: r.p256dh,
        auth: r.auth,
      },
      created_at: r.created_at,
      user_agent: r.user_agent || undefined,
    }));
  }

  // --- Device Tokens Management (FCM / Native & Web Multi-Device) ---
  registerDeviceToken(userId: string, token: string, deviceType: 'web' | 'android' | 'ios' | 'desktop' = 'web'): DeviceTokenRecord {
    const now = new Date().toISOString();
    const id = `dt_${crypto.randomBytes(6).toString('hex')}`;
    this.sqlite.prepare(`
      INSERT INTO device_tokens (id, user_id, device_token, device_type, created_at, updated_at, is_active)
      VALUES (?, ?, ?, ?, ?, ?, 1)
      ON CONFLICT(device_token) DO UPDATE SET
        user_id = excluded.user_id,
        device_type = excluded.device_type,
        updated_at = excluded.updated_at,
        is_active = 1
    `).run(id, userId, token, deviceType, now, now);

    const row = this.sqlite.prepare(`SELECT * FROM device_tokens WHERE device_token = ?`).get(token) as any;
    return {
      id: row.id,
      user_id: row.user_id,
      device_token: row.device_token,
      device_type: row.device_type,
      created_at: row.created_at,
      updated_at: row.updated_at,
      is_active: Boolean(row.is_active),
    };
  }

  unregisterDeviceToken(token: string): void {
    this.sqlite.prepare(`DELETE FROM device_tokens WHERE device_token = ?`).run(token);
  }

  getUserDeviceTokens(userId: string): DeviceTokenRecord[] {
    const rows = this.sqlite.prepare(`
      SELECT * FROM device_tokens WHERE user_id = ? AND is_active = 1 ORDER BY updated_at DESC
    `).all(userId) as any[];
    return rows.map(r => ({
      id: r.id,
      user_id: r.user_id,
      device_token: r.device_token,
      device_type: r.device_type,
      created_at: r.created_at,
      updated_at: r.updated_at,
      is_active: Boolean(r.is_active),
    }));
  }

  deleteUserDeviceTokens(userId: string): void {
    this.sqlite.prepare(`DELETE FROM device_tokens WHERE user_id = ?`).run(userId);
  }

  // --- Notifications History Management ---
  createNotification(record: {
    id?: string;
    recipient_id: string;
    sender_id?: string | null;
    conversation_id?: string | null;
    message_id?: string | null;
    notification_type?: 'message' | 'missed' | 'group' | 'mention' | 'system';
    title: string;
    body: string;
  }): NotificationRecord {
    const now = new Date().toISOString();
    const notifId = record.id || `notif_${crypto.randomBytes(8).toString('hex')}`;
    const type = record.notification_type || 'message';

    this.sqlite.prepare(`
      INSERT INTO notifications (
        notification_id, recipient_id, sender_id, conversation_id, message_id,
        notification_type, title, body, is_read, created_at
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
    `).run(
      notifId,
      record.recipient_id,
      record.sender_id || null,
      record.conversation_id || null,
      record.message_id || null,
      type,
      record.title,
      record.body,
      now
    );

    return {
      notification_id: notifId,
      recipient_id: record.recipient_id,
      sender_id: record.sender_id || null,
      conversation_id: record.conversation_id || null,
      message_id: record.message_id || null,
      notification_type: type,
      title: record.title,
      body: record.body,
      is_read: false,
      created_at: now,
    };
  }

  getUserNotifications(userId: string, limit = 50, onlyUnread = false): NotificationRecord[] {
    const sql = onlyUnread
      ? `SELECT * FROM notifications WHERE recipient_id = ? AND is_read = 0 ORDER BY created_at DESC LIMIT ?`
      : `SELECT * FROM notifications WHERE recipient_id = ? ORDER BY created_at DESC LIMIT ?`;
    const rows = this.sqlite.prepare(sql).all(userId, limit) as any[];
    return rows.map(r => ({
      notification_id: r.notification_id,
      recipient_id: r.recipient_id,
      sender_id: r.sender_id,
      conversation_id: r.conversation_id,
      message_id: r.message_id,
      notification_type: r.notification_type,
      title: r.title,
      body: r.body,
      is_read: Boolean(r.is_read),
      created_at: r.created_at,
    }));
  }

  markNotificationAsRead(notificationId: string, userId: string): boolean {
    const result = this.sqlite.prepare(`
      UPDATE notifications SET is_read = 1 WHERE notification_id = ? AND recipient_id = ?
    `).run(notificationId, userId);
    return result.changes > 0;
  }

  markAllNotificationsAsRead(userId: string): void {
    this.sqlite.prepare(`
      UPDATE notifications SET is_read = 1 WHERE recipient_id = ? AND is_read = 0
    `).run(userId);
  }

  deleteNotification(notificationId: string, userId: string): boolean {
    const result = this.sqlite.prepare(`
      DELETE FROM notifications WHERE notification_id = ? AND recipient_id = ?
    `).run(notificationId, userId);
    return result.changes > 0;
  }

  // --- User Notification Settings ---
  getUserNotificationSettings(userId: string): UserNotificationSettings {
    const row = this.sqlite.prepare(`
      SELECT * FROM user_notification_settings WHERE user_id = ?
    `).get(userId) as any;

    if (row) {
      return {
        user_id: row.user_id,
        push_enabled: Boolean(row.push_enabled),
        sound_enabled: Boolean(row.sound_enabled),
        vibration_enabled: Boolean(row.vibration_enabled),
        show_preview: Boolean(row.show_preview),
        updated_at: row.updated_at,
      };
    }

    // Default settings
    const now = new Date().toISOString();
    this.sqlite.prepare(`
      INSERT OR IGNORE INTO user_notification_settings (user_id, push_enabled, sound_enabled, vibration_enabled, show_preview, updated_at)
      VALUES (?, 1, 1, 1, 1, ?)
    `).run(userId, now);

    return {
      user_id: userId,
      push_enabled: true,
      sound_enabled: true,
      vibration_enabled: true,
      show_preview: true,
      updated_at: now,
    };
  }

  updateUserNotificationSettings(
    userId: string,
    settings: Partial<Omit<UserNotificationSettings, 'user_id' | 'updated_at'>>
  ): UserNotificationSettings {
    const current = this.getUserNotificationSettings(userId);
    const updated: UserNotificationSettings = {
      user_id: userId,
      push_enabled: settings.push_enabled !== undefined ? Boolean(settings.push_enabled) : current.push_enabled,
      sound_enabled: settings.sound_enabled !== undefined ? Boolean(settings.sound_enabled) : current.sound_enabled,
      vibration_enabled: settings.vibration_enabled !== undefined ? Boolean(settings.vibration_enabled) : current.vibration_enabled,
      show_preview: settings.show_preview !== undefined ? Boolean(settings.show_preview) : current.show_preview,
      updated_at: new Date().toISOString(),
    };

    this.sqlite.prepare(`
      INSERT INTO user_notification_settings (user_id, push_enabled, sound_enabled, vibration_enabled, show_preview, updated_at)
      VALUES (?, ?, ?, ?, ?, ?)
      ON CONFLICT(user_id) DO UPDATE SET
        push_enabled = excluded.push_enabled,
        sound_enabled = excluded.sound_enabled,
        vibration_enabled = excluded.vibration_enabled,
        show_preview = excluded.show_preview,
        updated_at = excluded.updated_at
    `).run(
      updated.user_id,
      updated.push_enabled ? 1 : 0,
      updated.sound_enabled ? 1 : 0,
      updated.vibration_enabled ? 1 : 0,
      updated.show_preview ? 1 : 0,
      updated.updated_at
    );

    return updated;
  }

  deleteAllExistingAccounts(): void {
    if (process.env.NODE_ENV === 'production') {
      console.warn('Database wipe attempt blocked in production.');
      return;
    }
    this.seedDefaultData();
  }
}

export const db = new SQLiteDatabase();
