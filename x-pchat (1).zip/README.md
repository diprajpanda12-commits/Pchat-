# PChat — Panda Chat (Real-Time Messaging Website + Android PWA)

PChat is a full-featured real-time messaging platform inspired by Telegram and Messenger, built with WebSockets, persistent database storage, Django REST Framework compatibility, and installable Android PWA support.

---

## 🚀 Key Features

1. **True Real-Time WebSocket Messaging**
   - Instant message transmission between multiple online users without page reloads.
   - Dedicated authenticated WebSocket endpoints: `/ws/chat/<conversation_id>/` and `/ws/general/`.
   - Idempotent event handlers prevent duplicate message displays when clients receive confirmation broadcasts.

2. **Full Message Lifecycle & Receipts**
   - **Pending** ➔ Message queued or transmitting
   - **Sent** (Single tick) ➔ Saved to database on server
   - **Delivered** (Double grey ticks) ➔ Acknowledged by recipient's active client
   - **Read** (Double blue ticks) ➔ Read receipt recorded with timestamp

3. **Personal & Group Conversations**
   - Username live search to start direct 1-to-1 chats.
   - Create multi-user group chats with custom title, avatar, and admin roles.
   - Add/remove members, leave group, and delete group messages.
   - Quote replies, live message editing, message deletion.

4. **Android PWA & Offline Support**
   - Compliant Web App Manifest (`id`, `standalone` display, `maskable` & standard 192px/512px icons).
   - In-app install button (`PWAInstallButton`) for Android and Desktop Chrome.
   - Guided iOS Safari home screen instructions.
   - Offline detection banner and service worker caching.

5. **Multi-Language UI**
   - Complete Bengali (বাংলা) and English language toggle for all screens and settings.

6. **Interactive Test Runner**
   - Built-in 13-step automated test suite executable with one click directly inside the web UI.

---

## 👥 Demo Pre-Seeded Accounts

| Name | Username | Password | Bio |
|------|----------|----------|-----|
| **Alice Panda 🐼** | `panda_alice` | `Panda@123` | Loves bamboo and real-time chatting on PChat! |
| **Bob Panda 🎋** | `panda_bob` | `Panda@123` | Mobile software engineer and Django developer. |
| **Charlie Bamboo 🐾** | `panda_charlie` | `Panda@123` | Panda community moderator. |

*You can also register any number of new unique accounts!*

---

## 💾 Persistent Storage & SQLite Database

PChat uses a robust **SQLite database (`better-sqlite3`)** configured in **Write-Ahead Logging (WAL)** mode for lightning-fast concurrent reads and writes, durability, and reliable real-time messaging without data loss.

### Production Persistence Note (`DATA_DIR`)
- By default, the SQLite database (`pchat.db`) and automated backups are located in the directory specified by the `DATA_DIR` environment variable (defaults to `./data`).
- **CRITICAL FOR PRODUCTION**: When deploying PChat to containerized platforms with ephemeral filesystems (such as Google Cloud Run, AI Studio, Docker, Kubernetes, AWS ECS, or Replit), **`DATA_DIR` MUST be mapped to a persistent volume or persistent disk mount** (e.g. `/mnt/pchat_data` or a mounted Cloud Storage / NFS volume).
  ```bash
  # Example: Point DATA_DIR to a mounted persistent volume
  export DATA_DIR=/mnt/pchat_data
  npm start
  ```
- Any legacy JSON data (`data/pchat_db.json`) is automatically and safely migrated into SQLite on first startup, ensuring zero data loss.
- Periodic and on-demand SQLite online backups are saved directly to `$DATA_DIR` via `db.createBackup()`.

---

## 📥 Export Chat History

Users can download and backup their conversation history anytime directly from the UI:
- **Formats Supported**:
  - **Text Transcript (`.txt`)**: Clean, formatted, human-readable transcript with message timestamps, sender names, reactions, and voice notes.
  - **Structured Data (`.json`)**: Machine-readable JSON export containing complete message metadata, participants, IDs, and timestamps.
- **Accessible From**:
  - **Chat Header**: Click the Download icon (📥) at the top right of the conversation.
  - **Sidebar**: Click "Export" next to your profile in the bottom workspace bar when a chat is open.
  - **REST API Endpoint**: `GET /api/conversations/:id/export/?format=txt|json` (authenticated).

---

## 🛠️ Architecture & Deployment

### Development Server (Node.js Express + WebSockets + Vite)
The application runs on Port 3000:
```bash
npm run dev
```

### Production Server
Build client bundle and start server with Node/TSX:
```bash
npm run build
npm start
```

### Django + Daphne ASGI Backend
The Django implementation is located in `/django_backend/`:
```bash
cd django_backend
pip install -r ../requirements.txt
python manage.py migrate
daphne -b 0.0.0.0 -p 8000 pchat_project.asgi:application
```
