import express from 'express';
import { createServer } from 'http';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { apiRouter } from './server/routes.js';
import crypto from 'crypto';
import { db } from './server/db.js';
import { broadcastToConversation, broadcastToUser, initWebSocketServer } from './server/ws.js';
import { sendPushForNewMessage } from './server/push.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = process.env.DATA_DIR || path.resolve(__dirname, 'data');
const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  const PORT = parseInt(process.env.PORT || '3000', 10);

  // Body and cookie parsing middleware
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));
  app.use((req, _res, next) => {
    const cookieHeader = req.headers.cookie;
    const cookies: Record<string, string> = {};
    if (cookieHeader) {
      cookieHeader.split(';').forEach(pair => {
        const [k, ...v] = pair.trim().split('=');
        if (k) cookies[k] = decodeURIComponent(v.join('='));
      });
    }
    (req as any).cookies = cookies;
    next();
  });

  // Serve static uploaded media files
  app.use('/uploads', express.static(UPLOADS_DIR));

  // REST API routes
  app.use('/api', apiRouter);

  // Initialize WebSocket server attached to HTTP server
  initWebSocketServer(server);

  // Background Scheduled Messages Dispatcher (checks every 3 seconds)
  setInterval(() => {
    try {
      const dueMessages = db.getDueScheduledMessages();
      for (const sm of dueMessages) {
        const now = new Date().toISOString();
        const parentId = sm.parent_message_id || sm.reply_to_id || null;
        const newMsg = db.createMessage({
          id: `msg_${crypto.randomBytes(8).toString('hex')}`,
          conversation_id: sm.conversation_id,
          sender_id: sm.sender_id,
          text: sm.text,
          reply_to_id: parentId,
          parent_message_id: parentId,
          status: 'sent',
          is_edited: false,
          is_deleted: false,
          created_at: now,
          updated_at: now,
          reactions: {},
        });

        db.markScheduledMessageSent(sm.id);

        const sender = db.findUserById(sm.sender_id);
        const parentMsg = parentId ? db.findMessageById(parentId) : null;
        const fullMsg = {
          ...newMsg,
          parent_message_id: parentId,
          parent_message: parentMsg,
          sender: sender ? {
            id: sender.id,
            username: sender.username,
            display_name: sender.display_name,
            avatar_url: sender.avatar_url,
          } : undefined,
          reply_to: parentMsg,
        };

        // Broadcast new message to conversation room
        broadcastToConversation(sm.conversation_id, {
          type: 'message:new',
          message: fullMsg,
          conversation_id: sm.conversation_id,
        });

        // Trigger web push for scheduled message arrival
        sendPushForNewMessage(
          sm.conversation_id,
          sm.sender_id,
          newMsg,
          sender ? sender.display_name : 'PChat User'
        ).catch((err) => {
          console.warn('Scheduled push dispatch note:', err);
        });

        // Notify sender user
        broadcastToUser(sm.sender_id, {
          type: 'scheduled:dispatched',
          scheduled_id: sm.id,
          conversation_id: sm.conversation_id,
          message: fullMsg,
        });
      }
    } catch (err) {
      console.error('Error dispatching scheduled messages:', err);
    }
  }, 3000);

  // In production or development:
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files from dist in production
    app.use(express.static(path.resolve(__dirname, 'dist')));
    // Return 404 for missing static assets rather than index.html
    app.get('/assets/*', (_req, res) => {
      res.status(404).send('Asset not found');
    });
    app.get('*', (_req, res) => {
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`🐼 PChat (Panda Chat) Server running at http://0.0.0.0:${PORT}`);
    console.log(`🎋 WebSocket endpoint listening at ws://0.0.0.0:${PORT}/ws/chat/<conv_id> and /ws/general`);
  });
}

startServer().catch(err => {
  console.error('Failed to start PChat server:', err);
  process.exit(1);
});
