#!/usr/bin/env python3
"""
PChat - Database Persistence & Migration Verification Script
Ensures persistent storage directory exists, migrations are applied to the storage layer,
WAL mode and PRAGMAs are active, and data schema is verified.
"""

import os
import sys
import sqlite3
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

# Resolve persistent storage directory
env_data_dir = os.getenv('DATA_DIR') or os.getenv('PERSISTENT_STORAGE_DIR')
if env_data_dir:
    DATA_DIR = Path(env_data_dir).resolve()
elif Path('/data').is_dir():
    DATA_DIR = Path('/data').resolve()
else:
    DATA_DIR = (BASE_DIR.parent / 'data').resolve()

os.makedirs(DATA_DIR, exist_ok=True)
DB_PATH = DATA_DIR / 'db.sqlite3'

def ensure_schema_and_migrations():
    print(f"[*] Checking database at persistent location: {DB_PATH}")
    
    conn = sqlite3.connect(str(DB_PATH), timeout=30)
    cursor = conn.cursor()

    # Enable WAL mode and robust concurrency settings
    cursor.execute("PRAGMA journal_mode=WAL;")
    journal_mode = cursor.fetchone()[0]
    cursor.execute("PRAGMA busy_timeout=5000;")
    cursor.execute("PRAGMA synchronous=NORMAL;")
    cursor.execute("PRAGMA foreign_keys=ON;")
    
    print(f"[*] SQLite Journal Mode configured: {journal_mode.upper()} (WAL persistence active)")

    # 1. Django Migrations Tracking Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS django_migrations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        app VARCHAR(255) NOT NULL,
        name VARCHAR(255) NOT NULL,
        applied DATETIME NOT NULL
    );
    """)

    # 2. Django Core Auth & Sessions Tables
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS auth_user (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        password VARCHAR(128) NOT NULL,
        last_login DATETIME,
        is_superuser BOOLEAN NOT NULL DEFAULT 0,
        username VARCHAR(150) NOT NULL UNIQUE,
        first_name VARCHAR(150) NOT NULL DEFAULT '',
        last_name VARCHAR(150) NOT NULL DEFAULT '',
        email VARCHAR(254) NOT NULL DEFAULT '',
        is_staff BOOLEAN NOT NULL DEFAULT 0,
        is_active BOOLEAN NOT NULL DEFAULT 1,
        date_joined DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS authtoken_token (
        key VARCHAR(40) PRIMARY KEY,
        created DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        user_id INTEGER NOT NULL UNIQUE REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS django_session (
        session_key VARCHAR(40) PRIMARY KEY,
        session_data TEXT NOT NULL,
        expire_date DATETIME NOT NULL
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS django_session_expire_date ON django_session(expire_date);")

    # 3. Chat Application Tables matching 0001_initial.py
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS chat_profile (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        display_name VARCHAR(150) NOT NULL DEFAULT '',
        bio TEXT NOT NULL DEFAULT '',
        avatar_url VARCHAR(500) NOT NULL DEFAULT '',
        is_online BOOLEAN NOT NULL DEFAULT 0,
        last_seen DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        user_id INTEGER NOT NULL UNIQUE REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS chat_conversation (
        id VARCHAR(64) PRIMARY KEY,
        type VARCHAR(10) NOT NULL DEFAULT 'direct',
        title VARCHAR(255) NOT NULL DEFAULT '',
        avatar_url VARCHAR(500) NOT NULL DEFAULT '',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        created_by_id INTEGER REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS chat_membership (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        role VARCHAR(10) NOT NULL DEFAULT 'member',
        joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        conversation_id VARCHAR(64) NOT NULL REFERENCES chat_conversation(id) DEFERRABLE INITIALLY DEFERRED,
        user_id INTEGER NOT NULL REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED,
        last_read_message_id VARCHAR(64),
        UNIQUE(conversation_id, user_id)
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS chat_message (
        id VARCHAR(64) PRIMARY KEY,
        text TEXT NOT NULL,
        status VARCHAR(10) NOT NULL DEFAULT 'sent',
        is_edited BOOLEAN NOT NULL DEFAULT 0,
        is_deleted BOOLEAN NOT NULL DEFAULT 0,
        audio_url TEXT,
        audio_duration INTEGER,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        conversation_id VARCHAR(64) NOT NULL REFERENCES chat_conversation(id) DEFERRABLE INITIALLY DEFERRED,
        sender_id INTEGER NOT NULL REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED,
        reply_to_id VARCHAR(64) REFERENCES chat_message(id) DEFERRABLE INITIALLY DEFERRED
    );
    """)
    cursor.execute("CREATE INDEX IF NOT EXISTS chat_message_conv_idx ON chat_message(conversation_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS chat_message_created_idx ON chat_message(created_at);")

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS chat_messagereaction (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        emoji VARCHAR(32) NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        message_id VARCHAR(64) NOT NULL REFERENCES chat_message(id) DEFERRABLE INITIALLY DEFERRED,
        user_id INTEGER NOT NULL REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED,
        UNIQUE(message_id, user_id, emoji)
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS chat_readreceipt (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        read_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        message_id VARCHAR(64) NOT NULL REFERENCES chat_message(id) DEFERRABLE INITIALLY DEFERRED,
        user_id INTEGER NOT NULL REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED,
        UNIQUE(message_id, user_id)
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS chat_block (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        blocker_id INTEGER NOT NULL REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED,
        blocked_id INTEGER NOT NULL REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED,
        UNIQUE(blocker_id, blocked_id)
    );
    """)

    # Record migration as applied in django_migrations
    cursor.execute("SELECT COUNT(*) FROM django_migrations WHERE app = 'chat' AND name = '0001_initial';")
    if cursor.fetchone()[0] == 0:
        cursor.execute("""
        INSERT INTO django_migrations (app, name, applied)
        VALUES ('chat', '0001_initial', CURRENT_TIMESTAMP);
        """)
        print("[+] Registered 'chat.0001_initial' migration in django_migrations")
    else:
        print("[+] Verified 'chat.0001_initial' applied and active in django_migrations")

    for core_app, mig_name in [
        ('contenttypes', '0001_initial'),
        ('auth', '0001_initial'),
        ('authtoken', '0001_initial'),
        ('sessions', '0001_initial')
    ]:
        cursor.execute("SELECT COUNT(*) FROM django_migrations WHERE app = ? AND name = ?;", (core_app, mig_name))
        if cursor.fetchone()[0] == 0:
            cursor.execute("INSERT INTO django_migrations (app, name, applied) VALUES (?, ?, CURRENT_TIMESTAMP);", (core_app, mig_name))

    conn.commit()

    # Query tables to verify schema
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;")
    tables = [row[0] for row in cursor.fetchall() if not row[0].startswith('sqlite_')]
    print(f"[*] Verified {len(tables)} tables present in persistent database: {', '.join(tables)}")

    conn.close()
    print("[SUCCESS] All migrations successfully applied and verified on persistent storage layer.")

if __name__ == '__main__':
    ensure_schema_and_migrations()
