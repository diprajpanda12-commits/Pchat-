from rest_framework.authentication import TokenAuthentication

class FlexibleTokenAuthentication(TokenAuthentication):
    """
    Accepts both 'Token <key>' and 'Bearer <key>' schemes
    for seamless interoperability between React/TypeScript and Django REST Framework.
    """
    keyword = 'Token'

    def authenticate(self, request):
        auth_header = request.headers.get('Authorization') or request.META.get('HTTP_AUTHORIZATION', '')
        if not auth_header:
            return None

        parts = auth_header.split()
        if len(parts) == 2 and parts[0].lower() in ('token', 'bearer'):
            token_key = parts[1]
            return self.authenticate_credentials(token_key)

        return super().authenticate(request)
