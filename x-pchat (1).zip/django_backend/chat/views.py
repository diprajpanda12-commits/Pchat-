from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404
from rest_framework import status, views, permissions
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer

from .models import Profile, Conversation, Membership, Message, MessageReaction, ReadReceipt
from .serializers import ConversationSerializer, MessageSerializer, UserSummarySerializer

channel_layer = get_channel_layer()

def broadcast_to_group(group_name, payload):
    if channel_layer:
        try:
            async_to_sync(channel_layer.group_send)(
                group_name,
                {
                    "type": "chat_message",
                    "payload": payload,
                }
            )
        except Exception as e:
            print(f"Channels broadcast error: {e}")

class RegisterView(views.APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        username = request.data.get('username', '').strip()
        email = request.data.get('email', '').strip().lower()
        password = request.data.get('password')
        display_name = request.data.get('display_name', '').strip()

        if not username or not email or not password:
            return Response({'error': 'Username, email, and password are required.'}, status=status.HTTP_400_BAD_REQUEST)

        if len(username) < 3 or len(username) > 30:
            return Response({'error': 'Username must be between 3 and 30 characters.'}, status=status.HTTP_400_BAD_REQUEST)

        if User.objects.filter(username__iexact=username).exists():
            return Response({'error': 'Username is already taken.'}, status=status.HTTP_400_BAD_REQUEST)

        if User.objects.filter(email__iexact=email).exists():
            return Response({'error': 'Email is already registered.'}, status=status.HTTP_400_BAD_REQUEST)

        user = User.objects.create_user(username=username, email=email, password=password)
        Profile.objects.create(
            user=user,
            display_name=display_name or username,
            bio='New PChat member 🐼',
            avatar_url=f'https://api.dicebear.com/7.x/bottts/svg?seed={username}'
        )

        token, _ = Token.objects.get_or_create(user=user)
        return Response({
            'token': token.key,
            'user': UserSummarySerializer(user).data,
            'message': 'Registration successful!'
        }, status=status.HTTP_201_CREATED)

class LoginView(views.APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        username = request.data.get('username', '').strip()
        password = request.data.get('password')

        if not username or not password:
            return Response({'error': 'Username and password are required.'}, status=status.HTTP_400_BAD_REQUEST)

        user = authenticate(username=username, password=password)
        if not user:
            # Try login via email
            try:
                user_obj = User.objects.get(email__iexact=username)
                user = authenticate(username=user_obj.username, password=password)
            except User.DoesNotExist:
                user = None

        if not user:
            return Response({'error': 'Invalid username/email or password.'}, status=status.HTTP_401_UNAUTHORIZED)

        if hasattr(user, 'profile'):
            user.profile.is_online = True
            user.profile.save()

        token, _ = Token.objects.get_or_create(user=user)
        return Response({
            'token': token.key,
            'user': UserSummarySerializer(user).data,
            'message': 'Login successful!'
        })

class LogoutView(views.APIView):
    def post(self, request):
        if hasattr(request.user, 'profile'):
            request.user.profile.is_online = False
            request.user.profile.save()
        Token.objects.filter(user=request.user).delete()
        return Response({'message': 'Logged out successfully.'})

class MeView(views.APIView):
    def get(self, request):
        return Response({'user': UserSummarySerializer(request.user).data})

class UserSearchView(views.APIView):
    def get(self, request):
        query = request.query_params.get('q', '').strip()
        users = User.objects.exclude(id=request.user.id)
        if query:
            users = users.filter(username__icontains=query) | users.filter(profile__display_name__icontains=query)
        serializer = UserSummarySerializer(users[:25], many=True)
        return Response({'users': serializer.data})

class ProfileUpdateView(views.APIView):
    def patch(self, request):
        profile = request.user.profile
        display_name = request.data.get('display_name')
        bio = request.data.get('bio')
        avatar_url = request.data.get('avatar_url')
        current_password = request.data.get('current_password')
        new_password = request.data.get('new_password')

        if current_password and new_password:
            if not request.user.check_password(current_password):
                return Response({'error': 'Current password is incorrect.'}, status=status.HTTP_400_BAD_REQUEST)
            if len(new_password) < 6:
                return Response({'error': 'New password must be at least 6 characters.'}, status=status.HTTP_400_BAD_REQUEST)
            request.user.set_password(new_password)
            request.user.save()

        if display_name:
            profile.display_name = display_name.strip()
        if bio is not None:
            profile.bio = bio.strip()
        if avatar_url:
            profile.avatar_url = avatar_url.strip()
        profile.save()

        return Response({'user': UserSummarySerializer(request.user).data, 'message': 'Profile updated successfully.'})

class ConversationListCreateView(views.APIView):
    def get(self, request):
        convs = Conversation.objects.filter(memberships__user=request.user)
        serializer = ConversationSerializer(convs, many=True, context={'request': request})
        return Response({'conversations': serializer.data})

    def post(self, request):
        user = request.user
        conv_type = request.data.get('type', 'direct')

        if conv_type == 'direct':
            recipient_id = request.data.get('recipient_id')
            if not recipient_id:
                return Response({'error': 'recipient_id is required.'}, status=status.HTTP_400_BAD_REQUEST)

            recipient = get_object_or_404(User, id=recipient_id)
            if recipient.id == user.id:
                return Response({'error': 'Cannot start a conversation with yourself.'}, status=status.HTTP_400_BAD_REQUEST)

            # Check if direct conversation already exists
            existing = Conversation.objects.filter(
                type='direct',
                memberships__user=user
            ).filter(
                memberships__user=recipient
            ).first()

            if existing:
                serializer = ConversationSerializer(existing, context={'request': request})
                return Response({'conversation': serializer.data, 'is_existing': True})

            conv = Conversation.objects.create(type='direct', created_by=user)
            Membership.objects.create(conversation=conv, user=user, role='member')
            Membership.objects.create(conversation=conv, user=recipient, role='member')

            serializer = ConversationSerializer(conv, context={'request': request})
            return Response({'conversation': serializer.data, 'is_existing': False}, status=status.HTTP_201_CREATED)

        elif conv_type == 'group':
            title = request.data.get('title', '').strip()
            avatar_url = request.data.get('avatar_url', '').strip() or '/pchat-logo.png'
            member_ids = request.data.get('member_ids', [])

            if not title:
                return Response({'error': 'Title required for group.'}, status=status.HTTP_400_BAD_REQUEST)

            conv = Conversation.objects.create(type='group', title=title, avatar_url=avatar_url, created_by=user)
            Membership.objects.create(conversation=conv, user=user, role='admin')

            for uid in member_ids:
                if str(uid) != str(user.id):
                    try:
                        u = User.objects.get(id=uid)
                        Membership.objects.create(conversation=conv, user=u, role='member')
                    except (User.DoesNotExist, ValueError):
                        pass

            serializer = ConversationSerializer(conv, context={'request': request})
            return Response({'conversation': serializer.data}, status=status.HTTP_201_CREATED)

        return Response({'error': 'Invalid conversation type.'}, status=status.HTTP_400_BAD_REQUEST)

class ConversationDetailView(views.APIView):
    def get(self, request, pk):
        conv = get_object_or_404(Conversation, id=pk)
        if not conv.memberships.filter(user=request.user).exists():
            return Response({'error': 'Forbidden.'}, status=status.HTTP_403_FORBIDDEN)
        serializer = ConversationSerializer(conv, context={'request': request})
        return Response({'conversation': serializer.data})

class ConversationMembersView(views.APIView):
    def post(self, request, pk):
        conv = get_object_or_404(Conversation, id=pk)
        if not conv.memberships.filter(user=request.user, role='admin').exists():
            return Response({'error': 'Only admins can add members.'}, status=status.HTTP_403_FORBIDDEN)

        user_id = request.data.get('user_id')
        target_user = get_object_or_404(User, id=user_id)
        if conv.memberships.filter(user=target_user).exists():
            return Response({'error': 'User is already a member.'}, status=status.HTTP_400_BAD_REQUEST)

        Membership.objects.create(conversation=conv, user=target_user, role='member')
        serializer = ConversationSerializer(conv, context={'request': request})
        return Response({'message': 'Member added.', 'conversation': serializer.data})

    def delete(self, request, pk, user_id):
        conv = get_object_or_404(Conversation, id=pk)
        membership = conv.memberships.filter(user=request.user).first()
        if not membership:
            return Response({'error': 'Forbidden.'}, status=status.HTTP_403_FORBIDDEN)

        is_self = str(request.user.id) == str(user_id)
        if not is_self and membership.role != 'admin':
            return Response({'error': 'Only admins can remove other members.'}, status=status.HTTP_403_FORBIDDEN)

        target_membership = conv.memberships.filter(user_id=user_id).first()
        if target_membership:
            target_membership.delete()

        serializer = ConversationSerializer(conv, context={'request': request})
        return Response({'message': 'Member removed.', 'conversation': serializer.data})

class MessageListCreateView(views.APIView):
    def get(self, request, conversation_id):
        conv = get_object_or_404(Conversation, id=conversation_id)
        if not conv.memberships.filter(user=request.user).exists():
            return Response({'error': 'Forbidden.'}, status=status.HTTP_403_FORBIDDEN)

        messages_list = list(conv.messages.all()[:150])
        if messages_list:
            last_msg = messages_list[-1]
            membership = conv.memberships.filter(user=request.user).first()
            if membership:
                membership.last_read_message = last_msg
                membership.save()

        serializer = MessageSerializer(messages_list, many=True)
        return Response({'messages': serializer.data})

    def post(self, request, conversation_id):
        conv = get_object_or_404(Conversation, id=conversation_id)
        if not conv.memberships.filter(user=request.user).exists():
            return Response({'error': 'Forbidden.'}, status=status.HTTP_403_FORBIDDEN)

        text = request.data.get('text', '').strip()
        reply_to_id = request.data.get('reply_to_id')
        audio_url = request.data.get('audio_url')
        audio_duration = request.data.get('audio_duration')

        effective_text = text or ('🎤 Voice message' if audio_url else '')
        if not effective_text:
            return Response({'error': 'Message text or audio required.'}, status=status.HTTP_400_BAD_REQUEST)

        msg = Message.objects.create(
            conversation=conv,
            sender=request.user,
            text=effective_text,
            reply_to_id=reply_to_id,
            audio_url=audio_url,
            audio_duration=audio_duration,
            status='sent'
        )

        serializer = MessageSerializer(msg)
        broadcast_to_group(f"chat_{conv.id}", {
            "type": "message:new",
            "message": serializer.data,
            "conversation_id": conv.id
        })

        return Response({'message': serializer.data}, status=status.HTTP_201_CREATED)

class MessageReactionView(views.APIView):
    def post(self, request, pk):
        msg = get_object_or_404(Message, id=pk)
        if not msg.conversation.memberships.filter(user=request.user).exists():
            return Response({'error': 'Forbidden.'}, status=status.HTTP_403_FORBIDDEN)

        emoji = request.data.get('emoji', '').strip()
        if not emoji:
            return Response({'error': 'Emoji required.'}, status=status.HTTP_400_BAD_REQUEST)

        existing = MessageReaction.objects.filter(message=msg, user=request.user, emoji=emoji).first()
        if existing:
            existing.delete()
        else:
            MessageReaction.objects.create(message=msg, user=request.user, emoji=emoji)

        serializer = MessageSerializer(msg)
        broadcast_to_group(f"chat_{msg.conversation_id}", {
            "type": "message:reaction",
            "message_id": msg.id,
            "conversation_id": msg.conversation_id,
            "reactions": serializer.data['reactions'],
            "user_id": request.user.id,
            "emoji": emoji
        })

        return Response({'message_id': msg.id, 'reactions': serializer.data['reactions']})

class MessageDetailView(views.APIView):
    def patch(self, request, pk):
        msg = get_object_or_404(Message, id=pk)
        if msg.sender != request.user:
            return Response({'error': 'You can only edit your own messages.'}, status=status.HTTP_403_FORBIDDEN)
        if msg.is_deleted:
            return Response({'error': 'Cannot edit deleted message.'}, status=status.HTTP_400_BAD_REQUEST)

        text = request.data.get('text', '').strip()
        if not text:
            return Response({'error': 'Text cannot be empty.'}, status=status.HTTP_400_BAD_REQUEST)

        msg.text = text
        msg.is_edited = True
        msg.save()

        serializer = MessageSerializer(msg)
        broadcast_to_group(f"chat_{msg.conversation_id}", {
            "type": "message:edited",
            "message_id": msg.id,
            "conversation_id": msg.conversation_id,
            "text": msg.text,
            "is_edited": True,
            "updated_at": msg.updated_at.isoformat()
        })

        return Response({'message': serializer.data})

    def delete(self, request, pk):
        msg = get_object_or_404(Message, id=pk)
        membership = msg.conversation.memberships.filter(user=request.user).first()
        if not membership:
            return Response({'error': 'Forbidden.'}, status=status.HTTP_403_FORBIDDEN)

        is_author = msg.sender == request.user
        is_admin = membership.role == 'admin'

        if not is_author and not is_admin:
            return Response({'error': 'Forbidden.'}, status=status.HTTP_403_FORBIDDEN)

        msg.is_deleted = True
        msg.text = 'This message was deleted'
        msg.save()

        broadcast_to_group(f"chat_{msg.conversation_id}", {
            "type": "message:deleted",
            "message_id": msg.id,
            "conversation_id": msg.conversation_id
        })

        return Response({'message': 'Message deleted.'})
