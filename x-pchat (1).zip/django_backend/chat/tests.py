from django.test import TestCase
from django.contrib.auth.models import User
from rest_framework.test import APIClient
from rest_framework import status
from .models import Conversation, Membership, Message, MessageReaction, Profile

class PChatCompleteBackendTestSuite(TestCase):
    def setUp(self):
        self.client_a = APIClient()
        self.client_b = APIClient()
        self.client_c = APIClient()

        # User A
        self.user_a = User.objects.create_user(username='test_alice', email='alice@test.org', password='Password@123')
        Profile.objects.create(user=self.user_a, display_name='Alice Panda')
        res_a = self.client_a.post('/api/auth/login/', {'username': 'test_alice', 'password': 'Password@123'})
        self.token_a = res_a.data['token']
        self.client_a.credentials(HTTP_AUTHORIZATION=f'Token {self.token_a}')

        # User B
        self.user_b = User.objects.create_user(username='test_bob', email='bob@test.org', password='Password@123')
        Profile.objects.create(user=self.user_b, display_name='Bob Panda')
        res_b = self.client_b.post('/api/auth/login/', {'username': 'test_bob', 'password': 'Password@123'})
        self.token_b = res_b.data['token']
        self.client_b.credentials(HTTP_AUTHORIZATION=f'Token {self.token_b}')

        # User C (Third Party / Unauthorized)
        self.user_c = User.objects.create_user(username='test_charlie', email='charlie@test.org', password='Password@123')
        Profile.objects.create(user=self.user_c, display_name='Charlie Panda')
        res_c = self.client_c.post('/api/auth/login/', {'username': 'test_charlie', 'password': 'Password@123'})
        self.token_c = res_c.data['token']
        self.client_c.credentials(HTTP_AUTHORIZATION=f'Token {self.token_c}')

    def test_registration_and_validation(self):
        client = APIClient()
        # Invalid credentials / missing fields
        res_missing = client.post('/api/auth/register/', {'username': 'incomplete'})
        self.assertEqual(res_missing.status_code, status.HTTP_400_BAD_REQUEST)

        # Duplicate username
        res_dup = client.post('/api/auth/register/', {
            'username': 'test_alice',
            'email': 'another@test.org',
            'password': 'Password@123'
        })
        self.assertEqual(res_dup.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('taken', res_dup.data['error'])

        # Successful registration
        res_ok = client.post('/api/auth/register/', {
            'username': 'new_panda',
            'email': 'new@test.org',
            'password': 'Password@123',
            'display_name': 'New Panda'
        })
        self.assertEqual(res_ok.status_code, status.HTTP_201_CREATED)
        self.assertIn('token', res_ok.data)
        self.assertEqual(res_ok.data['user']['username'], 'new_panda')

    def test_user_search_and_exclusion(self):
        # User A searches for 'bob'
        res = self.client_a.get('/api/users/search/?q=bob')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        users = res.data['users']
        self.assertTrue(any(u['username'] == 'test_bob' for u in users))
        # Ensure User A is excluded from their own search results
        self.assertFalse(any(u['username'] == 'test_alice' for u in users))

    def test_one_to_one_conversation_lifecycle(self):
        # 1. Self conversation blocked
        res_self = self.client_a.post('/api/conversations/', {
            'type': 'direct',
            'recipient_id': self.user_a.id
        })
        self.assertEqual(res_self.status_code, status.HTTP_400_BAD_REQUEST)

        # 2. Create direct conversation between A and B
        res_conv = self.client_a.post('/api/conversations/', {
            'type': 'direct',
            'recipient_id': self.user_b.id
        })
        self.assertEqual(res_conv.status_code, status.HTTP_201_CREATED)
        conv_id = res_conv.data['conversation']['id']

        # 3. Duplicate conversation creation reuses existing
        res_conv_dup = self.client_a.post('/api/conversations/', {
            'type': 'direct',
            'recipient_id': self.user_b.id
        })
        self.assertEqual(res_conv_dup.status_code, status.HTTP_200_OK)
        self.assertEqual(res_conv_dup.data['conversation']['id'], conv_id)
        self.assertTrue(res_conv_dup.data['is_existing'])

        # 4. User C cannot access private conversation (RBAC 403 Forbidden)
        res_c = self.client_c.get(f'/api/conversations/{conv_id}/messages/')
        self.assertEqual(res_c.status_code, status.HTTP_403_FORBIDDEN)

        # 5. User A sends message: "Hello from User A"
        test_text = "Hello from User A"
        res_msg = self.client_a.post(f'/api/conversations/{conv_id}/messages/', {'text': test_text})
        self.assertEqual(res_msg.status_code, status.HTTP_201_CREATED)
        msg_id = res_msg.data['message']['id']

        # 6. Verify message persists in SQLite database
        msg = Message.objects.get(id=msg_id)
        self.assertEqual(msg.text, test_text)
        self.assertEqual(msg.sender, self.user_a)

        # 7. User B reads messages
        res_msgs = self.client_b.get(f'/api/conversations/{conv_id}/messages/')
        self.assertEqual(res_msgs.status_code, status.HTTP_200_OK)
        self.assertEqual(len(res_msgs.data['messages']), 1)
        self.assertEqual(res_msgs.data['messages'][0]['text'], test_text)

        # 8. Emoji reaction toggling
        res_react = self.client_a.post(f'/api/messages/{msg_id}/reactions/', {'emoji': '🐼'})
        self.assertEqual(res_react.status_code, status.HTTP_200_OK)
        self.assertIn('🐼', res_react.data['reactions'])
        self.assertIn(str(self.user_a.id), res_react.data['reactions']['🐼'])

        # Toggle off
        res_react_off = self.client_a.post(f'/api/messages/{msg_id}/reactions/', {'emoji': '🐼'})
        self.assertEqual(res_react_off.status_code, status.HTTP_200_OK)
        self.assertEqual(res_react_off.data['reactions'], {})

        # 9. Voice note audio message creation & persistence
        res_voice = self.client_a.post(f'/api/conversations/{conv_id}/messages/', {
            'text': '🎤 Voice message',
            'audio_url': 'data:audio/webm;base64,GkXfo59ChoEBQveBAULygQRC84EIQoKEd2VibUKHgQRChYECGFOAZwEAAAAAAAAAA',
            'audio_duration': 6,
        })
        self.assertEqual(res_voice.status_code, status.HTTP_201_CREATED)
        self.assertEqual(res_voice.data['message']['audio_duration'], 6)

        # 10. Message edit (Author only)
        res_edit = self.client_a.patch(f'/api/messages/{msg_id}/', {'text': 'Edited message text'})
        self.assertEqual(res_edit.status_code, status.HTTP_200_OK)
        self.assertEqual(res_edit.data['message']['text'], 'Edited message text')

        # User B cannot edit User A's message
        res_unauth_edit = self.client_b.patch(f'/api/messages/{msg_id}/', {'text': 'Hacked'})
        self.assertEqual(res_unauth_edit.status_code, status.HTTP_403_FORBIDDEN)

        # 11. Message delete (soft delete)
        res_del = self.client_a.delete(f'/api/messages/{msg_id}/')
        self.assertEqual(res_del.status_code, status.HTTP_200_OK)
        msg.refresh_from_db()
        self.assertTrue(msg.is_deleted)
        self.assertEqual(msg.text, 'This message was deleted')

    def test_group_chat_and_permissions(self):
        # 1. Create group
        res_g = self.client_a.post('/api/conversations/', {
            'type': 'group',
            'title': 'Panda Engineering Core',
            'member_ids': [self.user_a.id, self.user_b.id]
        })
        self.assertEqual(res_g.status_code, status.HTTP_201_CREATED)
        group_id = res_g.data['conversation']['id']

        # 2. Member A (admin) can add Member C
        res_add = self.client_a.post(f'/api/conversations/{group_id}/members/', {'user_id': self.user_c.id})
        self.assertEqual(res_add.status_code, status.HTTP_200_OK)

        # 3. Member B (regular member) cannot add users
        res_unauth_add = self.client_b.post(f'/api/conversations/{group_id}/members/', {'user_id': self.user_c.id})
        self.assertEqual(res_unauth_add.status_code, status.HTTP_403_FORBIDDEN)
