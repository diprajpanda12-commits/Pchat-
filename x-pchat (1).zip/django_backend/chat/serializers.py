from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Profile, Conversation, Membership, Message, MessageReaction, ReadReceipt

class UserSummarySerializer(serializers.ModelSerializer):
    display_name = serializers.CharField(source='profile.display_name', read_only=True)
    bio = serializers.CharField(source='profile.bio', read_only=True)
    avatar_url = serializers.CharField(source='profile.avatar_url', read_only=True)
    is_online = serializers.BooleanField(source='profile.is_online', read_only=True)
    last_seen = serializers.DateTimeField(source='profile.last_seen', read_only=True)

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'display_name', 'bio', 'avatar_url', 'is_online', 'last_seen']

class MessageSerializer(serializers.ModelSerializer):
    sender = UserSummarySerializer(read_only=True)
    sender_id = serializers.CharField(source='sender.id', read_only=True)
    conversation_id = serializers.CharField(source='conversation.id', read_only=True)
    reactions = serializers.SerializerMethodField()
    reply_to = serializers.SerializerMethodField()

    class Meta:
        model = Message
        fields = [
            'id', 'conversation_id', 'sender_id', 'sender', 'text',
            'reply_to_id', 'reply_to', 'status', 'is_edited', 'is_deleted',
            'audio_url', 'audio_duration', 'reactions',
            'created_at', 'updated_at'
        ]

    def get_reactions(self, obj):
        # Return { emoji: [user_id_1, user_id_2] }
        result = {}
        for r in obj.reactions.all():
            result.setdefault(r.emoji, []).append(str(r.user_id))
        return result

    def get_reply_to(self, obj):
        if obj.reply_to:
            return {
                'id': obj.reply_to.id,
                'sender_id': str(obj.reply_to.sender_id),
                'text': obj.reply_to.text,
                'sender': UserSummarySerializer(obj.reply_to.sender).data
            }
        return None

class MembershipSerializer(serializers.ModelSerializer):
    id = serializers.CharField(source='user.id', read_only=True)
    username = serializers.CharField(source='user.username', read_only=True)
    display_name = serializers.CharField(source='user.profile.display_name', read_only=True)
    avatar_url = serializers.CharField(source='user.profile.avatar_url', read_only=True)
    is_online = serializers.BooleanField(source='user.profile.is_online', read_only=True)
    last_seen = serializers.DateTimeField(source='user.profile.last_seen', read_only=True)

    class Meta:
        model = Membership
        fields = ['id', 'role', 'joined_at', 'username', 'display_name', 'avatar_url', 'is_online', 'last_seen']

class ConversationSerializer(serializers.ModelSerializer):
    members = MembershipSerializer(source='memberships', many=True, read_only=True)
    last_message = serializers.SerializerMethodField()
    unread_count = serializers.SerializerMethodField()
    recipient = serializers.SerializerMethodField()

    class Meta:
        model = Conversation
        fields = [
            'id', 'type', 'title', 'avatar_url', 'created_by',
            'created_at', 'updated_at', 'members', 'last_message',
            'unread_count', 'recipient'
        ]

    def get_last_message(self, obj):
        last_msg = obj.messages.last()
        if last_msg:
            return MessageSerializer(last_msg).data
        return None

    def get_unread_count(self, obj):
        request = self.context.get('request')
        if not request or not request.user.is_authenticated:
            return 0
        user = request.user
        membership = obj.memberships.filter(user=user).first()
        if not membership:
            return 0
        if not membership.last_read_message:
            return obj.messages.exclude(sender=user).count()
        return obj.messages.filter(
            created_at__gt=membership.last_read_message.created_at
        ).exclude(sender=user).count()

    def get_recipient(self, obj):
        if obj.type != 'direct':
            return None
        request = self.context.get('request')
        if not request or not request.user.is_authenticated:
            return None
        other_membership = obj.memberships.exclude(user=request.user).first()
        if other_membership:
            return UserSummarySerializer(other_membership.user).data
        return None
