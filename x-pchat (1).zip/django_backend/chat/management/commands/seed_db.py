from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from rest_framework.authtoken.models import Token
from chat.models import Profile, Conversation, Membership, Message, MessageReaction

class Command(BaseCommand):
    help = 'Seeds initial users and conversations in Django SQLite database'

    def handle(self, *args, **options):
        self.stdout.write("Seeding database...")

        users_data = [
            {
                'username': 'panda_alice',
                'email': 'alice@pchat.org',
                'display_name': 'Alice Panda 🐼',
                'bio': 'Loves bamboo and real-time chatting on PChat!',
                'avatar_url': 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
            },
            {
                'username': 'panda_bob',
                'email': 'bob@pchat.org',
                'display_name': 'Bob Panda 🎋',
                'bio': 'Mobile software engineer and Django developer.',
                'avatar_url': 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
            },
            {
                'username': 'panda_charlie',
                'email': 'charlie@pchat.org',
                'display_name': 'Charlie Bamboo 🐾',
                'bio': 'Panda community moderator.',
                'avatar_url': 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150&auto=format&fit=crop&q=80',
            },
        ]

        created_users = {}
        for u in users_data:
            user, created = User.objects.get_or_create(
                username=u['username'],
                defaults={'email': u['email']}
            )
            user.set_password('Panda@123')
            user.save()
            created_users[u['username']] = user

            profile, _ = Profile.objects.get_or_create(user=user)
            profile.display_name = u['display_name']
            profile.bio = u['bio']
            profile.avatar_url = u['avatar_url']
            profile.is_online = True
            profile.save()

            Token.objects.get_or_create(user=user)
            self.stdout.write(f"User {u['username']} ready.")

        alice = created_users['panda_alice']
        bob = created_users['panda_bob']
        charlie = created_users['panda_charlie']

        # Direct conversation between Alice & Bob
        direct_conv, d_created = Conversation.objects.get_or_create(
            id='conv_alice_bob',
            defaults={
                'type': 'direct',
                'created_by': alice,
            }
        )
        Membership.objects.get_or_create(conversation=direct_conv, user=alice, defaults={'role': 'member'})
        Membership.objects.get_or_create(conversation=direct_conv, user=bob, defaults={'role': 'member'})

        if d_created:
            m1 = Message.objects.create(
                id='msg_alice_1',
                conversation=direct_conv,
                sender=alice,
                text='Hey Bob! Welcome to PChat! 🐼🎋',
                status='read'
            )
            m2 = Message.objects.create(
                id='msg_bob_1',
                conversation=direct_conv,
                sender=bob,
                text='Hello Alice! WebSocket messaging with Django & SQLite is blazing fast!',
                status='read'
            )
            MessageReaction.objects.get_or_create(message=m2, user=alice, emoji='❤️')
            MessageReaction.objects.get_or_create(message=m2, user=bob, emoji='🐼')

        # Group conversation
        group_conv, g_created = Conversation.objects.get_or_create(
            id='conv_panda_hangout',
            defaults={
                'type': 'group',
                'title': 'Panda Developers Hangout 🐼🎋',
                'avatar_url': '/pchat-logo.png',
                'created_by': alice,
            }
        )
        Membership.objects.get_or_create(conversation=group_conv, user=alice, defaults={'role': 'admin'})
        Membership.objects.get_or_create(conversation=group_conv, user=bob, defaults={'role': 'member'})
        Membership.objects.get_or_create(conversation=group_conv, user=charlie, defaults={'role': 'member'})

        if g_created:
            m_g = Message.objects.create(
                id='msg_group_1',
                conversation=group_conv,
                sender=alice,
                text='Welcome everyone to the official Panda Chat group! Enjoy real-time voice notes, emoji reactions, and instant sync. 🚀',
                status='sent'
            )
            MessageReaction.objects.get_or_create(message=m_g, user=bob, emoji='🔥')

        self.stdout.write(self.style.SUCCESS("Database seeding completed successfully!"))
