from django.urls import path
from .views import (
    RegisterView, LoginView, LogoutView, MeView,
    UserSearchView, ProfileUpdateView,
    ConversationListCreateView, ConversationDetailView, ConversationMembersView,
    MessageListCreateView, MessageDetailView, MessageReactionView
)

urlpatterns = [
    # Auth
    path('auth/register/', RegisterView.as_view(), name='auth_register'),
    path('auth/login/', LoginView.as_view(), name='auth_login'),
    path('auth/logout/', LogoutView.as_view(), name='auth_logout'),
    path('auth/me/', MeView.as_view(), name='auth_me'),

    # Users & Profiles
    path('users/search/', UserSearchView.as_view(), name='user_search'),
    path('profile/', ProfileUpdateView.as_view(), name='profile_update'),

    # Conversations
    path('conversations/', ConversationListCreateView.as_view(), name='conversation_list_create'),
    path('conversations/<str:pk>/', ConversationDetailView.as_view(), name='conversation_detail'),
    path('conversations/<str:pk>/members/', ConversationMembersView.as_view(), name='conversation_members'),
    path('conversations/<str:pk>/members/<int:user_id>/', ConversationMembersView.as_view(), name='conversation_member_detail'),

    # Messages
    path('conversations/<str:conversation_id>/messages/', MessageListCreateView.as_view(), name='message_list_create'),
    path('messages/<str:pk>/', MessageDetailView.as_view(), name='message_detail'),
    path('messages/<str:pk>/reactions/', MessageReactionView.as_view(), name='message_reactions'),
]
