import json
import time
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.contrib.auth.models import User
from rest_framework.authtoken.models import Token
from urllib.parse import parse_qs

from .models import Conversation, Membership, Message, MessageReaction, ReadReceipt, Profile
from .serializers import MessageSerializer

class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.conversation_id = self.scope['url_route']['kwargs']['conversation_id']
        self.room_group_name = f"chat_{self.conversation_id}"

        # Authenticate user via token in query string or headers
        query_string = self.scope.get('query_string', b'').decode('utf-8')
        params = parse_qs(query_string)
        token_key = params.get('token', [None])[0]

        user = await self.get_user_from_token(token_key)
        if not user or not user.is_authenticated:
            await self.close(code=4001)
            return

        self.user = user

        # Verify conversation membership
        is_member = await self.check_membership(self.conversation_id, self.user)
        if not is_member:
            await self.close(code=4003)
            return

        # Mark user online
        await self.set_online_status(self.user, True)

        # Join room group
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )

        await self.accept()

        # Send welcome payload
        await self.send(text_data=json.dumps({
            'type': 'connection:established',
            'user': {
                'id': self.user.id,
                'username': self.user.username,
                'display_name': getattr(getattr(self.user, 'profile', None), 'display_name', self.user.username),
            },
            'conversation_id': self.conversation_id,
            'server_time': time.time(),
        }))

    async def disconnect(self, close_code):
        if hasattr(self, 'room_group_name'):
            await self.channel_layer.group_discard(
                self.room_group_name,
                self.channel_name
            )

    async def receive(self, text_data):
        try:
            data = json.loads(text_data)
        except json.JSONDecodeError:
            await self.send(text_data=json.dumps({'type': 'error', 'message': 'Malformed JSON payload.'}))
            return

        action_type = data.get('type')

        if action_type == 'message:send':
            text = data.get('text', '').strip()
            reply_to_id = data.get('reply_to_id')
            client_temp_id = data.get('client_temp_id')
            audio_url = data.get('audio_url')
            audio_duration = data.get('audio_duration')

            effective_text = text or ('🎤 Voice message' if audio_url else '')
            if not effective_text:
                return

            msg_data = await self.save_message(self.conversation_id, self.user, effective_text, reply_to_id, audio_url, audio_duration)
            msg_data['client_temp_id'] = client_temp_id

            await self.channel_layer.group_send(
                self.room_group_name,
                {
                    'type': 'chat_message',
                    'payload': {
                        'type': 'message:new',
                        'message': msg_data,
                        'conversation_id': self.conversation_id,
                    }
                }
            )

        elif action_type == 'message:reaction':
            msg_id = data.get('message_id')
            emoji = data.get('emoji', '').strip()
            if not msg_id or not emoji:
                return

            updated_reactions = await self.toggle_reaction(msg_id, self.user, emoji)
            if updated_reactions is not None:
                await self.channel_layer.group_send(
                    self.room_group_name,
                    {
                        'type': 'chat_message',
                        'payload': {
                            'type': 'message:reaction',
                            'message_id': msg_id,
                            'conversation_id': self.conversation_id,
                            'reactions': updated_reactions,
                            'user_id': self.user.id,
                            'emoji': emoji,
                        }
                    }
                )

        elif action_type == 'message:delivered':
            msg_id = data.get('message_id')
            if msg_id:
                await self.mark_delivered(msg_id)
                await self.channel_layer.group_send(
                    self.room_group_name,
                    {
                        'type': 'chat_message',
                        'payload': {
                            'type': 'message:delivered',
                            'message_id': msg_id,
                            'conversation_id': self.conversation_id,
                            'recipient_id': self.user.id,
                        }
                    }
                )

        elif action_type == 'message:read':
            msg_id = data.get('message_id')
            if msg_id:
                await self.mark_read(msg_id, self.user, self.conversation_id)
                await self.channel_layer.group_send(
                    self.room_group_name,
                    {
                        'type': 'chat_message',
                        'payload': {
                            'type': 'message:read',
                            'message_id': msg_id,
                            'conversation_id': self.conversation_id,
                            'reader_id': self.user.id,
                        }
                    }
                )

        elif action_type == 'typing:start':
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                    'type': 'chat_message',
                    'payload': {
                        'type': 'typing:status',
                        'conversation_id': self.conversation_id,
                        'user_id': self.user.id,
                        'username': self.user.username,
                        'display_name': getattr(getattr(self.user, 'profile', None), 'display_name', self.user.username),
                        'is_typing': True,
                    }
                }
            )

        elif action_type == 'typing:stop':
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                    'type': 'chat_message',
                    'payload': {
                        'type': 'typing:status',
                        'conversation_id': self.conversation_id,
                        'user_id': self.user.id,
                        'username': self.user.username,
                        'display_name': getattr(getattr(self.user, 'profile', None), 'display_name', self.user.username),
                        'is_typing': False,
                    }
                }
            )

        elif action_type == 'ping':
            await self.send(text_data=json.dumps({
                'type': 'pong',
                'echoTimestamp': data.get('timestamp'),
                'serverTimestamp': int(time.time() * 1000),
            }))

    async def chat_message(self, event):
        await self.send(text_data=json.dumps(event['payload']))

    @database_sync_to_async
    def get_user_from_token(self, token_key):
        if not token_key:
            return None
        try:
            token = Token.objects.select_related('user', 'user__profile').get(key=token_key)
            return token.user
        except Token.DoesNotExist:
            return None

    @database_sync_to_async
    def check_membership(self, conv_id, user):
        return Membership.objects.filter(conversation_id=conv_id, user=user).exists()

    @database_sync_to_async
    def set_online_status(self, user, is_online):
        if hasattr(user, 'profile'):
            user.profile.is_online = is_online
            user.profile.save()

    @database_sync_to_async
    def save_message(self, conv_id, user, text, reply_to_id, audio_url, audio_duration):
        conv = Conversation.objects.get(id=conv_id)
        msg = Message.objects.create(
            conversation=conv,
            sender=user,
            text=text,
            reply_to_id=reply_to_id,
            audio_url=audio_url,
            audio_duration=audio_duration,
            status='sent'
        )
        return MessageSerializer(msg).data

    @database_sync_to_async
    def toggle_reaction(self, msg_id, user, emoji):
        try:
            msg = Message.objects.get(id=msg_id)
            existing = MessageReaction.objects.filter(message=msg, user=user, emoji=emoji).first()
            if existing:
                existing.delete()
            else:
                MessageReaction.objects.create(message=msg, user=user, emoji=emoji)
            return MessageSerializer(msg).data['reactions']
        except Message.DoesNotExist:
            return None

    @database_sync_to_async
    def mark_delivered(self, msg_id):
        Message.objects.filter(id=msg_id, status='sent').update(status='delivered')

    @database_sync_to_async
    def mark_read(self, msg_id, user, conv_id):
        msg = Message.objects.filter(id=msg_id).first()
        if msg:
            ReadReceipt.objects.get_or_create(message=msg, user=user)
            msg.status = 'read'
            msg.save()
            membership = Membership.objects.filter(conversation_id=conv_id, user=user).first()
            if membership:
                membership.last_read_message = msg
                membership.save()

class GeneralConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        query_string = self.scope.get('query_string', b'').decode('utf-8')
        params = parse_qs(query_string)
        token_key = params.get('token', [None])[0]

        user = await self.get_user_from_token(token_key)
        if not user or not user.is_authenticated:
            await self.close(code=4001)
            return

        self.user = user
        self.user_group_name = f"user_{self.user.id}"

        await self.channel_layer.group_add(
            self.user_group_name,
            self.channel_name
        )

        await self.accept()

    async def disconnect(self, close_code):
        if hasattr(self, 'user_group_name'):
            await self.channel_layer.group_discard(
                self.user_group_name,
                self.channel_name
            )

    async def receive(self, text_data):
        pass

    async def chat_message(self, event):
        await self.send(text_data=json.dumps(event['payload']))

    @database_sync_to_async
    def get_user_from_token(self, token_key):
        if not token_key:
            return None
        try:
            token = Token.objects.select_related('user').get(key=token_key)
            return token.user
        except Token.DoesNotExist:
            return None
