import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';

const DATA_DIR = path.resolve('data');
const DB_FILE = path.join(DATA_DIR, 'pchat_db.json');
const BACKUP_FILE = path.join(DATA_DIR, 'pchat_db_backup.json');

const defaultPasswordHash = bcrypt.hashSync('Panda@123', 10);
const now = new Date().toISOString();

const canonicalData = {
  users: [
    {
      id: 'u_alice',
      username: 'panda_alice',
      email: 'alice@pchat.app',
      password_hash: defaultPasswordHash,
      display_name: 'Alice Panda 🐼',
      bio: 'PChat Lead Tester & Panda enthusiast 🌿',
      avatar_url: '/avatars/panda-emerald.svg',
      is_online: true,
      last_seen: now,
      created_at: now,
    },
    {
      id: 'u_bob',
      username: 'panda_bob',
      email: 'bob@pchat.app',
      password_hash: defaultPasswordHash,
      display_name: 'Bob Panda 🎋',
      bio: 'Real-time WebSocket architect & coder ⚡',
      avatar_url: '/avatars/panda-cyber.svg',
      is_online: true,
      last_seen: now,
      created_at: now,
    },
    {
      id: 'u_charlie',
      username: 'panda_charlie',
      email: 'charlie@pchat.app',
      password_hash: defaultPasswordHash,
      display_name: 'Charlie Panda 🎯',
      bio: 'Security researcher & external tester 🛡️',
      avatar_url: '/avatars/panda-ninja.svg',
      is_online: false,
      last_seen: now,
      created_at: now,
    },
    {
      id: 'u_maya',
      username: 'maya_chen',
      email: 'maya@pchat.app',
      password_hash: defaultPasswordHash,
      display_name: 'Maya Chen ✨',
      bio: 'Product Designer & UI lover 🎨',
      avatar_url: '/avatars/panda-astro.svg',
      is_online: true,
      last_seen: now,
      created_at: now,
    },
    {
      id: 'u_panda_bot',
      username: 'panda_bot',
      email: 'bot@pchat.app',
      password_hash: defaultPasswordHash,
      display_name: 'Panda Bot 🤖',
      bio: 'Official PChat Welcome & Echo Companion',
      avatar_url: '/avatars/panda-classic.svg',
      is_online: true,
      last_seen: now,
      created_at: now,
    },
  ],
  conversations: [
    {
      id: 'conv_panda_hangout',
      type: 'group',
      title: '🎋 Bamboo Grove Hangout',
      avatar_url: '/avatars/panda-royal.svg',
      created_by: 'u_alice',
      created_at: now,
      updated_at: now,
    },
  ],
  memberships: [
    { conversation_id: 'conv_panda_hangout', user_id: 'u_alice', role: 'admin', joined_at: now, last_read_message_id: null },
    { conversation_id: 'conv_panda_hangout', user_id: 'u_bob', role: 'member', joined_at: now, last_read_message_id: null },
    { conversation_id: 'conv_panda_hangout', user_id: 'u_charlie', role: 'member', joined_at: now, last_read_message_id: null },
    { conversation_id: 'conv_panda_hangout', user_id: 'u_maya', role: 'member', joined_at: now, last_read_message_id: null },
    { conversation_id: 'conv_panda_hangout', user_id: 'u_panda_bot', role: 'member', joined_at: now, last_read_message_id: null },
  ],
  messages: [
    {
      id: 'msg_welcome_alice',
      conversation_id: 'conv_panda_hangout',
      sender_id: 'u_alice',
      text: 'Welcome to PChat (Panda Chat)! 🐼 Real-time messaging, scheduled messages, and instant reactions are all active.',
      reply_to_id: null,
      parent_message_id: null,
      status: 'read',
      is_edited: false,
      is_deleted: false,
      created_at: new Date(Date.now() - 3600000).toISOString(),
      updated_at: new Date(Date.now() - 3600000).toISOString(),
      reactions: { '🐼': ['u_alice', 'u_bob', 'u_maya'], '❤️': ['u_bob'] },
    },
    {
      id: 'msg_welcome_bob',
      conversation_id: 'conv_panda_hangout',
      sender_id: 'u_bob',
      text: 'All messages are synchronized via authenticated WebSockets with persistent storage and delivery status checks 🎋⚡',
      reply_to_id: 'msg_welcome_alice',
      parent_message_id: 'msg_welcome_alice',
      status: 'read',
      is_edited: false,
      is_deleted: false,
      created_at: new Date(Date.now() - 1800000).toISOString(),
      updated_at: new Date(Date.now() - 1800000).toISOString(),
      reactions: { '🔥': ['u_alice'] },
    },
  ],
  read_receipts: [],
  sessions: [],
  scheduled_messages: [],
};

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.writeFileSync(DB_FILE, JSON.stringify(canonicalData, null, 2), 'utf-8');
fs.writeFileSync(BACKUP_FILE, JSON.stringify(canonicalData, null, 2), 'utf-8');
console.log('Successfully wiped old accounts and cleanly seeded canonical accounts with zero duplicates!');
